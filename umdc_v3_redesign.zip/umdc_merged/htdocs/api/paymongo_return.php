<?php
// api/paymongo_return.php — User lands here after GCash/Maya redirect
defined('UMDC_APP') or define('UMDC_APP', true);
require_once __DIR__ . '/../Config/security.php';
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../receipts/generate.php';
umdc_session_start();
setSecureHeaders();

$status      = $_GET['status']      ?? '';
$donation_id = filter_var($_GET['donation_id'] ?? 0, FILTER_VALIDATE_INT);
$source_id   = $_GET['id']          ?? ''; // PayMongo appends ?id=src_xxx

if (!$donation_id) {
    header('Location: /dashboard/user.php?_sess=UMDC_USER&error=invalid_return');
    exit;
}

if ($status === 'success' && $donation_id) {
    try {
        // Verify this donation is still pending
        $stmt = $pdo->prepare("
            SELECT d.*, c.campaign_id, c.title AS campaign_title
            FROM donations d
            JOIN campaigns c ON d.campaign_id = c.campaign_id
            WHERE d.donation_id = ? AND d.status = 'pending'
        ");
        $stmt->execute([$donation_id]);
        $donation = $stmt->fetch();

        if ($donation) {
            $pdo->beginTransaction();

            $pdo->prepare("UPDATE donations SET status='completed' WHERE donation_id=?")
                ->execute([$donation_id]);
            $pdo->prepare("UPDATE campaigns SET current_amount = current_amount + ? WHERE campaign_id=?")
                ->execute([$donation['amount'], $donation['campaign_id']]);
            $pdo->prepare("UPDATE payments SET payment_status='success', paid_at=NOW() WHERE donation_id=?")
                ->execute([$donation_id]);

            generateReceipt($pdo, $donation_id);

            // Get user_id from donation for audit log
            auditLog($pdo, $donation['user_id'], 'payment_completed', 'donation', $donation_id);
            $pdo->commit();
        }
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log('PayMongo return error: ' . $e->getMessage());
        header('Location: /dashboard/user.php?_sess=UMDC_USER&error=payment_error');
        exit;
    }

    header('Location: /dashboard/user.php?_sess=UMDC_USER&success=payment_complete');
    exit;
}

// Failed / cancelled
if ($donation_id) {
    try {
        $pdo->prepare("UPDATE payments SET payment_status='failed' WHERE donation_id=?")
            ->execute([$donation_id]);
    } catch (PDOException $e) { /* non-fatal */ }
}
header("Location: /donations/cash.php?_sess=UMDC_USER&id={$donation_id}&error=payment_failed");
exit;
