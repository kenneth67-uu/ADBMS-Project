<?php
// api/paymongo_webhook.php
// Add this URL to your PayMongo dashboard: https://yourdomain.com/api/paymongo_webhook.php
defined('UMDC_APP') or define('UMDC_APP', true);
require_once __DIR__ . '/../Config/security.php';
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../Config/paymongo.php';
require_once __DIR__ . '/../receipts/generate.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit(json_encode(['error' => 'Method not allowed']));
}

$payload   = file_get_contents('php://input');
$signature = $_SERVER['HTTP_PAYMONGO_SIGNATURE'] ?? '';

// Verify webhook signature
if (!PayMongo::verifyWebhook($payload, $signature)) {
    http_response_code(401);
    exit(json_encode(['error' => 'Invalid signature']));
}

$event = json_decode($payload, true);
if (!$event) {
    http_response_code(400);
    exit(json_encode(['error' => 'Invalid payload']));
}

$type       = $event['data']['attributes']['type']      ?? '';
$attributes = $event['data']['attributes']['data']['attributes'] ?? [];
$metadata   = $attributes['metadata'] ?? [];
$donation_id= (int)($metadata['donation_id'] ?? 0);

error_log("PayMongo webhook: $type, donation_id=$donation_id");

try {
    switch ($type) {
        case 'payment.paid':
        case 'source.chargeable':
            if (!$donation_id) break;

            // Fetch donation
            $stmt = $pdo->prepare("SELECT * FROM donations WHERE donation_id=? AND status='pending'");
            $stmt->execute([$donation_id]);
            $donation = $stmt->fetch();

            if (!$donation) break; // Already processed

            $pdo->beginTransaction();
            $pdo->prepare("UPDATE donations SET status='completed' WHERE donation_id=?")
                ->execute([$donation_id]);
            $pdo->prepare("UPDATE campaigns SET current_amount=current_amount+? WHERE campaign_id=?")
                ->execute([$donation['amount'], $donation['campaign_id']]);
            $pdo->prepare("UPDATE payments SET payment_status='success', paid_at=NOW() WHERE donation_id=?")
                ->execute([$donation_id]);
            generateReceipt($pdo, $donation_id);
            $pdo->prepare("INSERT INTO audit_logs (user_id,action,entity_type,entity_id,ip_address) VALUES (?,?,?,?,?)")
                ->execute([$donation['user_id'],'payment_webhook_success','donation',$donation_id,'webhook']);
            $pdo->commit();
            break;

        case 'payment.failed':
            if ($donation_id) {
                $pdo->prepare("UPDATE payments SET payment_status='failed' WHERE donation_id=?")
                    ->execute([$donation_id]);
            }
            break;
    }

    http_response_code(200);
    echo json_encode(['received' => true]);

} catch (PDOException $e) {
    $pdo->rollBack();
    error_log('Webhook DB error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'DB error']);
}
