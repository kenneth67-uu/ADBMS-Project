<?php
// api/paymongo_create.php — Creates a PayMongo payment source/intent
defined('UMDC_APP') or define('UMDC_APP', true);
require_once __DIR__ . '/../Config/security.php';
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../Config/paymongo.php';
umdc_session_start();
requireRole('user');
setSecureHeaders();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
}
csrf_check();

$donation_id = filter_var($_POST['donation_id'] ?? 0, FILTER_VALIDATE_INT);
$method      = $_POST['payment_method'] ?? 'gcash'; // gcash | maya | qrph
$user_id     = currentUserId();

if (!$donation_id) jsonResponse(['success' => false, 'message' => 'Invalid donation'], 400);
if (!in_array($method, ['gcash','maya','qrph'], true)) {
    jsonResponse(['success' => false, 'message' => 'Invalid payment method'], 400);
}

try {
    // Fetch donation — verify ownership
    $stmt = $pdo->prepare("
        SELECT d.*, c.title AS campaign_title, c.campaign_id
        FROM donations d
        JOIN campaigns c ON d.campaign_id = c.campaign_id
        WHERE d.donation_id = ? AND d.user_id = ? AND d.status = 'pending'
    ");
    $stmt->execute([$donation_id, $user_id]);
    $donation = $stmt->fetch();

    if (!$donation) {
        jsonResponse(['success' => false, 'message' => 'Donation not found or already processed'], 404);
    }

    $amount      = (float)$donation['amount'];
    $description = 'UMDC Donation: ' . mb_substr($donation['campaign_title'], 0, 100);

    // Create payment based on method
    switch ($method) {
        case 'gcash':
            $result = PayMongo::createGCashSource($amount, $description, $donation_id);
            $checkoutUrl = $result['checkout_url'];
            $sourceId    = $result['source_id'];
            $intentId    = null;
            break;

        case 'maya':
            $result = PayMongo::createMayaSource($amount, $description, $donation_id);
            $checkoutUrl = $result['checkout_url'];
            $sourceId    = $result['source_id'];
            $intentId    = null;
            break;

        case 'qrph':
            $result = PayMongo::createQRPH($amount, $description, $donation_id);
            $checkoutUrl = $result['checkout_url'] ?? '';
            $sourceId    = null;
            $intentId    = $result['payment_intent_id'] ?? null;
            break;

        default:
            jsonResponse(['success' => false, 'message' => 'Unknown method'], 400);
    }

    // Store payment record with source/intent reference
    $ref = $sourceId ?? $intentId ?? 'UMDC-' . strtoupper(bin2hex(random_bytes(4)));
    $pdo->prepare("
        INSERT INTO payments (donation_id, gateway, transaction_ref, payment_status)
        VALUES (?, ?, ?, 'pending')
        ON DUPLICATE KEY UPDATE transaction_ref=VALUES(transaction_ref), payment_status='pending'
    ")->execute([$donation_id, $method, $ref]);

    auditLog($pdo, $user_id, 'payment_initiated', 'donation', $donation_id);

    jsonResponse([
        'success'      => true,
        'checkout_url' => $checkoutUrl,
        'method'       => $method,
        'qr_code_url'  => $result['qr_code_url'] ?? $checkoutUrl,
        'ref'          => $ref,
    ]);

} catch (RuntimeException $e) {
    error_log('PayMongo create: ' . $e->getMessage());
    jsonResponse(['success' => false, 'message' => $e->getMessage()], 422);
} catch (PDOException $e) {
    error_log('PayMongo DB: ' . $e->getMessage());
    jsonResponse(['success' => false, 'message' => 'Database error'], 500);
}
