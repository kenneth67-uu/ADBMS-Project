<?php
defined('UMDC_APP') or define('UMDC_APP', true);
require_once __DIR__ . '/../Config/security.php';
require_once __DIR__ . '/../Config/db.php';
umdc_session_start();
requireAnyRole(['user','organization','admin']);
setSecureHeaders();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
}
csrf_check();

$user_id  = currentUserId();
$current  = $_POST['current_password'] ?? '';
$new      = $_POST['new_password']     ?? '';
$confirm  = $_POST['confirm_password'] ?? '';

if (!$current || !$new || !$confirm)
    jsonResponse(['success' => false, 'message' => 'All fields are required'], 422);
if (strlen($new) < 8)
    jsonResponse(['success' => false, 'message' => 'New password must be at least 8 characters'], 422);
if ($new !== $confirm)
    jsonResponse(['success' => false, 'message' => 'Passwords do not match'], 422);

try {
    $stmt = $pdo->prepare("SELECT password_hash FROM users WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($current, $user['password_hash']))
        jsonResponse(['success' => false, 'message' => 'Current password is incorrect'], 403);

    $newHash = password_hash($new, PASSWORD_BCRYPT, ['cost' => 12]);
    $pdo->prepare("UPDATE users SET password_hash = ? WHERE user_id = ?")
        ->execute([$newHash, $user_id]);

    auditLog($pdo, $user_id, 'password_changed');
    jsonResponse(['success' => true, 'message' => 'Password changed successfully!']);

} catch (PDOException $e) {
    error_log('change_password: ' . $e->getMessage());
    jsonResponse(['success' => false, 'message' => 'Failed to change password'], 500);
}
