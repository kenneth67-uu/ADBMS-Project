<?php
defined('UMDC_APP') or define('UMDC_APP', true);
require_once __DIR__ . '/../Config/security.php';
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../Config/upload_helper.php';
umdc_session_start();
requireRole('organization');
setSecureHeaders();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
}
csrf_check();

$user_id     = currentUserId();
$campaign_id = filter_var($_POST['campaign_id'] ?? 0, FILTER_VALIDATE_INT);
$file        = $_FILES['image'] ?? null;

if (!$campaign_id) jsonResponse(['success' => false, 'message' => 'Campaign ID required'], 400);
if (!$file)        jsonResponse(['success' => false, 'message' => 'No file uploaded'], 400);

try {
    // Verify org owns this campaign
    $stmt = $pdo->prepare("
        SELECT c.campaign_id, c.campaign_image
        FROM campaigns c
        JOIN organizations o ON c.org_id = o.org_id
        WHERE c.campaign_id=? AND o.user_id=?
    ");
    $stmt->execute([$campaign_id, $user_id]);
    $campaign = $stmt->fetch();
    if (!$campaign) jsonResponse(['success' => false, 'message' => 'Campaign not found'], 404);

    // Delete old image
    if ($campaign['campaign_image']) umdc_delete_file($campaign['campaign_image']);

    // Save new
    $relPath = umdc_upload_file($file, 'campaigns', ['jpg','jpeg','png','webp'], 5 * 1024 * 1024);
    $pdo->prepare("UPDATE campaigns SET campaign_image=? WHERE campaign_id=?")->execute([$relPath, $campaign_id]);
    auditLog($pdo, $user_id, 'campaign_image_updated', 'campaign', $campaign_id);

    jsonResponse(['success' => true, 'url' => '/' . $relPath, 'message' => 'Campaign image updated!']);
} catch (RuntimeException $e) {
    jsonResponse(['success' => false, 'message' => $e->getMessage()], 422);
} catch (PDOException $e) {
    error_log('Campaign image upload: ' . $e->getMessage());
    jsonResponse(['success' => false, 'message' => 'Upload failed.'], 500);
}
