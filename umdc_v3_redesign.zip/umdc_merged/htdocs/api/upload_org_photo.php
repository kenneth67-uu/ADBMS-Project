<?php
defined('UMDC_APP') or define('UMDC_APP', true);
require_once __DIR__ . '/../Config/security.php';
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../Config/upload_helper.php';
umdc_session_start();
requireRole('organization');
setSecureHeaders();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
}
csrf_check();

$user_id = currentUserId();
$type    = in_array($_POST['type'] ?? '', ['logo','cover_photo']) ? $_POST['type'] : null;
$file    = $_FILES['photo'] ?? null;

if (!$type)  jsonResponse(['success' => false, 'message' => 'Invalid upload type'], 400);
if (!$file)  jsonResponse(['success' => false, 'message' => 'No file uploaded'], 400);

try {
    // Get org
    $org = $pdo->prepare("SELECT org_id, logo, cover_photo FROM organizations WHERE user_id=?");
    $org->execute([$user_id]);
    $org = $org->fetch();
    if (!$org) jsonResponse(['success' => false, 'message' => 'Organization not found'], 404);

    // Delete old
    $oldPath = $org[$type] ?? '';
    if ($oldPath) umdc_delete_file($oldPath);

    // Save new
    $relPath = umdc_upload_file($file, 'campaigns', ['jpg','jpeg','png','webp'], 5 * 1024 * 1024);
    $pdo->prepare("UPDATE organizations SET $type=? WHERE org_id=?")->execute([$relPath, $org['org_id']]);
    auditLog($pdo, $user_id, "org_{$type}_updated");

    jsonResponse(['success' => true, 'url' => '/' . $relPath, 'message' => ucfirst(str_replace('_',' ',$type)) . ' updated!']);
} catch (RuntimeException $e) {
    jsonResponse(['success' => false, 'message' => $e->getMessage()], 422);
} catch (PDOException $e) {
    error_log('Org photo upload: ' . $e->getMessage());
    jsonResponse(['success' => false, 'message' => 'Upload failed.'], 500);
}
