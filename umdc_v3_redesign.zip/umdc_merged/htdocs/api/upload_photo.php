<?php
defined('UMDC_APP') or define('UMDC_APP', true);
require_once __DIR__ . '/../Config/security.php';
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../Config/upload_helper.php';
umdc_session_start();
requireAnyRole(['user','organization','admin']);
setSecureHeaders();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
}
csrf_check();

$user_id = currentUserId();
$file    = $_FILES['photo'] ?? null;

if (!$file) {
    jsonResponse(['success' => false, 'message' => 'No file uploaded'], 400);
}

try {
    // Delete old photo
    $old = $pdo->prepare("SELECT profile_photo FROM users WHERE user_id=?");
    $old->execute([$user_id]);
    $oldPath = $old->fetchColumn();
    if ($oldPath) umdc_delete_file($oldPath);

    // Save new photo (images only)
    $relPath = umdc_upload_file($file, 'profiles', ['jpg','jpeg','png','webp'], 3 * 1024 * 1024);

    $pdo->prepare("UPDATE users SET profile_photo=? WHERE user_id=?")->execute([$relPath, $user_id]);
    auditLog($pdo, $user_id, 'profile_photo_updated');

    jsonResponse(['success' => true, 'url' => '/' . $relPath, 'message' => 'Photo updated!']);
} catch (RuntimeException $e) {
    jsonResponse(['success' => false, 'message' => $e->getMessage()], 422);
} catch (PDOException $e) {
    error_log('Photo upload: ' . $e->getMessage());
    jsonResponse(['success' => false, 'message' => 'Upload failed. Please try again.'], 500);
}
