<?php
defined('UMDC_APP') or define('UMDC_APP', true);
require_once __DIR__ . '/../Config/security.php';
require_once __DIR__ . '/../Config/db.php';
umdc_session_start();
requireAnyRole(['user','organization','admin']);
setSecureHeaders();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
}
csrf_check();

$user_id = currentUserId();

// ── Personal fields ───────────────────────────────────────────
$fname   = sanitizeInput($_POST['first_name']   ?? '');
$lname   = sanitizeInput($_POST['last_name']    ?? '');
$email   = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
$phone   = sanitizeInput($_POST['phone']        ?? '');
$address = sanitizeInput($_POST['address']      ?? '');
$bio     = sanitizeInput($_POST['bio']          ?? '');
$dob     = $_POST['date_of_birth'] ?? '';
$gender  = in_array($_POST['gender'] ?? '', ['male','female','prefer_not_to_say','']) ? ($_POST['gender'] ?? '') : '';

// ── Social links ──────────────────────────────────────────────
$facebook  = sanitizeInput($_POST['facebook']  ?? '');
$twitter   = sanitizeInput($_POST['twitter']   ?? '');
$instagram = sanitizeInput($_POST['instagram'] ?? '');
$linkedin  = sanitizeInput($_POST['linkedin']  ?? '');
$website   = sanitizeInput($_POST['website']   ?? '');

// ── Validation ────────────────────────────────────────────────
if (!$fname || !$lname) jsonResponse(['success' => false, 'message' => 'First and last name are required'], 422);
if (!$email)            jsonResponse(['success' => false, 'message' => 'A valid email address is required'], 422);
if (strlen($bio) > 500) jsonResponse(['success' => false, 'message' => 'Bio must be 500 characters or less'], 422);

// Validate DOB
$dobVal = null;
if ($dob && preg_match('/^\d{4}-\d{2}-\d{2}$/', $dob)) {
    $dobVal = $dob;
}

// Normalise social URLs — strip leading @ for Twitter/Instagram
$twitter   = ltrim(trim($twitter), '@');
$instagram = ltrim(trim($instagram), '@');

// Enforce URL format for website/linkedin/facebook
foreach (['website', 'facebook', 'linkedin'] as $urlField) {
    $$urlField = trim($$urlField);
    if ($$urlField && !preg_match('#^https?://#i', $$urlField)) {
        $$urlField = 'https://' . $$urlField;
    }
}

try {
    // Unique email check
    $check = $pdo->prepare("SELECT user_id FROM users WHERE email=? AND user_id!=?");
    $check->execute([$email, $user_id]);
    if ($check->fetch()) jsonResponse(['success' => false, 'message' => 'That email is already in use by another account'], 409);

    // ── Update users ──────────────────────────────────────────
    $pdo->prepare("
        UPDATE users SET
            first_name=?, last_name=?, email=?, phone=?, address=?,
            bio=?, date_of_birth=?, gender=?,
            facebook=?, twitter=?, instagram=?, linkedin=?, website=?
        WHERE user_id=?
    ")->execute([
        $fname, $lname, $email,
        $phone   ?: null,
        $address ?: null,
        $bio     ?: null,
        $dobVal,
        $gender  ?: null,
        $facebook  ?: null,
        $twitter   ?: null,
        $instagram ?: null,
        $linkedin  ?: null,
        $website   ?: null,
        $user_id,
    ]);

    // ── Update org if org user ────────────────────────────────
    if (currentRole() === 'organization') {
        $orgName      = sanitizeInput($_POST['org_name']      ?? '');
        $orgEmail     = filter_var(trim($_POST['org_email']   ?? ''), FILTER_VALIDATE_EMAIL);
        $orgContact   = sanitizeInput($_POST['org_contact']   ?? '');
        $description  = sanitizeInput($_POST['description']   ?? '');
        $orgWebsite   = sanitizeInput($_POST['org_website']   ?? '');
        $orgMission   = sanitizeInput($_POST['mission']       ?? '');
        $orgFacebook  = sanitizeInput($_POST['org_facebook']  ?? '');
        $orgTwitter   = ltrim(trim(sanitizeInput($_POST['org_twitter']   ?? '')), '@');
        $orgInstagram = ltrim(trim(sanitizeInput($_POST['org_instagram'] ?? '')), '@');
        $foundedYear  = filter_var($_POST['founded_year'] ?? '', FILTER_VALIDATE_INT);

        if ($orgWebsite && !preg_match('#^https?://#i', $orgWebsite)) $orgWebsite = 'https://' . $orgWebsite;
        if ($orgFacebook && !preg_match('#^https?://#i', $orgFacebook)) $orgFacebook = 'https://' . $orgFacebook;

        if ($orgName) {
            $pdo->prepare("
                UPDATE organizations SET
                    org_name=?, org_email=?, org_contact=?, description=?,
                    website=?, mission=?, facebook=?, twitter=?, instagram=?,
                    founded_year=?
                WHERE user_id=?
            ")->execute([
                $orgName,
                $orgEmail    ?: null,
                $orgContact  ?: null,
                $description ?: null,
                $orgWebsite  ?: null,
                $orgMission  ?: null,
                $orgFacebook ?: null,
                $orgTwitter  ?: null,
                $orgInstagram?: null,
                $foundedYear ?: null,
                $user_id,
            ]);
        }
    }

    $_SESSION['user_name']  = trim("$fname $lname");
    $_SESSION['user_email'] = $email;
    auditLog($pdo, $user_id, 'profile_updated');

    jsonResponse(['success' => true, 'message' => 'Profile updated successfully!']);

} catch (PDOException $e) {
    error_log('update_profile: ' . $e->getMessage());
    jsonResponse(['success' => false, 'message' => 'Update failed. Please try again.'], 500);
}
