<?php
defined('UMDC_APP') or define('UMDC_APP', true);
require_once __DIR__ . '/../Config/security.php';
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../Config/upload_helper.php';
umdc_session_start();
requireAnyRole(['admin','user']);
setSecureHeaders();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
}
csrf_check();

$delivery_id = filter_var($_POST['delivery_id'] ?? 0, FILTER_VALIDATE_INT);
$action      = $_POST['action'] ?? '';
if (!$delivery_id) jsonResponse(['success' => false, 'message' => 'Delivery ID required'], 400);

try {
    // Fetch delivery
    $stmt = $pdo->prepare("SELECT dv.*, d.user_id AS donor_id FROM deliveries dv JOIN item_donations i ON dv.item_id=i.item_id JOIN donations d ON i.donation_id=d.donation_id WHERE dv.delivery_id=?");
    $stmt->execute([$delivery_id]);
    $delivery = $stmt->fetch();
    if (!$delivery) jsonResponse(['success' => false, 'message' => 'Delivery not found'], 404);

    // Update tracking code (admin)
    if ($action === 'update_tracking' && currentRole() === 'admin') {
        $code  = sanitizeInput($_POST['tracking_code'] ?? '');
        $notes = sanitizeInput($_POST['notes'] ?? '');
        $pickup_address  = sanitizeInput($_POST['pickup_address'] ?? '');
        $pickup_date     = $_POST['pickup_date'] ?? '';
        $est_delivery    = $_POST['estimated_delivery'] ?? '';
        $status = sanitizeInput($_POST['status'] ?? $delivery['status']);

        // Validate status
        $validStatus = ['requested','approved','in_transit','delivered','cancelled'];
        if (!in_array($status, $validStatus)) jsonResponse(['success'=>false,'message'=>'Invalid status'],400);

        $pdo->prepare("
            UPDATE deliveries SET
              tracking_code=?, notes=?, pickup_address=?,
              pickup_date=?, estimated_delivery=?, status=?,
              delivered_at = CASE WHEN ? = 'delivered' THEN NOW() ELSE delivered_at END
            WHERE delivery_id=?
        ")->execute([$code,$notes,$pickup_address,
            $pickup_date ?: null, $est_delivery ?: null,
            $status, $status, $delivery_id]);

        auditLog($pdo, currentUserId(), 'delivery_updated', 'delivery', $delivery_id);
        jsonResponse(['success'=>true,'message'=>'Delivery updated.']);

    // Upload proof photo (admin or donor)
    } elseif ($action === 'upload_proof') {
        // Only admin or the donor can upload proof
        if (currentRole() !== 'admin' && currentUserId() !== (int)$delivery['donor_id']) {
            jsonResponse(['success'=>false,'message'=>'Permission denied'],403);
        }
        $file = $_FILES['proof'] ?? null;
        if (!$file) jsonResponse(['success'=>false,'message'=>'No file uploaded'],400);

        if ($delivery['proof_photo']) umdc_delete_file($delivery['proof_photo']);
        $relPath = umdc_upload_file($file, 'delivery', ['jpg','jpeg','png','webp'], 5*1024*1024);
        $pdo->prepare("UPDATE deliveries SET proof_photo=?, status='delivered', delivered_at=NOW() WHERE delivery_id=?")
            ->execute([$relPath, $delivery_id]);

        auditLog($pdo, currentUserId(), 'delivery_proof_uploaded', 'delivery', $delivery_id);
        jsonResponse(['success'=>true,'url'=>'/'.$relPath,'message'=>'Proof uploaded and delivery marked as delivered!']);

    } else {
        jsonResponse(['success'=>false,'message'=>'Invalid action'],400);
    }

} catch (RuntimeException $e) {
    jsonResponse(['success'=>false,'message'=>$e->getMessage()],422);
} catch (PDOException $e) {
    error_log('Delivery update: '.$e->getMessage());
    jsonResponse(['success'=>false,'message'=>'Update failed.'],500);
}
