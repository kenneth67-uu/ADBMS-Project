<?php
defined('UMDC_APP') or define('UMDC_APP', true);
require_once __DIR__ . '/../Config/security.php';
require_once __DIR__ . '/../Config/db.php';
umdc_session_start();
requireAnyRole(['user','organization','admin']);
setSecureHeaders();
header('Content-Type: application/json');

$user_id = currentUserId();

try {
    $stmt = $pdo->prepare("
        SELECT u.user_id, u.first_name, u.last_name, u.email, u.phone, u.address,
               u.created_at, u.is_verified, u.status,
               COALESCE(u.profile_photo,'') AS profile_photo,
               COALESCE(u.bio,'')           AS bio,
               COALESCE(u.date_of_birth,'') AS date_of_birth,
               COALESCE(u.gender,'')        AS gender,
               COALESCE(u.facebook,'')      AS facebook,
               COALESCE(u.twitter,'')       AS twitter,
               COALESCE(u.instagram,'')     AS instagram,
               COALESCE(u.linkedin,'')      AS linkedin,
               COALESCE(u.website,'')       AS website,
               r.role_name,
               COALESCE(SUM(CASE WHEN d.status='completed' THEN d.amount ELSE 0 END),0) AS total_donated,
               COUNT(DISTINCT d.donation_id)  AS donation_count,
               COUNT(DISTINCT d.campaign_id)  AS campaigns_supported,
               MAX(d.created_at)              AS last_donation
        FROM users u
        JOIN roles r ON u.role_id = r.role_id
        LEFT JOIN donations d ON d.user_id = u.user_id
        WHERE u.user_id = ?
        GROUP BY u.user_id
    ");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if (!$user) jsonResponse(['success' => false, 'message' => 'User not found'], 404);

    // For org users, also fetch full org info
    $orgData = null;
    if ($user['role_name'] === 'organization') {
        $orgStmt = $pdo->prepare("
            SELECT org_id, org_name, org_email, org_contact, description,
                   verified, founded_year,
                   COALESCE(website,'')      AS website,
                   COALESCE(logo,'')         AS logo,
                   COALESCE(cover_photo,'')  AS cover_photo,
                   COALESCE(mission,'')      AS mission,
                   COALESCE(address,'')      AS org_address,
                   COALESCE(facebook,'')     AS facebook,
                   COALESCE(twitter,'')      AS twitter,
                   COALESCE(instagram,'')    AS instagram
            FROM organizations WHERE user_id=?
        ");
        $orgStmt->execute([$user_id]);
        $orgData = $orgStmt->fetch() ?: null;
    }

    $photoUrl = $user['profile_photo'] ? '/' . ltrim($user['profile_photo'], '/') : '';

    jsonResponse([
        'success' => true,
        'user'    => [
            'user_id'       => (int)$user['user_id'],
            'first_name'    => $user['first_name'],
            'last_name'     => $user['last_name'],
            'email'         => $user['email'],
            'phone'         => $user['phone'],
            'address'       => $user['address'],
            'bio'           => $user['bio'],
            'date_of_birth' => $user['date_of_birth'],
            'gender'        => $user['gender'],
            'facebook'      => $user['facebook'],
            'twitter'       => $user['twitter'],
            'instagram'     => $user['instagram'],
            'linkedin'      => $user['linkedin'],
            'website'       => $user['website'],
            'profile_photo' => $photoUrl,
            'is_verified'   => (bool)$user['is_verified'],
            'created_at'    => $user['created_at'],
            'role'          => $user['role_name'],
        ],
        'stats' => [
            'total_donated'       => (float)$user['total_donated'],
            'donation_count'      => (int)$user['donation_count'],
            'campaigns_supported' => (int)$user['campaigns_supported'],
            'last_donation'       => $user['last_donation'],
        ],
        'org' => $orgData,
    ]);
} catch (PDOException $e) {
    error_log('Profile API: ' . $e->getMessage());
    jsonResponse(['success' => false, 'message' => 'Unable to load profile'], 500);
}
