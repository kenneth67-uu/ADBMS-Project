<?php
// =============================================================
// UMDC – API: Get Notifications
// GET  /api/notifications.php          → paginated list + unread count
// POST /api/notifications.php?action=read      → mark one read
// POST /api/notifications.php?action=read_all  → mark all read
// =============================================================
defined('UMDC_APP') or define('UMDC_APP', true);
require_once __DIR__ . '/../Config/security.php';
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../Config/notifications.php';

umdc_session_start();
setSecureHeaders();
header('Content-Type: application/json');

if (!isLoggedIn()) {
    jsonResponse(['success' => false, 'message' => 'Unauthenticated'], 401);
}

$userId = currentUserId();
$action = $_GET['action'] ?? ($_POST['action'] ?? '');

// ── POST: mark read ──────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    if ($action === 'read_all') {
        Notifier::markRead($pdo, $userId);
        jsonResponse(['success' => true, 'unread' => 0]);
    }

    if ($action === 'read') {
        $id = filter_var($_POST['id'] ?? 0, FILTER_VALIDATE_INT);
        if ($id) Notifier::markRead($pdo, $userId, $id);
        jsonResponse(['success' => true, 'unread' => Notifier::getUnreadCount($pdo, $userId)]);
    }

    jsonResponse(['success' => false, 'message' => 'Unknown action'], 400);
}

// ── GET: fetch notifications ─────────────────────────────────
$page  = max(1, (int)($_GET['page'] ?? 1));
$limit = 15;
$offset = ($page - 1) * $limit;

$stmt = $pdo->prepare("
    SELECT notification_id, message, type, link, icon, priority,
           is_read, read_at, created_at, expires_at
    FROM notifications
    WHERE user_id = ?
      AND (expires_at IS NULL OR expires_at > NOW())
    ORDER BY created_at DESC
    LIMIT ? OFFSET ?
");
$stmt->execute([$userId, $limit, $offset]);
$rows = $stmt->fetchAll();

// Format for frontend
$items = array_map(function($row) {
    return [
        'id'         => (int)$row['notification_id'],
        'message'    => $row['message'],
        'type'       => $row['type'],
        'link'       => $row['link'] ?? '',
        'icon'       => $row['icon'] ?? 'fa-bell',
        'priority'   => $row['priority'],
        'is_read'    => (bool)$row['is_read'],
        'time_ago'   => self_time_ago($row['created_at']),
        'created_at' => $row['created_at'],
    ];
}, $rows);

$unread = Notifier::getUnreadCount($pdo, $userId);
$total  = (int)$pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id=? AND (expires_at IS NULL OR expires_at>NOW())")->execute([$userId]) ? 0 : 0;
$countStmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id=? AND (expires_at IS NULL OR expires_at > NOW())");
$countStmt->execute([$userId]);
$total = (int)$countStmt->fetchColumn();

jsonResponse([
    'success'   => true,
    'items'     => $items,
    'unread'    => $unread,
    'total'     => $total,
    'page'      => $page,
    'has_more'  => ($offset + $limit) < $total,
]);

// ── Helper ───────────────────────────────────────────────────
function self_time_ago(string $datetime): string {
    $diff = time() - strtotime($datetime);
    if ($diff < 60)     return 'just now';
    if ($diff < 3600)   return floor($diff/60)   . 'm ago';
    if ($diff < 86400)  return floor($diff/3600)  . 'h ago';
    if ($diff < 604800) return floor($diff/86400) . 'd ago';
    return date('M j', strtotime($datetime));
}
