<?php
defined('UMDC_APP') or define('UMDC_APP', true);
require_once __DIR__ . '/../Config/security.php';
require_once __DIR__ . '/../Config/db.php';
umdc_session_start();

$is_logged_in = isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
$user_name    = $is_logged_in ? e($_SESSION['user_name'] ?? '') : '';
$user_role    = $is_logged_in ? ($_SESSION['role'] ?? 'user') : '';
$user_initials= $is_logged_in ? strtoupper(substr($user_name, 0, 2)) : '';
$dash_link    = match($user_role) {
    'admin'        => '/dashboard/admin.php?_sess=UMDC_ADMIN',
    'organization' => '/dashboard/organization.php?_sess=UMDC_ORG',
    default        => '/dashboard/user.php?_sess=UMDC_USER',
};

// ── Live stats from DB ────────────────────────────────────────
try {
    $stat_raised    = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM donations WHERE status='completed' AND donation_type='cash'")->fetchColumn();
    $stat_campaigns = (int)$pdo->query("SELECT COUNT(*) FROM campaigns WHERE status IN ('active','approved')")->fetchColumn();
    $stat_donors    = (int)$pdo->query("SELECT COUNT(DISTINCT user_id) FROM donations WHERE status='completed'")->fetchColumn();
    $stat_orgs      = (int)$pdo->query("SELECT COUNT(*) FROM organizations WHERE verified=1")->fetchColumn();
    $live_campaigns = $pdo->query("
        SELECT c.campaign_id, c.title, c.category, c.target_amount, c.current_amount,
               c.end_date, c.campaign_image, o.org_name, o.verified,
               COUNT(d.donation_id) AS donor_count
        FROM campaigns c
        JOIN organizations o ON c.org_id = o.org_id
        LEFT JOIN donations d ON d.campaign_id = c.campaign_id AND d.status='completed'
        WHERE c.status IN ('active','approved')
        GROUP BY c.campaign_id
        ORDER BY c.is_featured DESC, c.current_amount DESC
        LIMIT 6
    ")->fetchAll();
} catch (Exception $e) {
    $stat_raised=$stat_campaigns=$stat_donors=$stat_orgs=0;
    $live_campaigns=[];
}

function fmt_raised(float $n): string {
    if ($n >= 1_000_000) return '₱' . number_format($n/1_000_000, 1) . 'M';
    if ($n >= 1_000)     return '₱' . number_format($n/1_000, 1)     . 'K';
    return '₱' . number_format($n, 0);
}
$cat_colors = [
    'Environment'=>'#22d3a5','Education'=>'#6C72FF','Health'=>'#f87171',
    'Disaster Relief'=>'#FDB52A','Livelihood'=>'#57C3FF','Infrastructure'=>'#9A91FB',
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>UMDC — Unified Movement for Donation & Charity</title>
<meta name="description" content="UMDC connects donors with verified Philippine organizations. Donate cash, items, or services — and track every peso with full transparency.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700;9..40,800&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
/* ── Reset ── */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
:root{
  --pp:#6C72FF;--pv:#9A91FB;--pc:#57C3FF;--pa:#FDB52A;
  --n9:#080F25;--n8:#101935;--n7:#212C4D;--n6:#37446B;
  --s5:#7E89AC;--s4:#AEB9E1;--s3:#D1DBF9;
  --success:#22d3a5;--danger:#f87171;--warning:#FDB52A;
  --grad:linear-gradient(135deg,#6C72FF 0%,#9A91FB 100%);
  --font:'DM Sans',-apple-system,sans-serif;
  --mono:'DM Mono','Courier New',monospace;
  --r12:12px;--r18:18px;--r24:24px;
  --shadow:0 8px 32px rgba(0,0,0,.45);
  --border:rgba(174,185,225,.1);
}
html{scroll-behavior:smooth;}
body{background:var(--n9);color:#fff;font-family:var(--font);-webkit-font-smoothing:antialiased;line-height:1.6;}
a{color:var(--pp);text-decoration:none;}
a:hover{color:var(--pv);}
img{max-width:100%;display:block;}

/* ── Navbar ── */
.navbar{
  position:sticky;top:0;z-index:200;
  background:rgba(8,15,37,.85);
  backdrop-filter:blur(20px);
  border-bottom:1px solid var(--border);
  padding:0 40px;
  height:66px;
  display:flex;align-items:center;gap:24px;
}
.nav-brand{
  display:flex;align-items:center;gap:10px;
  font-weight:800;font-size:1.1rem;letter-spacing:-.3px;
  white-space:nowrap;color:#fff;text-decoration:none;
}
.nav-logo-icon{
  width:34px;height:34px;background:var(--grad);border-radius:9px;
  display:flex;align-items:center;justify-content:center;
  font-size:.85rem;color:#fff;flex-shrink:0;
  box-shadow:0 0 20px rgba(108,114,255,.3);
}
.nav-links{
  display:flex;align-items:center;gap:4px;margin-left:24px;flex:1;
}
.nav-links a{
  padding:7px 14px;border-radius:var(--r12);
  color:var(--s4);font-size:.88rem;font-weight:500;
  transition:all .15s;
}
.nav-links a:hover{background:rgba(108,114,255,.1);color:#fff;}
.nav-right{display:flex;align-items:center;gap:10px;margin-left:auto;}

/* User pill (logged in) */
.nav-user-pill{
  display:flex;align-items:center;gap:10px;
  padding:5px 14px 5px 5px;
  background:rgba(108,114,255,.12);
  border:1px solid rgba(108,114,255,.25);
  border-radius:40px;
  cursor:pointer;
  transition:all .15s;
  text-decoration:none;
  color:#fff;
}
.nav-user-pill:hover{background:rgba(108,114,255,.2);color:#fff;}
.nav-user-avatar{
  width:30px;height:30px;border-radius:50%;
  background:var(--grad);
  display:flex;align-items:center;justify-content:center;
  font-size:.7rem;font-weight:800;color:#fff;
  flex-shrink:0;
}
.nav-user-name{font-size:.82rem;font-weight:600;max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.nav-user-role{font-size:.65rem;color:var(--s4);text-transform:capitalize;}

.btn-nav-primary{
  padding:8px 18px;background:var(--grad);color:#fff;
  border-radius:var(--r12);font-weight:700;font-size:.85rem;
  border:none;cursor:pointer;transition:all .15s;
  box-shadow:0 0 20px rgba(108,114,255,.25);
}
.btn-nav-primary:hover{transform:translateY(-1px);box-shadow:0 0 30px rgba(108,114,255,.4);color:#fff;}
.btn-nav-ghost{
  padding:8px 18px;background:transparent;color:var(--s4);
  border:1px solid var(--border);border-radius:var(--r12);
  font-weight:600;font-size:.85rem;transition:all .15s;
}
.btn-nav-ghost:hover{border-color:rgba(108,114,255,.4);color:#fff;}

/* ── Hero ── */
.hero{
  min-height:calc(100vh - 66px);
  display:flex;align-items:center;
  padding:80px 40px;
  position:relative;
  overflow:hidden;
  gap:60px;
}
.hero::before{
  content:'';
  position:absolute;inset:0;
  background:
    radial-gradient(ellipse 60% 60% at 70% 50%, rgba(108,114,255,.12) 0%, transparent 70%),
    radial-gradient(ellipse 40% 50% at 20% 80%, rgba(87,195,255,.08) 0%, transparent 70%);
  pointer-events:none;
}
.hero-left{flex:1;max-width:600px;position:relative;z-index:1;}
.hero-badge{
  display:inline-flex;align-items:center;gap:8px;
  padding:7px 16px;
  background:rgba(108,114,255,.12);
  border:1px solid rgba(108,114,255,.3);
  border-radius:40px;
  font-size:.78rem;font-weight:700;
  color:var(--pp);margin-bottom:28px;
}
.hero h1{
  font-size:clamp(2.4rem,5vw,4rem);
  font-weight:800;line-height:1.1;
  letter-spacing:-2px;
  margin-bottom:20px;
  color:#fff;
}
.hero h1 .grad-text{
  background:var(--grad);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
}
.hero-desc{
  font-size:1.05rem;color:var(--s4);line-height:1.75;
  max-width:500px;margin-bottom:36px;
}
.hero-actions{display:flex;gap:14px;flex-wrap:wrap;margin-bottom:48px;}
.btn-hero-primary{
  display:inline-flex;align-items:center;gap:9px;
  padding:15px 32px;background:var(--grad);color:#fff;
  border-radius:var(--r18);font-weight:700;font-size:1rem;
  box-shadow:0 8px 32px rgba(108,114,255,.35);
  transition:all .2s;border:none;cursor:pointer;
}
.btn-hero-primary:hover{transform:translateY(-2px);box-shadow:0 12px 40px rgba(108,114,255,.5);color:#fff;}
.btn-hero-ghost{
  display:inline-flex;align-items:center;gap:9px;
  padding:15px 32px;background:rgba(255,255,255,.05);
  color:var(--s3);border:1px solid var(--border);
  border-radius:var(--r18);font-weight:600;font-size:1rem;
  transition:all .2s;
}
.btn-hero-ghost:hover{background:rgba(255,255,255,.1);color:#fff;border-color:rgba(174,185,225,.25);}

.hero-trust{display:flex;align-items:center;gap:16px;flex-wrap:wrap;}
.hero-trust-item{display:flex;align-items:center;gap:7px;font-size:.82rem;color:var(--s5);}
.hero-trust-item i{color:var(--success);font-size:.75rem;}

.hero-right{flex:0 0 420px;position:relative;z-index:1;}
.hero-card{
  background:var(--n8);border:1px solid var(--border);
  border-radius:var(--r24);padding:28px;
  box-shadow:var(--shadow),0 0 60px rgba(108,114,255,.1);
}
.hero-card-header{display:flex;align-items:center;gap:12px;margin-bottom:20px;}
.hero-card-icon{
  width:44px;height:44px;background:var(--grad);border-radius:12px;
  display:flex;align-items:center;justify-content:center;
  font-size:1.1rem;color:#fff;flex-shrink:0;
}
.hero-mini-stat{
  display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-top:16px;
}
.hms-item{
  background:var(--n7);border-radius:var(--r12);padding:12px;text-align:center;
  border:1px solid var(--border);
}
.hms-val{font-size:1.15rem;font-weight:800;margin-bottom:2px;}
.hms-lbl{font-size:.62rem;color:var(--s5);text-transform:uppercase;letter-spacing:.6px;}

/* Floating mini cards */
.float-card{
  position:absolute;
  background:var(--n8);border:1px solid rgba(174,185,225,.15);
  border-radius:var(--r12);padding:10px 14px;
  display:flex;align-items:center;gap:8px;
  font-size:.78rem;font-weight:600;
  box-shadow:var(--shadow);
  animation:floatY 4s ease-in-out infinite;
  white-space:nowrap;
}
@keyframes floatY{0%,100%{transform:translateY(0);}50%{transform:translateY(-8px);}}

/* ── Stats bar ── */
.stats-bar{
  background:var(--n8);
  border-top:1px solid var(--border);
  border-bottom:1px solid var(--border);
  padding:32px 40px;
  display:grid;
  grid-template-columns:repeat(4,1fr);
  gap:20px;
  text-align:center;
}
.stat-val{
  font-size:2rem;font-weight:800;letter-spacing:-1.5px;
  background:var(--grad);-webkit-background-clip:text;-webkit-text-fill-color:transparent;
  margin-bottom:4px;
  font-family:var(--mono);
}
.stat-lbl{font-size:.78rem;color:var(--s5);text-transform:uppercase;letter-spacing:.8px;font-weight:600;}

/* ── Section base ── */
.section{padding:90px 40px;}
.section-alt{background:var(--n8);}
.sec-eyebrow{
  display:inline-flex;align-items:center;gap:6px;
  font-size:.72rem;font-weight:700;text-transform:uppercase;
  letter-spacing:1.5px;color:var(--pp);
  background:rgba(108,114,255,.1);border:1px solid rgba(108,114,255,.2);
  padding:5px 14px;border-radius:40px;margin-bottom:16px;
}
.section h2{font-size:clamp(1.8rem,3vw,2.6rem);font-weight:800;letter-spacing:-1px;margin-bottom:12px;}
.section .sec-desc{font-size:1rem;color:var(--s4);max-width:560px;line-height:1.7;margin-bottom:48px;}

/* ── Campaign cards ── */
.campaigns-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;}
.camp-card{
  background:var(--n8);border:1px solid var(--border);border-radius:var(--r18);
  overflow:hidden;transition:all .2s;cursor:pointer;
}
.camp-card:hover{
  border-color:rgba(108,114,255,.35);transform:translateY(-4px);
  box-shadow:0 20px 50px rgba(0,0,0,.4),0 0 30px rgba(108,114,255,.1);
}
.camp-thumb{
  height:180px;background:var(--n7);position:relative;overflow:hidden;
  display:flex;align-items:center;justify-content:center;
  font-size:2.5rem;
}
.camp-thumb img{width:100%;height:100%;object-fit:cover;}
.camp-cat-badge{
  position:absolute;top:12px;left:12px;
  padding:4px 10px;border-radius:20px;font-size:.67rem;font-weight:800;
  text-transform:uppercase;letter-spacing:.5px;
}
.camp-body{padding:18px 20px;}
.camp-org-row{display:flex;align-items:center;gap:6px;margin-bottom:8px;}
.camp-org-name{font-size:.75rem;color:var(--s5);font-weight:500;}
.camp-verified-icon{color:var(--pp);font-size:.7rem;}
.camp-title{font-size:.95rem;font-weight:700;color:#fff;margin-bottom:12px;line-height:1.4;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
.camp-progress-bar{height:5px;background:var(--n7);border-radius:3px;overflow:hidden;margin-bottom:10px;}
.camp-progress-fill{height:100%;background:var(--grad);border-radius:3px;transition:width .5s ease;}
.camp-footer{display:flex;justify-content:space-between;align-items:center;}
.camp-raised{font-size:.82rem;font-weight:800;color:var(--success);font-family:var(--mono);}
.camp-target{font-size:.72rem;color:var(--s5);}
.camp-pct-badge{
  font-size:.7rem;font-weight:800;padding:3px 8px;border-radius:20px;
  background:rgba(34,211,165,.1);color:var(--success);
}

/* ── How it works ── */
.steps-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:20px;position:relative;}
.steps-grid::before{
  content:'';position:absolute;top:32px;left:12%;right:12%;
  height:2px;background:linear-gradient(90deg,var(--pp),var(--pv));
  opacity:.2;z-index:0;
}
.step-card{
  background:var(--n9);border:1px solid var(--border);border-radius:var(--r18);
  padding:28px 20px;text-align:center;position:relative;z-index:1;
  transition:all .2s;
}
.step-card:hover{border-color:rgba(108,114,255,.3);transform:translateY(-3px);}
.step-num{
  position:absolute;top:-1px;right:14px;
  font-size:.62rem;font-weight:800;color:var(--pp);
  background:rgba(108,114,255,.1);border:1px solid rgba(108,114,255,.2);
  padding:3px 8px;border-radius:0 var(--r12) 0 var(--r12);
}
.step-icon{
  width:58px;height:58px;background:var(--grad);border-radius:50%;
  display:flex;align-items:center;justify-content:center;
  font-size:1.2rem;color:#fff;margin:0 auto 16px;
  box-shadow:0 0 24px rgba(108,114,255,.3);
}
.step-title{font-weight:700;font-size:.95rem;margin-bottom:8px;}
.step-desc{font-size:.83rem;color:var(--s5);line-height:1.6;}

/* ── Features ── */
.features-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px;}
.feat-card{
  background:var(--n9);border:1px solid var(--border);border-radius:var(--r18);
  padding:26px;transition:all .2s;
}
.feat-card:hover{border-color:rgba(108,114,255,.3);transform:translateY(-3px);}
.feat-icon{
  width:44px;height:44px;background:rgba(108,114,255,.1);border-radius:12px;
  display:flex;align-items:center;justify-content:center;
  font-size:1rem;color:var(--pp);margin-bottom:16px;
}
.feat-title{font-weight:700;font-size:.95rem;margin-bottom:8px;}
.feat-desc{font-size:.83rem;color:var(--s5);line-height:1.6;}

/* ── CTA Strip ── */
.cta-strip{
  background:var(--n8);
  padding:80px 40px;text-align:center;
  position:relative;overflow:hidden;
}
.cta-strip::before{
  content:'';position:absolute;inset:0;
  background:radial-gradient(ellipse 60% 80% at 50% 50%,rgba(108,114,255,.1) 0%,transparent 70%);
  pointer-events:none;
}
.cta-strip h2{font-size:2.2rem;font-weight:800;letter-spacing:-1px;margin-bottom:12px;}
.cta-strip p{color:var(--s4);margin-bottom:36px;font-size:1rem;}
.cta-btns{display:flex;gap:14px;justify-content:center;flex-wrap:wrap;}
.btn-cta-white{
  display:inline-flex;align-items:center;gap:9px;
  padding:14px 28px;background:#fff;color:var(--n9);
  border-radius:var(--r18);font-weight:800;font-size:.95rem;
  transition:all .2s;border:none;cursor:pointer;
}
.btn-cta-white:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(255,255,255,.15);color:var(--n9);}
.btn-cta-outline{
  display:inline-flex;align-items:center;gap:9px;
  padding:14px 28px;background:transparent;color:#fff;
  border:2px solid rgba(255,255,255,.3);
  border-radius:var(--r18);font-weight:700;font-size:.95rem;
  transition:all .2s;
}
.btn-cta-outline:hover{background:rgba(255,255,255,.08);color:#fff;border-color:rgba(255,255,255,.5);}

/* ── Footer ── */
.footer{
  background:var(--n9);border-top:1px solid var(--border);
  padding:60px 40px 30px;
}
.footer-grid{display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:48px;margin-bottom:48px;}
.footer-brand-name{font-size:1.05rem;font-weight:800;letter-spacing:-.3px;margin-bottom:10px;display:flex;align-items:center;gap:8px;}
.footer-brand-desc{font-size:.83rem;color:var(--s5);line-height:1.7;max-width:260px;}
.footer-col h5{font-size:.72rem;font-weight:800;text-transform:uppercase;letter-spacing:1.2px;color:var(--s4);margin-bottom:14px;}
.footer-col a{display:block;font-size:.83rem;color:var(--s5);margin-bottom:8px;transition:color .15s;}
.footer-col a:hover{color:#fff;}
.footer-bottom{
  display:flex;justify-content:space-between;align-items:center;
  padding-top:24px;border-top:1px solid var(--border);
  font-size:.78rem;color:var(--s5);flex-wrap:wrap;gap:8px;
}

/* ── Mobile nav hamburger ── */
.nav-hamburger{display:none;background:none;border:none;color:var(--s4);font-size:1.2rem;cursor:pointer;padding:8px;}
.mobile-nav-overlay{
  display:none;position:fixed;inset:0;z-index:500;
  background:var(--n8);flex-direction:column;padding:20px;gap:8px;
}
.mobile-nav-overlay.open{display:flex;}
.mob-nav-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;}
.mob-nav-link{display:flex;align-items:center;gap:12px;padding:14px 16px;border-radius:var(--r12);color:var(--s4);font-weight:600;transition:all .15s;}
.mob-nav-link:hover{background:rgba(108,114,255,.1);color:#fff;}
.mob-nav-link i{width:18px;text-align:center;color:var(--pp);}

/* ── Responsive ── */
@media(max-width:1100px){
  .hero{flex-direction:column;align-items:flex-start;gap:40px;min-height:auto;padding-top:60px;}
  .hero-right{flex:none;width:100%;max-width:480px;}
  .campaigns-grid{grid-template-columns:repeat(2,1fr);}
  .steps-grid{grid-template-columns:repeat(2,1fr);}
  .steps-grid::before{display:none;}
  .features-grid{grid-template-columns:repeat(2,1fr);}
  .footer-grid{grid-template-columns:1fr 1fr;gap:32px;}
}
@media(max-width:768px){
  .navbar{padding:0 16px;}
  .nav-links{display:none;}
  .nav-hamburger{display:block;}
  .hero{padding:40px 16px 60px;}
  .stats-bar{grid-template-columns:1fr 1fr;padding:24px 16px;gap:16px;}
  .section{padding:60px 16px;}
  .campaigns-grid{grid-template-columns:1fr;}
  .steps-grid{grid-template-columns:1fr;}
  .features-grid{grid-template-columns:1fr;}
  .cta-strip{padding:60px 16px;}
  .footer{padding:48px 16px 24px;}
  .footer-grid{grid-template-columns:1fr;gap:28px;}
  .footer-bottom{flex-direction:column;text-align:center;}
}
</style>
</head>
<body>

<!-- ── Mobile Nav Overlay ─────────────────────────────────── -->
<div class="mobile-nav-overlay" id="mobileNav">
  <div class="mob-nav-header">
    <div class="nav-brand" style="font-size:1rem;">
      <div class="nav-logo-icon"><i class="fas fa-shield-halved"></i></div>
      UMDC
    </div>
    <button onclick="document.getElementById('mobileNav').classList.remove('open')"
            style="background:none;border:none;color:var(--s4);font-size:1.3rem;cursor:pointer;">
      <i class="fas fa-xmark"></i>
    </button>
  </div>
  <a href="#campaigns"   class="mob-nav-link" onclick="document.getElementById('mobileNav').classList.remove('open')"><i class="fas fa-bullhorn"></i> Campaigns</a>
  <a href="#how-it-works"class="mob-nav-link" onclick="document.getElementById('mobileNav').classList.remove('open')"><i class="fas fa-list-check"></i> How It Works</a>
  <a href="#transparency"class="mob-nav-link" onclick="document.getElementById('mobileNav').classList.remove('open')"><i class="fas fa-shield-alt"></i> Features</a>
  <a href="#about"       class="mob-nav-link" onclick="document.getElementById('mobileNav').classList.remove('open')"><i class="fas fa-info-circle"></i> About</a>
  <div style="margin-top:auto;display:flex;flex-direction:column;gap:10px;padding-top:16px;border-top:1px solid var(--border);">
    <?php if ($is_logged_in): ?>
    <a href="<?= $dash_link ?>" class="btn-hero-primary" style="justify-content:center;"><i class="fas fa-gauge-high"></i> Go to Dashboard</a>
    <?php else: ?>
    <a href="/Auth/login.php" class="btn-hero-ghost" style="justify-content:center;color:var(--s3);"><i class="fas fa-sign-in-alt"></i> Sign In</a>
    <a href="/Auth/register.php" class="btn-hero-primary" style="justify-content:center;"><i class="fas fa-heart"></i> Get Started</a>
    <?php endif; ?>
  </div>
</div>

<!-- ── Navbar ─────────────────────────────────────────────── -->
<header class="navbar">
  <a href="/public/index.php" class="nav-brand">
    <div class="nav-logo-icon"><i class="fas fa-shield-halved"></i></div>
    UMDC
  </a>
  <nav class="nav-links">
    <a href="#campaigns">Campaigns</a>
    <a href="#how-it-works">How It Works</a>
    <a href="#transparency">Features</a>
    <a href="#about">About</a>
  </nav>
  <div class="nav-right">
    <?php if ($is_logged_in): ?>
      <a href="<?= $dash_link ?>" class="nav-user-pill">
        <div class="nav-user-avatar"><?= $user_initials ?></div>
        <div>
          <div class="nav-user-name"><?= $user_name ?></div>
          <div class="nav-user-role"><?= $user_role ?></div>
        </div>
        <i class="fas fa-chevron-right" style="font-size:.65rem;color:var(--s5);margin-left:4px;"></i>
      </a>
      <a href="<?= $dash_link ?>" class="btn-nav-primary"><i class="fas fa-gauge-high"></i> Dashboard</a>
    <?php else: ?>
      <a href="/Auth/login.php"    class="btn-nav-ghost">Sign In</a>
      <a href="/Auth/register.php" class="btn-nav-primary"><i class="fas fa-heart"></i> Get Started</a>
    <?php endif; ?>
    <button class="nav-hamburger" onclick="document.getElementById('mobileNav').classList.add('open')">
      <i class="fas fa-bars"></i>
    </button>
  </div>
</header>

<!-- ── Hero ───────────────────────────────────────────────── -->
<section class="hero">
  <div class="hero-left">
    <div class="hero-badge"><i class="fas fa-shield-alt"></i> Verified &amp; Transparent Giving</div>
    <h1>Give With<br><span class="grad-text">Purpose.</span><br>Track Every Peso.</h1>
    <p class="hero-desc">
      UMDC connects Filipino donors with verified NGOs running real campaigns.
      Donate cash, items, or services — and follow every peso with blockchain-backed transparency.
    </p>
    <div class="hero-actions">
      <?php if ($is_logged_in): ?>
        <a href="<?= $dash_link ?>" class="btn-hero-primary"><i class="fas fa-gauge-high"></i> Go to Your Dashboard</a>
        <a href="#campaigns" class="btn-hero-ghost"><i class="fas fa-search"></i> Browse Campaigns</a>
      <?php else: ?>
        <a href="/Auth/register.php" class="btn-hero-primary"><i class="fas fa-heart"></i> Start Donating — Free</a>
        <a href="#campaigns" class="btn-hero-ghost"><i class="fas fa-search"></i> Browse Campaigns</a>
      <?php endif; ?>
    </div>
    <div class="hero-trust">
      <div class="hero-trust-item"><i class="fas fa-circle-check"></i> No platform fee</div>
      <div class="hero-trust-item"><i class="fas fa-circle-check"></i> SEC-verified orgs</div>
      <div class="hero-trust-item"><i class="fas fa-circle-check"></i> Real-time tracking</div>
      <div class="hero-trust-item"><i class="fas fa-circle-check"></i> Digital receipts</div>
    </div>
  </div>

  <div class="hero-right">
    <!-- Floating accents -->
    <div class="float-card" style="top:-18px;right:20px;animation-delay:.5s;">
      <i class="fas fa-circle-check" style="color:var(--success);"></i>
      Donation confirmed!
    </div>
    <div class="float-card" style="bottom:60px;left:-30px;animation-delay:1.2s;font-size:.72rem;">
      <i class="fas fa-shield-halved" style="color:var(--pp);"></i>
      SEC Verified Org
    </div>

    <div class="hero-card">
      <div class="hero-card-header">
        <div class="hero-card-icon"><i class="fas fa-hand-holding-heart"></i></div>
        <div>
          <div style="font-weight:700;font-size:.95rem;">Live Donation Activity</div>
          <div style="font-size:.73rem;color:var(--s5);"><?= date('F j, Y') ?></div>
        </div>
        <div style="margin-left:auto;font-weight:800;color:var(--success);font-family:var(--mono);font-size:1.05rem;">
          <?= fmt_raised($stat_raised) ?>
        </div>
      </div>

      <?php if (!empty($live_campaigns)): $fc = $live_campaigns[0];
        $fpct = $fc['target_amount']>0 ? min(100,round(($fc['current_amount']/$fc['target_amount'])*100)) : 0;
      ?>
      <div style="background:var(--n7);border-radius:var(--r12);padding:16px;margin-bottom:14px;border:1px solid var(--border);">
        <div style="font-size:.73rem;color:var(--s5);margin-bottom:6px;"><?= e($fc['title']) ?></div>
        <div class="camp-progress-bar"><div class="camp-progress-fill" style="width:<?= $fpct ?>%;"></div></div>
        <div style="display:flex;justify-content:space-between;font-size:.78rem;margin-top:6px;">
          <span style="color:var(--success);font-weight:800;font-family:var(--mono);"><?= fmt_raised((float)$fc['current_amount']) ?></span>
          <span style="color:var(--s5);">of <?= fmt_raised((float)$fc['target_amount']) ?></span>
        </div>
      </div>
      <?php endif; ?>

      <div class="hero-mini-stat">
        <div class="hms-item">
          <div class="hms-val" style="color:var(--pp);"><?= $stat_donors ?></div>
          <div class="hms-lbl">Donors</div>
        </div>
        <div class="hms-item">
          <div class="hms-val" style="color:var(--success);"><?= $stat_campaigns ?></div>
          <div class="hms-lbl">Active</div>
        </div>
        <div class="hms-item">
          <div class="hms-val" style="color:var(--pa);"><?= $stat_orgs ?></div>
          <div class="hms-lbl">Verified Orgs</div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ── Stats Bar ──────────────────────────────────────────── -->
<div class="stats-bar">
  <div>
    <div class="stat-val" id="c-raised">₱0</div>
    <div class="stat-lbl">Total Raised</div>
  </div>
  <div>
    <div class="stat-val" id="c-campaigns">0</div>
    <div class="stat-lbl">Active Campaigns</div>
  </div>
  <div>
    <div class="stat-val" id="c-donors">0</div>
    <div class="stat-lbl">Donors</div>
  </div>
  <div>
    <div class="stat-val" id="c-orgs">0</div>
    <div class="stat-lbl">Verified Organizations</div>
  </div>
</div>

<!-- ── Active Campaigns ──────────────────────────────────── -->
<section class="section" id="campaigns">
  <div style="max-width:1200px;margin:0 auto;">
    <div class="sec-eyebrow"><i class="fas fa-fire"></i> Live Campaigns</div>
    <h2>Support a Cause Today</h2>
    <p class="sec-desc">Every campaign is verified. Every peso is tracked. Browse and donate in minutes.</p>

    <div class="campaigns-grid">
      <?php foreach ($live_campaigns as $c):
        $pct = $c['target_amount']>0 ? min(100,round(($c['current_amount']/$c['target_amount'])*100)) : 0;
        $cat = $c['category'] ?? 'General';
        $cat_color = $cat_colors[$cat] ?? '#6C72FF';
        $days_left = $c['end_date'] ? max(0,(int)ceil((strtotime($c['end_date'])-time())/86400)) : null;
        $emoji_map = ['Environment'=>'🌿','Education'=>'📚','Health'=>'🏥','Disaster Relief'=>'🆘','Livelihood'=>'🛠️','Infrastructure'=>'⚡'];
        $emoji = $emoji_map[$cat] ?? '❤️';
      ?>
      <a href="<?= $is_logged_in ? $dash_link : '/Auth/register.php' ?>" class="camp-card">
        <div class="camp-thumb">
          <?php if (!empty($c['campaign_image'])): ?>
          <img src="/<?= ltrim(e($c['campaign_image']),'/') ?>" alt="<?= e($c['title']) ?>" loading="lazy">
          <?php else: ?>
          <span><?= $emoji ?></span>
          <?php endif; ?>
          <span class="camp-cat-badge" style="background:<?= $cat_color ?>22;color:<?= $cat_color ?>;border:1px solid <?= $cat_color ?>44;">
            <?= e($cat) ?>
          </span>
          <?php if ($days_left !== null && $days_left <= 7): ?>
          <span style="position:absolute;top:12px;right:12px;background:rgba(248,113,113,.15);color:var(--danger);border:1px solid rgba(248,113,113,.3);border-radius:20px;padding:3px 9px;font-size:.65rem;font-weight:800;">
            <?= $days_left === 0 ? 'Ends today' : $days_left.'d left' ?>
          </span>
          <?php endif; ?>
        </div>
        <div class="camp-body">
          <div class="camp-org-row">
            <span class="camp-org-name"><?= e($c['org_name']) ?></span>
            <?php if ($c['verified']): ?><i class="fas fa-circle-check camp-verified-icon"></i><?php endif; ?>
          </div>
          <div class="camp-title"><?= e($c['title']) ?></div>
          <div class="camp-progress-bar"><div class="camp-progress-fill" style="width:<?= $pct ?>%;<?= $pct>=100?'background:var(--success);':'' ?>"></div></div>
          <div class="camp-footer">
            <div>
              <div class="camp-raised"><?= fmt_raised((float)$c['current_amount']) ?></div>
              <div class="camp-target">of <?= fmt_raised((float)$c['target_amount']) ?> · <?= $c['donor_count'] ?> donors</div>
            </div>
            <span class="camp-pct-badge"><?= $pct ?>%</span>
          </div>
        </div>
      </a>
      <?php endforeach; ?>

      <?php if (empty($live_campaigns)): ?>
      <div style="grid-column:1/-1;text-align:center;padding:60px;color:var(--s5);">
        <i class="fas fa-bullhorn" style="font-size:2.5rem;opacity:.3;display:block;margin-bottom:12px;"></i>
        No active campaigns yet — check back soon!
      </div>
      <?php endif; ?>
    </div>

    <div style="text-align:center;margin-top:40px;">
      <?php if ($is_logged_in): ?>
      <a href="<?= $dash_link ?>" class="btn-hero-primary"><i class="fas fa-gauge-high"></i> View All Campaigns in Dashboard</a>
      <?php else: ?>
      <a href="/Auth/register.php" class="btn-hero-primary"><i class="fas fa-plus"></i> Sign Up to Donate &amp; See All</a>
      <?php endif; ?>
    </div>
  </div>
</section>

<!-- ── How It Works ──────────────────────────────────────── -->
<section class="section section-alt" id="how-it-works">
  <div style="max-width:1200px;margin:0 auto;">
    <div class="sec-eyebrow"><i class="fas fa-list-check"></i> Process</div>
    <h2>Simple, Transparent Giving</h2>
    <p class="sec-desc">From registration to impact report — every step is designed around trust.</p>
    <div class="steps-grid">
      <?php
      $steps = [
        ['1','fa-user-plus','Create Account','Register as a donor or organization in seconds. No fees, no barriers.'],
        ['2','fa-search','Find a Campaign','Browse verified campaigns by category, organization, or urgency.'],
        ['3','fa-hand-holding-heart','Donate Anything','Give cash via PayMongo, drop off items, or offer your skills and services.'],
        ['4','fa-chart-line','Track Your Impact','Get digital receipts, live campaign updates, and delivery confirmations.'],
      ];
      foreach ($steps as $s): ?>
      <div class="step-card">
        <div class="step-num">Step <?= $s[0] ?></div>
        <div class="step-icon"><i class="fas <?= $s[1] ?>"></i></div>
        <div class="step-title"><?= $s[2] ?></div>
        <p class="step-desc"><?= $s[3] ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── Features ──────────────────────────────────────────── -->
<section class="section" id="transparency">
  <div style="max-width:1200px;margin:0 auto;">
    <div class="sec-eyebrow"><i class="fas fa-shield-halved"></i> Built for Trust</div>
    <h2>Every Feature Protects Your Donation</h2>
    <p class="sec-desc">Six pillars that make UMDC the most transparent donation platform in the Philippines.</p>
    <div class="features-grid">
      <?php
      $feats = [
        ['fa-building-ngo','Verified Organizations','Every organization submits SEC registration, BIR documents, and undergoes manual admin review before they can campaign.'],
        ['fa-receipt','Instant Digital Receipts','Auto-generated, downloadable receipts for every cash donation — BIR-ready and shareable.'],
        ['fa-link','Blockchain Audit Trail','Every transaction is SHA-256 hashed and stored in an immutable ledger for full auditability.'],
        ['fa-truck','Item Donation Logistics','Donate goods — we schedule courier pickup, track delivery status, and confirm receipt with photos.'],
        ['fa-chart-bar','Real-Time Analytics','Live dashboards show campaign progress, donor leaderboards, and organization impact in real time.'],
        ['fa-triangle-exclamation','Fraud Detection','Our admin team actively monitors and flags suspicious activity to protect every donor and beneficiary.'],
      ];
      foreach ($feats as $f): ?>
      <div class="feat-card">
        <div class="feat-icon"><i class="fas <?= $f[0] ?>"></i></div>
        <div class="feat-title"><?= $f[1] ?></div>
        <p class="feat-desc"><?= $f[2] ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── CTA Strip ─────────────────────────────────────────── -->
<section class="cta-strip" id="about">
  <div style="max-width:700px;margin:0 auto;position:relative;z-index:1;">
    <h2>Ready to Make an Impact?</h2>
    <p>Join thousands of Filipino donors already changing lives through UMDC.</p>
    <div class="cta-btns">
      <?php if ($is_logged_in): ?>
        <a href="<?= $dash_link ?>" class="btn-cta-white"><i class="fas fa-gauge-high"></i> Go to Dashboard</a>
      <?php else: ?>
        <a href="/Auth/register.php" class="btn-cta-white"><i class="fas fa-heart"></i> Donate Now — It's Free</a>
        <a href="/Auth/register.php?role=organization" class="btn-cta-outline"><i class="fas fa-building"></i> Register Your Organization</a>
      <?php endif; ?>
    </div>
  </div>
</section>

<!-- ── Footer ────────────────────────────────────────────── -->
<footer class="footer">
  <div style="max-width:1200px;margin:0 auto;">
    <div class="footer-grid">
      <div>
        <div class="footer-brand-name">
          <div class="nav-logo-icon" style="width:28px;height:28px;font-size:.75rem;"><i class="fas fa-shield-halved"></i></div>
          UMDC Platform
        </div>
        <p class="footer-brand-desc">A unified platform for transparent, verified, and impactful donations across the Philippines.</p>
      </div>
      <div class="footer-col">
        <h5>Platform</h5>
        <a href="#campaigns">Campaigns</a>
        <a href="#how-it-works">How It Works</a>
        <a href="#transparency">Features</a>
        <a href="/transactions/ledger.php">Public Ledger</a>
      </div>
      <div class="footer-col">
        <h5>Account</h5>
        <?php if ($is_logged_in): ?>
        <a href="<?= $dash_link ?>">My Dashboard</a>
        <a href="/Auth/logout.php">Sign Out</a>
        <?php else: ?>
        <a href="/Auth/login.php">Sign In</a>
        <a href="/Auth/register.php">Create Account</a>
        <a href="/Auth/register.php?role=organization">For Organizations</a>
        <?php endif; ?>
      </div>
      <div class="footer-col">
        <h5>Legal</h5>
        <a href="#">Privacy Policy</a>
        <a href="#">Terms of Service</a>
        <a href="#">Data Protection</a>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; <?= date('Y') ?> UMDC Platform. All rights reserved.</span>
      <span>Built with ❤️ for Filipino communities</span>
    </div>
  </div>
</footer>

<script>
// ── Counter animation ────────────────────────────────────────
function animateCounter(el, end, prefix='', suffix='', isLarge=false) {
    let start = 0, duration = 1800, step = 16;
    let timer = setInterval(() => {
        start += end / (duration / step);
        if (start >= end) { start = end; clearInterval(timer); }
        if (isLarge) {
            let v = start;
            if (v >= 1e6) el.textContent = prefix + (v/1e6).toFixed(1) + 'M' + suffix;
            else if (v >= 1e3) el.textContent = prefix + (v/1e3).toFixed(0) + 'K' + suffix;
            else el.textContent = prefix + Math.floor(v) + suffix;
        } else {
            el.textContent = prefix + Math.floor(start).toLocaleString() + suffix;
        }
    }, step);
}

// Run when stats bar enters viewport
const statsBar = document.querySelector('.stats-bar');
let counted = false;
const io = new IntersectionObserver(entries => {
    if (entries[0].isIntersecting && !counted) {
        counted = true;
        animateCounter(document.getElementById('c-raised'), <?= $stat_raised ?>, '₱', '', true);
        animateCounter(document.getElementById('c-campaigns'), <?= $stat_campaigns ?>);
        animateCounter(document.getElementById('c-donors'), <?= $stat_donors ?>);
        animateCounter(document.getElementById('c-orgs'), <?= $stat_orgs ?>);
    }
}, { threshold: 0.3 });
if (statsBar) io.observe(statsBar);

// ── Smooth scroll for anchor links ─────────────────────────
document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
        const t = document.querySelector(a.getAttribute('href'));
        if (t) { e.preventDefault(); t.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    });
});
</script>
</body>
</html>
