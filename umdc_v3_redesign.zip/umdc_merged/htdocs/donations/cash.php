<?php
defined('UMDC_APP') or define('UMDC_APP', true);
require_once __DIR__ . '/../Config/security.php';
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../receipts/generate.php';
umdc_session_start();
requireRole('user');
setSecureHeaders();

$donation_id = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);
$sess        = '?_sess=UMDC_USER';

if (!$donation_id) { header("Location: /dashboard/user.php{$sess}"); exit; }

$user_id = currentUserId();
$stmt = $pdo->prepare("
    SELECT d.*, c.title AS campaign_title, c.campaign_id,
           CONCAT(u.first_name,' ',u.last_name) AS donor_name, u.email AS donor_email,
           o.org_name
    FROM donations d
    JOIN campaigns c ON d.campaign_id = c.campaign_id
    JOIN organizations o ON c.org_id = o.org_id
    JOIN users u ON d.user_id = u.user_id
    WHERE d.donation_id = ? AND d.user_id = ? AND d.donation_type = 'cash'
");
$stmt->execute([$donation_id, $user_id]);
$donation = $stmt->fetch();
if (!$donation) { header("Location: /dashboard/user.php{$sess}"); exit; }

// Check if paymongo is configured
$paymongoReady = (strpos(getenv('PAYMONGO_SECRET_KEY') ?: '', 'sk_') === 0
               || strpos(PAYMONGO_SECRET_KEY ?? '', 'sk_') === 0)
               && !str_contains(PAYMONGO_SECRET_KEY ?? '', 'REPLACE');

// Fallback: manual confirm (no PayMongo keys)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_manual'])) {
    csrf_check();
    if ($donation['status'] === 'pending') {
        try {
            $pdo->beginTransaction();
            $pdo->prepare("UPDATE donations SET status='completed' WHERE donation_id=?")->execute([$donation_id]);
            $pdo->prepare("UPDATE campaigns SET current_amount=current_amount+? WHERE campaign_id=?")->execute([$donation['amount'],$donation['campaign_id']]);
            $ref = 'UMDC-' . strtoupper(bin2hex(random_bytes(6)));
            $pdo->prepare("INSERT INTO payments (donation_id,gateway,transaction_ref,payment_status,paid_at) VALUES (?,'manual',?,'success',NOW())")->execute([$donation_id,$ref]);
            generateReceipt($pdo, $donation_id);
            auditLog($pdo, $user_id, 'payment_manual', 'donation', $donation_id);
            $pdo->commit();
            header("Location: /dashboard/user.php{$sess}&success=payment_complete"); exit;
        } catch (PDOException $e) {
            $pdo->rollBack();
            error_log($e->getMessage());
        }
    }
}

$amount    = (float)$donation['amount'];
$isPaid    = $donation['status'] === 'completed';
$hasFailed = isset($_GET['error']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<meta name="csrf-token" content="<?= csrf_token() ?>">
<title>Complete Donation – UMDC</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="/assets/css/global.css">
<style>
/* ── Payment page layout ───────────────────────────────────── */
body { background: var(--color-bg); min-height: 100vh; }
.pay-page {
  min-height: 100vh;
  display: grid;
  grid-template-columns: 1fr 420px;
  max-width: 960px;
  margin: 0 auto;
  padding: 40px 24px;
  gap: 32px;
  align-items: start;
}
.pay-left { position: sticky; top: 40px; }
.pay-summary {
  background: var(--brand-gradient);
  border-radius: 20px;
  padding: 32px;
  color: white;
  position: relative;
  overflow: hidden;
}
.pay-summary::before {
  content: '';
  position: absolute;
  width: 300px; height: 300px;
  background: rgba(255,255,255,.07);
  border-radius: 50%;
  top: -100px; right: -60px;
}
.pay-amount {
  font-size: 2.8rem;
  font-weight: 800;
  letter-spacing: -2px;
  font-family: var(--font-mono);
  margin: 16px 0;
}
.pay-detail { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid rgba(255,255,255,.15); font-size: .875rem; }
.pay-detail:last-child { border-bottom: none; }
.pay-detail .lbl { opacity: .75; }
.pay-right { }

/* ── Payment method cards ─────────────────────────────────── */
.method-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 20px; }
.method-card {
  border: 2px solid var(--color-border);
  border-radius: 14px;
  padding: 18px 14px;
  text-align: center;
  cursor: pointer;
  transition: var(--transition);
  background: var(--color-surface);
  position: relative;
  user-select: none;
  -webkit-tap-highlight-color: transparent;
}
.method-card:hover, .method-card.selected {
  border-color: var(--brand-primary);
  background: rgba(59,111,240,.05);
}
.method-card.selected::after {
  content: '✓';
  position: absolute;
  top: 8px; right: 10px;
  width: 20px; height: 20px;
  background: var(--brand-primary);
  color: white;
  border-radius: 50%;
  font-size: .7rem;
  font-weight: 800;
  display: flex;
  align-items: center;
  justify-content: center;
}
.method-logo { height: 40px; object-fit: contain; margin: 0 auto 8px; display: block; }
.method-name { font-weight: 700; font-size: .875rem; }
.method-desc { font-size: .72rem; color: var(--color-muted); margin-top: 3px; }

/* ── QR display ────────────────────────────────────────────── */
.qr-container {
  display: none;
  text-align: center;
  padding: 28px 20px;
  background: var(--color-surface);
  border: 1px solid var(--color-border);
  border-radius: 16px;
  margin-bottom: 20px;
}
.qr-container.show { display: block; }
.qr-img { width: 220px; height: 220px; border-radius: 12px; border: 4px solid var(--brand-primary); margin: 0 auto 16px; display: block; }
.qr-steps { text-align: left; font-size: .855rem; color: var(--color-muted); }
.qr-steps li { padding: 5px 0; display: flex; gap: 10px; }
.qr-steps .num { width: 22px; height: 22px; border-radius: 50%; background: var(--brand-primary); color: white; font-size: .7rem; font-weight: 800; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 1px; }

/* ── Pay button ────────────────────────────────────────────── */
.pay-btn {
  width: 100%;
  padding: 16px;
  border: none;
  border-radius: 14px;
  background: var(--brand-gradient);
  color: white;
  font-family: var(--font-sans);
  font-size: 1.05rem;
  font-weight: 700;
  cursor: pointer;
  transition: var(--transition);
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  letter-spacing: -.2px;
}
.pay-btn:disabled { opacity: .6; cursor: not-allowed; }
.pay-btn:not(:disabled):hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(59,111,240,.4); }
.pay-btn:not(:disabled):active { transform: translateY(0); }

/* ── Progress / stepper ────────────────────────────────────── */
.stepper { display: flex; gap: 0; margin-bottom: 28px; }
.step { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 6px; position: relative; }
.step::before {
  content: '';
  position: absolute;
  left: 50%; right: -50%;
  top: 14px;
  height: 2px;
  background: var(--color-border);
  z-index: 0;
}
.step:last-child::before { display: none; }
.step.done::before { background: var(--brand-primary); }
.step-dot {
  width: 28px; height: 28px;
  border-radius: 50%;
  background: var(--color-border);
  display: flex; align-items: center; justify-content: center;
  font-size: .75rem; font-weight: 700;
  color: var(--color-muted);
  z-index: 1;
  transition: var(--transition);
}
.step.active .step-dot { background: var(--brand-primary); color: white; }
.step.done .step-dot   { background: var(--color-success); color: white; }
.step-label { font-size: .68rem; color: var(--color-muted); font-weight: 600; text-align: center; }
.step.active .step-label { color: var(--brand-primary); }

/* ── Success state ──────────────────────────────────────────── */
.success-state { text-align: center; padding: 32px 20px; }
.success-state .check-anim {
  width: 80px; height: 80px;
  border-radius: 50%;
  background: rgba(5,150,105,.1);
  display: flex; align-items: center; justify-content: center;
  margin: 0 auto 20px;
  font-size: 2.2rem;
  animation: bounceIn .5s cubic-bezier(.175,.885,.32,1.275);
}
@keyframes bounceIn { 0%{transform:scale(0)} 60%{transform:scale(1.2)} 100%{transform:scale(1)} }

/* ── Security badge ─────────────────────────────────────────── */
.security-row {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 16px;
  margin-top: 16px;
  font-size: .72rem;
  color: var(--color-muted);
  flex-wrap: wrap;
}
.security-item { display: flex; align-items: center; gap: 5px; }
.security-item i { color: var(--color-success); }

/* ── MOBILE ─────────────────────────────────────────────────── */
@media (max-width: 768px) {
  .pay-page {
    grid-template-columns: 1fr;
    padding: 0 0 24px;
    gap: 0;
    max-width: 100%;
  }
  .pay-left {
    position: static;
    border-radius: 0 0 24px 24px;
    margin-bottom: 0;
  }
  .pay-summary {
    border-radius: 0 0 24px 24px;
    padding: 24px 20px;
  }
  .pay-amount { font-size: 2.2rem; }
  .pay-right { padding: 20px 16px; }
  .method-grid { gap: 10px; }
  .method-card { padding: 14px 10px; }
  .qr-img { width: 180px; height: 180px; }
}
@media (max-width: 380px) {
  .method-grid { grid-template-columns: 1fr; }
}
</style>
</head>
<body>

<div class="pay-page">

    <!-- ── Left: summary ─────────────────────────────────── -->
    <div class="pay-left">
        <a href="/dashboard/user.php?_sess=UMDC_USER" style="display:inline-flex;align-items:center;gap:8px;color:var(--color-muted);font-size:.855rem;text-decoration:none;margin-bottom:20px;margin-left:4px;">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>

        <div class="pay-summary">
            <div style="font-size:.78rem;opacity:.75;text-transform:uppercase;letter-spacing:1.5px;font-weight:700;">Donation to</div>
            <div style="font-weight:800;font-size:1.05rem;margin-top:4px;line-height:1.3;"><?= e($donation['campaign_title']) ?></div>
            <div style="font-size:.82rem;opacity:.7;margin-top:4px;"><?= e($donation['org_name']) ?></div>

            <div class="pay-amount">₱<?= number_format($amount, 2) ?></div>

            <div class="pay-detail"><span class="lbl">Donor</span><span><?= e($donation['donor_name']) ?></span></div>
            <div class="pay-detail"><span class="lbl">Email</span><span style="font-size:.82rem;"><?= e($donation['donor_email']) ?></span></div>
            <div class="pay-detail"><span class="lbl">Donation #</span><span style="font-family:var(--font-mono);font-size:.82rem;">#<?= $donation_id ?></span></div>
            <div class="pay-detail"><span class="lbl">Date</span><span><?= date('M d, Y', strtotime($donation['created_at'])) ?></span></div>
        </div>

        <!-- What you're supporting -->
        <div style="margin-top:16px;padding:16px;background:var(--color-surface);border:1px solid var(--color-border);border-radius:14px;">
            <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:1px;color:var(--color-muted);font-weight:700;margin-bottom:10px;">Your Impact</div>
            <div style="display:flex;align-items:center;gap:10px;font-size:.855rem;">
                <i class="fas fa-hand-holding-heart" style="color:var(--brand-primary);font-size:1.1rem;flex-shrink:0;"></i>
                <span>100% of your donation goes directly to <strong><?= e($donation['campaign_title']) ?></strong></span>
            </div>
        </div>
    </div>

    <!-- ── Right: payment ────────────────────────────────── -->
    <div class="pay-right">

        <?php if ($isPaid): ?>
        <!-- Already paid -->
        <div class="success-state">
            <div class="check-anim"><i class="fas fa-check" style="color:var(--color-success);"></i></div>
            <h3 style="font-weight:800;margin-bottom:8px;">Donation Completed!</h3>
            <p style="color:var(--color-muted);margin-bottom:24px;">Thank you for your generosity. Your receipt has been generated.</p>
            <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
                <a href="/receipts/view.php?id=<?= $donation_id ?>&_sess=UMDC_USER" class="btn-primary">
                    <i class="fas fa-receipt"></i> View Receipt
                </a>
                <a href="/dashboard/user.php?_sess=UMDC_USER" class="btn-secondary">Back to Dashboard</a>
            </div>
        </div>

        <?php else: ?>
        <!-- Stepper -->
        <div class="stepper" id="stepper">
            <div class="step done" id="step1"><div class="step-dot"><i class="fas fa-check" style="font-size:.65rem;"></i></div><div class="step-label">Review</div></div>
            <div class="step active" id="step2"><div class="step-dot">2</div><div class="step-label">Pay</div></div>
            <div class="step" id="step3"><div class="step-dot">3</div><div class="step-label">Done</div></div>
        </div>

        <h3 style="font-weight:800;margin-bottom:6px;">Choose Payment Method</h3>
        <p style="color:var(--color-muted);font-size:.875rem;margin-bottom:20px;">
            Select how you want to pay ₱<?= number_format($amount, 2) ?>
        </p>

        <?php if ($hasFailed): ?>
        <div class="alert alert-danger" style="margin-bottom:16px;">
            <i class="fas fa-exclamation-circle"></i>
            <span>Payment was cancelled or failed. Please try again.</span>
        </div>
        <?php endif; ?>

        <!-- Payment method selection -->
        <div class="method-grid" id="methodGrid">
            <div class="method-card selected" data-method="gcash" onclick="selectMethod('gcash',this)">
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/60/GCash_Logo.svg/200px-GCash_Logo.svg.png"
                     class="method-logo" alt="GCash" onerror="this.style.display='none'">
                <div class="method-name">GCash</div>
                <div class="method-desc">e-Wallet · QR Scan</div>
            </div>
            <div class="method-card" data-method="maya" onclick="selectMethod('maya',this)">
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2b/Maya_logo_blue.svg/200px-Maya_logo_blue.svg.png"
                     class="method-logo" alt="Maya" onerror="this.style.display='none'">
                <div class="method-name">Maya</div>
                <div class="method-desc">e-Wallet · Redirect</div>
            </div>
            <div class="method-card" data-method="qrph" onclick="selectMethod('qrph',this)">
                <div style="height:40px;display:flex;align-items:center;justify-content:center;margin-bottom:8px;">
                    <i class="fas fa-qrcode" style="font-size:2rem;color:var(--brand-primary);"></i>
                </div>
                <div class="method-name">QR Ph</div>
                <div class="method-desc">InstaPay · Any Bank</div>
            </div>
            <?php if (!$paymongoReady): ?>
            <div class="method-card" data-method="manual" onclick="selectMethod('manual',this)">
                <div style="height:40px;display:flex;align-items:center;justify-content:center;margin-bottom:8px;">
                    <i class="fas fa-check-circle" style="font-size:2rem;color:var(--color-success);"></i>
                </div>
                <div class="method-name">Confirm Directly</div>
                <div class="method-desc">Demo / Testing</div>
            </div>
            <?php endif; ?>
        </div>

        <!-- QR code display (for qrph) -->
        <div class="qr-container" id="qrContainer">
            <div style="font-weight:700;font-size:1rem;margin-bottom:4px;">Scan QR Code</div>
            <div style="font-size:.82rem;color:var(--color-muted);margin-bottom:16px;">Open your banking app and scan this InstaPay QR</div>
            <img id="qrImage" src="" alt="QR Code" class="qr-img">
            <div style="font-size:.78rem;font-family:var(--font-mono);color:var(--color-muted);word-break:break-all;background:var(--color-surface-2);border-radius:8px;padding:10px;margin-bottom:16px;" id="qrRef"></div>
            <ol class="qr-steps" style="list-style:none;padding:0;">
                <li><span class="num">1</span> Open your bank or e-wallet app</li>
                <li><span class="num">2</span> Tap "Scan QR" or "Pay via QR"</li>
                <li><span class="num">3</span> Scan the QR code above</li>
                <li><span class="num">4</span> Confirm the amount of ₱<?= number_format($amount, 2) ?></li>
                <li><span class="num">5</span> Click "I've Paid" button below</li>
            </ol>
        </div>

        <!-- Loading state -->
        <div id="payLoading" style="display:none;text-align:center;padding:24px;">
            <div class="spinner" style="margin:0 auto 12px;"></div>
            <div style="font-size:.875rem;color:var(--color-muted);" id="payLoadingText">Creating payment…</div>
        </div>

        <!-- Pay button -->
        <button class="pay-btn" id="payBtn" onclick="initPayment()">
            <i class="fas fa-lock"></i>
            <span id="payBtnText">Pay ₱<?= number_format($amount, 2) ?> with GCash</span>
        </button>

        <!-- Manual confirm (fallback) -->
        <?php if (!$paymongoReady): ?>
        <form method="POST" id="manualForm" style="display:none;margin-top:12px;">
            <?= csrf_field() ?>
            <button type="submit" name="confirm_manual" class="pay-btn" style="background:var(--color-success);">
                <i class="fas fa-check-circle"></i> Confirm Donation (Demo)
            </button>
        </form>
        <div class="alert alert-warning" style="margin-top:12px;font-size:.82rem;">
            <i class="fas fa-info-circle"></i>
            <span><strong>Demo mode:</strong> PayMongo keys not configured. Add your keys to <code>Config/paymongo.php</code> for live payments.</span>
        </div>
        <?php endif; ?>

        <!-- Security row -->
        <div class="security-row">
            <div class="security-item"><i class="fas fa-lock"></i> SSL Encrypted</div>
            <div class="security-item"><i class="fas fa-shield-alt"></i> Powered by PayMongo</div>
            <div class="security-item"><i class="fas fa-check-circle"></i> PCI Compliant</div>
        </div>

        <?php endif; // end !isPaid ?>
    </div>
</div>

<script src="/assets/js/global.js"></script>
<script>
const DONATION_ID    = <?= $donation_id ?>;
const CSRF_TOKEN     = document.querySelector('meta[name="csrf-token"]').content;
const PAYMONGO_READY = <?= $paymongoReady ? 'true' : 'false' ?>;
let selectedMethod   = 'gcash';

function selectMethod(method, el) {
    document.querySelectorAll('.method-card').forEach(c => c.classList.remove('selected'));
    el.classList.add('selected');
    selectedMethod = method;

    const btn  = document.getElementById('payBtn');
    const btnT = document.getElementById('payBtnText');
    const qrC  = document.getElementById('qrContainer');
    const mForm= document.getElementById('manualForm');

    qrC.classList.remove('show');
    if (mForm) mForm.style.display = 'none';
    btn.style.display = 'flex';

    const labels = {
        gcash:  `Pay ₱<?= number_format($amount,2) ?> with GCash`,
        maya:   `Pay ₱<?= number_format($amount,2) ?> with Maya`,
        qrph:   `Generate QR Ph Code`,
        manual: `Confirm Donation (Demo)`,
    };
    btnT.textContent = labels[method] || `Pay ₱<?= number_format($amount,2) ?>`;

    if (method === 'manual') {
        btn.style.display = 'none';
        if (mForm) mForm.style.display = 'block';
    }
}

async function initPayment() {
    const btn = document.getElementById('payBtn');
    const loading = document.getElementById('payLoading');
    const loadingText = document.getElementById('payLoadingText');

    btn.disabled = true;
    btn.style.display = 'none';
    loading.style.display = 'block';

    const fd = new FormData();
    fd.append('donation_id', DONATION_ID);
    fd.append('payment_method', selectedMethod);
    fd.append('csrf_token', CSRF_TOKEN);

    try {
        loadingText.textContent = 'Connecting to PayMongo…';
        const res  = await fetch(`/api/paymongo_create.php?_sess=UMDC_USER`, { method: 'POST', body: fd });
        const data = await res.json();

        if (!data.success) {
            throw new Error(data.message || 'Payment setup failed');
        }

        if (selectedMethod === 'qrph' && data.qr_code_url) {
            // Show QR code
            loading.style.display = 'none';
            btn.style.display = 'none';

            const qrC = document.getElementById('qrContainer');
            const qrImg = document.getElementById('qrImage');
            const qrRef = document.getElementById('qrRef');

            // Use Google Charts QR generator to display the URL as QR
            const qrContent = data.qr_code_url || data.ref;
            qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(qrContent)}&margin=10&color=000000&bgcolor=ffffff`;
            qrRef.textContent = 'Ref: ' + (data.ref || '');
            qrC.classList.add('show');

            // Add "I've paid" button
            const paidBtn = document.createElement('button');
            paidBtn.className = 'pay-btn';
            paidBtn.style.marginTop = '16px';
            paidBtn.style.background = 'var(--color-success)';
            paidBtn.innerHTML = '<i class="fas fa-check-circle"></i> I\'ve Paid — Verify Payment';
            paidBtn.onclick = () => pollPayment(data.ref);
            qrC.appendChild(paidBtn);

            // Step indicator
            goToStep(3);

        } else if (data.checkout_url) {
            // Redirect to GCash/Maya checkout
            loadingText.textContent = 'Redirecting to ' + selectedMethod + '…';
            setTimeout(() => { window.location.href = data.checkout_url; }, 600);
        }

    } catch (err) {
        loading.style.display = 'none';
        btn.style.display = 'flex';
        btn.disabled = false;

        // Show error alert
        const alert = document.createElement('div');
        alert.className = 'alert alert-danger';
        alert.style.marginBottom = '16px';
        alert.innerHTML = `<i class="fas fa-exclamation-circle"></i><span>${escapeHtml(err.message)}</span>`;
        btn.parentNode.insertBefore(alert, btn);
        setTimeout(() => alert.remove(), 6000);
    }
}

async function pollPayment(ref) {
    showToast('Checking payment status…', 'info');
    // Simple: reload the page after a moment — the return handler will have updated DB
    // For production, poll /api/paymongo_status.php
    setTimeout(() => {
        window.location.href = `/donations/cash.php?id=${DONATION_ID}&_sess=UMDC_USER`;
    }, 2000);
}

function goToStep(n) {
    const steps = ['step1','step2','step3'];
    steps.forEach((id, i) => {
        const el = document.getElementById(id);
        if (!el) return;
        el.classList.remove('active','done');
        if (i + 1 < n)      el.classList.add('done');
        else if (i + 1 === n) el.classList.add('active');
    });
}

function escapeHtml(str) {
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
</script>
</body>
</html>
