<?php
defined('UMDC_APP') or define('UMDC_APP', true);
require_once __DIR__ . '/../Config/security.php';
require_once __DIR__ . '/../Config/db.php';
umdc_session_start();
requireRole('organization');
setSecureHeaders();
$_SESS_PARAM = '?_sess=UMDC_ORG';
require_once __DIR__ . '/../Config/notifications.php';

$user_id   = currentUserId();
$user_name = e($_SESSION['user_name'] ?? 'Organization');
$first     = strtok($_SESSION['user_name'] ?? 'Org', ' ');
$initials  = strtoupper(substr($_SESSION['user_name']??'O',0,1).(strpos($_SESSION['user_name']??'','  ')!==false?substr(strrchr($_SESSION['user_name']??'',' '),1,1):''));

// Fetch user with photo
$userRow = $pdo->prepare("SELECT profile_photo, bio, email, phone, address FROM users WHERE user_id=?");
$userRow->execute([$user_id]); $userRow = $userRow->fetch();
$profilePhoto = $userRow['profile_photo'] ? '/' . ltrim($userRow['profile_photo'],'/') : '';

// Fetch org with logo/cover
$orgStmt = $pdo->prepare("SELECT * FROM organizations WHERE user_id=?");
$orgStmt->execute([$user_id]); $org = $orgStmt->fetch();
$needs_setup = !$org;
$logo        = (!$needs_setup && !empty($org['logo']))        ? '/' . ltrim($org['logo'],'/') : '';
$cover       = (!$needs_setup && !empty($org['cover_photo'])) ? '/' . ltrim($org['cover_photo'],'/') : '';

$campaigns = [];
$stats = ['total_raised'=>0,'total_campaigns'=>0,'active_campaigns'=>0,'total_donors'=>0];

if (!$needs_setup) {
    $cStmt = $pdo->prepare("
        SELECT c.*,
               COALESCE(c.campaign_image,'') AS campaign_image,
               COALESCE(c.location,'')       AS location,
               COALESCE(c.tags,'')           AS tags,
               (SELECT COUNT(*) FROM donations d WHERE d.campaign_id=c.campaign_id AND d.status='completed') AS donor_count,
               (SELECT COALESCE(SUM(amount),0) FROM donations d WHERE d.campaign_id=c.campaign_id AND d.status='completed') AS raised
        FROM campaigns c WHERE c.org_id=? ORDER BY c.created_at DESC
    ");
    $cStmt->execute([$org['org_id']]); $campaigns = $cStmt->fetchAll();

    $qs = [
        'total_raised'     => "SELECT COALESCE(SUM(d.amount),0) FROM donations d JOIN campaigns c ON d.campaign_id=c.campaign_id WHERE c.org_id=? AND d.status='completed'",
        'total_campaigns'  => "SELECT COUNT(*) FROM campaigns WHERE org_id=?",
        'active_campaigns' => "SELECT COUNT(*) FROM campaigns WHERE org_id=? AND status IN ('approved','active')",
        'total_donors'     => "SELECT COUNT(DISTINCT d.user_id) FROM donations d JOIN campaigns c ON d.campaign_id=c.campaign_id WHERE c.org_id=?",
    ];
    foreach ($qs as $k => $q) { $s=$pdo->prepare($q); $s->execute([$org['org_id']]); $stats[$k]=$s->fetchColumn(); }
}

// Success / error flash messages
$flash = '';
if (isset($_GET['success'])) {
    $msgs = ['campaign_submitted'=>'Campaign submitted for review!','org_created'=>'Organization set up!','updated'=>'Profile updated!'];
    $flash = $msgs[$_GET['success']] ?? 'Done!';
}

// Chart data (only if org exists)
$monthlyDonations = [];
$campaignPerformance = [];
if (!$needs_setup) {
    $mStmt = $pdo->prepare("
        SELECT DATE_FORMAT(d.created_at,'%b') AS label,
               DATE_FORMAT(d.created_at,'%Y-%m') AS month_key,
               COALESCE(SUM(d.amount),0) AS total, COUNT(*) AS cnt
        FROM donations d
        JOIN campaigns c ON d.campaign_id=c.campaign_id
        WHERE c.org_id=? AND d.status='completed'
          AND d.created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
        GROUP BY month_key, label ORDER BY month_key ASC
    ");
    $mStmt->execute([$org['org_id']]);
    $monthlyDonations = $mStmt->fetchAll(PDO::FETCH_ASSOC);

    $cpStmt = $pdo->prepare("
        SELECT c.title, COALESCE(c.current_amount,0) AS raised,
               c.target_amount, c.status,
               (SELECT COUNT(*) FROM donations d WHERE d.campaign_id=c.campaign_id AND d.status='completed') AS donors
        FROM campaigns c WHERE c.org_id=? ORDER BY raised DESC LIMIT 5
    ");
    $cpStmt->execute([$org['org_id']]);
    $campaignPerformance = $cpStmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<meta name="csrf-token" content="<?= csrf_token() ?>">
<meta name="sess-name" content="UMDC_ORG">
<title>Organization Dashboard – UMDC</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="/assets/css/global.css">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="/assets/css/notifications.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
/* Org cover / hero */
.org-hero{position:relative;height:200px;background:var(--brand-gradient);border-radius:var(--radius-lg);overflow:hidden;margin-bottom:60px;cursor:pointer;}
.org-hero img{width:100%;height:100%;object-fit:cover;}
.org-hero-overlay{position:absolute;inset:0;background:rgba(0,0,0,.3);display:flex;align-items:center;justify-content:center;opacity:0;transition:.2s;}
.org-hero:hover .org-hero-overlay{opacity:1;}
.org-logo-wrap{position:absolute;bottom:-44px;left:28px;width:88px;height:88px;border-radius:50%;border:4px solid var(--color-surface);background:var(--color-surface);overflow:hidden;box-shadow:var(--shadow-md);}
.org-logo-wrap img{width:100%;height:100%;object-fit:cover;}
.org-logo-placeholder{width:100%;height:100%;background:var(--brand-gradient);display:flex;align-items:center;justify-content:center;color:white;font-size:2rem;font-weight:800;}
.org-logo-edit{position:absolute;inset:0;background:rgba(0,0,0,.4);display:flex;align-items:center;justify-content:center;opacity:0;cursor:pointer;border-radius:50%;transition:.2s;}
.org-logo-wrap:hover .org-logo-edit{opacity:1;}

/* Campaign card grid */
.camp-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:20px;}
.camp-card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:var(--radius-lg);overflow:hidden;box-shadow:var(--shadow-sm);transition:var(--transition);}
.camp-card:hover{transform:translateY(-3px);box-shadow:var(--shadow-md);}
.camp-thumb{height:160px;background:linear-gradient(135deg,rgba(59,111,240,.12),rgba(124,58,237,.12));position:relative;overflow:hidden;display:flex;align-items:center;justify-content:center;font-size:3rem;}
.camp-thumb img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;}
.camp-thumb-overlay{position:absolute;inset:0;background:rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center;opacity:0;transition:.2s;cursor:pointer;}
.camp-thumb:hover .camp-thumb-overlay{opacity:1;}
.camp-body{padding:16px;}

/* Tab nav */
.tab-nav{display:flex;gap:4px;border-bottom:2px solid var(--color-border);margin-bottom:24px;}
.tab-btn{padding:10px 18px;font-size:.875rem;font-weight:600;color:var(--color-muted);background:none;border:none;border-bottom:2px solid transparent;margin-bottom:-2px;cursor:pointer;transition:var(--transition);font-family:var(--font-sans);}
.tab-btn.active{color:var(--brand-primary);border-bottom-color:var(--brand-primary);}
.tab-pane{display:none;} .tab-pane.active{display:block;}

/* Charts */
.org-chart-grid { display: grid; grid-template-columns: 1.4fr 1fr; gap: 20px; margin-bottom: 24px; }
.chart-wrap { position: relative; height: 200px; }
canvas { max-height: 200px; }

/* Stat accents */
.stat-card.green::before  { background: var(--color-success); }
.stat-card.blue::before   { background: var(--brand-primary); }
.stat-card.purple::before { background: var(--brand-secondary); }
.stat-card.amber::before  { background: var(--color-warning); }
.stat-icon { position: absolute; top: 18px; right: 18px; font-size: 1.4rem; opacity: .1; }

/* Filter bar */
.filter-bar { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; padding: 12px 20px 14px; border-bottom: 1px solid var(--color-border); background: var(--color-surface-2); }
.filter-input { padding: 6px 12px; border-radius: 20px; border: 1.5px solid var(--color-border); background: var(--color-surface); color: var(--color-text); font-family: var(--font-sans); font-size: .82rem; min-width: 160px; transition: border-color .15s; }
.filter-input:focus { outline: none; border-color: var(--brand-primary); }
.filter-select { padding: 6px 12px; border-radius: 20px; border: 1.5px solid var(--color-border); background: var(--color-surface); color: var(--color-text); font-family: var(--font-sans); font-size: .82rem; cursor: pointer; }
.filter-count { margin-left: auto; font-size: .78rem; color: var(--color-muted); }

@media (max-width: 768px) {
  .org-chart-grid { grid-template-columns: 1fr; }
}
</style>
</head>
<body>


<!-- Mobile Header -->
<header class="mobile-header">
    <div class="brand-name">UMDC</div>
    <div class="mobile-header-right">
        <?php require_once __DIR__ . '/../components/notification_bell.php'; ?>
        <button class="logout-btn" data-logout style="padding:6px 8px;font-size:1rem;background:var(--color-surface-2);border:1px solid var(--color-border);border-radius:var(--radius-md);">
            <i class="fas fa-sign-out-alt" style="color:var(--color-danger);"></i>
        </button>
    </div>
</header>
<button class="mobile-toggle" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>

<aside class="sidebar">
    <div class="sidebar-logo">
        <div class="brand-name">UMDC</div>
        <div class="brand-sub">Organization Portal</div>
    </div>
    <nav class="sidebar-nav">
        <a href="organization.php<?= $_SESS_PARAM ?>" class="sidebar-link active"><i class="fas fa-chart-pie"></i> Dashboard</a>
        <?php if (!$needs_setup): ?>
        <button class="sidebar-link" onclick="openModal('campaignModal')"><i class="fas fa-plus-circle"></i> New Campaign</button>
        <a href="../transactions/ledger.php<?= $_SESS_PARAM ?>" class="sidebar-link"><i class="fas fa-list-alt"></i> Ledger</a>
        <a href="../verification/submit.php<?= $_SESS_PARAM ?>" class="sidebar-link"><i class="fas fa-id-badge"></i> Verification</a>
        <a href="/notifications/index.php<?= $_SESS_PARAM ?>" class="sidebar-link">
            <i class="fas fa-bell"></i> Notifications
            <?php $nb = Notifier::getUnreadCount($pdo, currentUserId()); if ($nb > 0): ?>
            <span class="badge-count"><?= min($nb,99) ?></span>
            <?php endif; ?>
        </a>
        <?php endif; ?>
    </nav>
    <div class="sidebar-footer">
        <div class="sidebar-user">
            <?php if ($profilePhoto): ?>
            <img src="<?= $profilePhoto ?>" style="width:34px;height:34px;border-radius:50%;object-fit:cover;flex-shrink:0;" alt="Profile">
            <?php else: ?>
            <div class="avatar"><?= $initials ?></div>
            <?php endif; ?>
            <div>
                <div class="sidebar-user-name"><?= $user_name ?></div>
                <div class="sidebar-user-role"><?= $needs_setup ? 'Organization' : e($org['org_name']) ?></div>
            </div>
            <button class="logout-btn" data-logout title="Sign out"><i class="fas fa-sign-out-alt"></i></button>
        </div>
    </div>
</aside>

<main class="main-content">

<?php if ($flash): ?>
<div class="alert alert-success" data-auto-dismiss><i class="fas fa-check-circle"></i><span><?= e($flash) ?></span></div>
<?php endif; ?>

<?php if ($needs_setup): ?>
<!-- ── SETUP SCREEN ──────────────────────────────────────────── -->
<div class="page-header">
    <h1>Set Up Your Organization</h1>
    <p>Complete your profile to start creating campaigns and receiving donations.</p>
</div>
<div class="card" style="max-width:560px;">
    <div class="card-header"><h5>Organization Details</h5></div>
    <div class="card-body">
        <form method="POST" action="../api/setup_org.php" id="setupForm">
            <?= csrf_field() ?>
            <div class="form-group">
                <label class="form-label">Organization Name <span style="color:var(--color-danger)">*</span></label>
                <input class="form-input" type="text" name="org_name" placeholder="e.g., Helping Hands Foundation" required>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
                <div class="form-group">
                    <label class="form-label">Organization Email</label>
                    <input class="form-input" type="email" name="org_email" placeholder="org@example.com">
                </div>
                <div class="form-group">
                    <label class="form-label">Contact Number</label>
                    <input class="form-input" type="tel" name="org_contact" placeholder="+63 9XX XXX XXXX">
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Description</label>
                <textarea class="form-textarea" name="description" rows="3" placeholder="Tell donors what your organization does…"></textarea>
            </div>
            <div class="form-group">
                <label class="form-label">Mission Statement</label>
                <textarea class="form-textarea" name="mission" rows="2" placeholder="Your organization's mission…"></textarea>
            </div>
            <button type="submit" class="btn-primary" style="width:100%;justify-content:center;"><i class="fas fa-save"></i> Save &amp; Continue</button>
        </form>
    </div>
</div>

<?php else: ?>
<!-- ── MAIN DASHBOARD ────────────────────────────────────────── -->
<div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px;">
    <div>
        <h1><?= e($org['org_name']) ?></h1>
        <p style="display:flex;align-items:center;gap:8px;">
            <?php if ($org['verified']): ?>
            <span class="badge-pill badge-active"><i class="fas fa-shield-alt"></i> Verified Organization</span>
            <?php else: ?>
            <span class="badge-pill badge-pending"><i class="fas fa-clock"></i> Pending Verification</span>
            <a href="../verification/submit.php<?= $_SESS_PARAM ?>" style="font-size:.82rem;color:var(--brand-primary);">Submit documents →</a>
            <?php endif; ?>
        </p>
    </div>
    <button class="btn-primary" onclick="openModal('campaignModal')"><i class="fas fa-plus"></i> New Campaign</button>
</div>

<!-- Stats -->
<div class="stats-grid" style="margin-bottom:24px;">
    <div class="stat-card">
        <div class="stat-label">Total Raised</div>
        <div class="stat-value" style="font-family:var(--font-mono);font-size:1.5rem;color:var(--color-success);">₱<?= number_format((float)$stats['total_raised'],2) ?></div>
        <div class="stat-sub">Completed donations</div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Total Campaigns</div>
        <div class="stat-value"><?= (int)$stats['total_campaigns'] ?></div>
        <div class="stat-sub"><?= (int)$stats['active_campaigns'] ?> active</div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Active Campaigns</div>
        <div class="stat-value"><?= (int)$stats['active_campaigns'] ?></div>
        <div class="stat-sub">Currently running</div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Total Donors</div>
        <div class="stat-value"><?= number_format((int)$stats['total_donors']) ?></div>
        <div class="stat-sub">Unique supporters</div>
    </div>
</div>

<?php if (!empty($monthlyDonations) || !empty($campaignPerformance)): ?>
<!-- Analytics Charts -->
<div class="org-chart-grid">
    <div class="card">
        <div class="card-header">
            <h5><i class="fas fa-chart-bar" style="color:var(--brand-primary);margin-right:8px"></i>Monthly Donations Received</h5>
            <span style="font-size:.78rem;color:var(--color-muted)">Last 6 months</span>
        </div>
        <div class="card-body"><div class="chart-wrap"><canvas id="orgMonthlyChart"></canvas></div></div>
    </div>
    <div class="card">
        <div class="card-header">
            <h5><i class="fas fa-chart-pie" style="color:var(--brand-secondary);margin-right:8px"></i>Campaign Progress</h5>
        </div>
        <div class="card-body"><div class="chart-wrap"><canvas id="orgCampChart"></canvas></div></div>
    </div>
</div>
<?php endif; ?>

<!-- Tab navigation -->
<div class="tab-nav">
    <button class="tab-btn active" onclick="switchTab('campaigns',this)"><i class="fas fa-bullhorn"></i> Campaigns</button>
    <button class="tab-btn" onclick="switchTab('profile',this)"><i class="fas fa-building"></i> Organization Profile</button>
    <button class="tab-btn" onclick="switchTab('myprofile',this)"><i class="fas fa-user"></i> My Profile</button>
</div>

<!-- TAB: Campaigns -->
<div id="tab-campaigns" class="tab-pane active">
    <?php if (!empty($campaigns)): ?>
    <div class="filter-bar" style="margin-bottom:20px;border-radius:var(--radius-md);border:1px solid var(--color-border);">
        <input class="filter-input" type="text" id="campSearch" placeholder="🔍 Search campaigns…">
        <select class="filter-select" id="campStatus">
            <option value="">All Statuses</option>
            <option value="active">Active</option>
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="completed">Completed</option>
            <option value="rejected">Rejected</option>
        </select>
        <span class="filter-count"><?= count($campaigns) ?> campaign<?= count($campaigns) !== 1 ? 's' : '' ?></span>
    </div>
    <?php endif; ?>
    <?php if (empty($campaigns)): ?>
    <div class="card">
        <div class="empty-state">
            <i class="fas fa-bullhorn"></i><h6>No campaigns yet</h6>
            <p>Create your first campaign to start receiving donations.</p>
            <button class="btn-primary" style="margin-top:12px;" onclick="openModal('campaignModal')">Create Campaign</button>
        </div>
    </div>
    <?php else: ?>
    <div class="camp-grid">
    <?php foreach ($campaigns as $c):
        $pct    = $c['target_amount']>0 ? min(100,($c['raised']/$c['target_amount'])*100) : 0;
        $imgUrl = $c['campaign_image'] ? '/' . ltrim($c['campaign_image'],'/') : '';
        $emoji  = ['Education'=>'📚','Health'=>'🏥','Disaster Relief'=>'🆘','Environment'=>'🌿','Community'=>'🤝','Food'=>'🍱'][$c['category']??''] ?? '🤝';
    ?>
    <div class="camp-card" data-status="<?= e($c['status']) ?>" data-title="<?= e(strtolower($c['title'])) ?>">
        <div class="camp-thumb">
            <?php if ($imgUrl): ?><img src="<?= e($imgUrl) ?>" alt=""><?php else: ?><?= $emoji ?><?php endif; ?>
            <div class="camp-thumb-overlay" onclick="triggerCampImg(<?= $c['campaign_id'] ?>)">
                <div style="text-align:center;color:white;">
                    <i class="fas fa-camera" style="font-size:1.5rem;display:block;margin-bottom:6px;"></i>
                    <span style="font-size:.8rem;">Change Image</span>
                </div>
            </div>
            <input type="file" id="camp-img-<?= $c['campaign_id'] ?>" accept="image/*" style="display:none;"
                   onchange="uploadCampImg(<?= $c['campaign_id'] ?>,this)">
        </div>
        <div class="camp-body">
            <div style="font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:var(--brand-primary);margin-bottom:6px;"><?= e($c['category']??'General') ?></div>
            <div style="font-weight:700;font-size:.95rem;margin-bottom:6px;line-height:1.3;" data-title="<?= e(strtolower($c['title'])) ?>"><?= e($c['title']) ?></div>
            <div style="font-size:.8rem;color:var(--color-muted);margin-bottom:10px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;"><?= e($c['description']??'') ?></div>
            <?php if ($c['location']): ?>
            <div style="font-size:.78rem;color:var(--color-muted);margin-bottom:8px;"><i class="fas fa-map-marker-alt" style="margin-right:4px;"></i><?= e($c['location']) ?></div>
            <?php endif; ?>
            <div style="display:flex;justify-content:space-between;font-size:.8rem;margin-bottom:6px;">
                <span style="font-weight:700;color:var(--color-success);font-family:var(--font-mono);">₱<?= number_format((float)$c['raised'],2) ?></span>
                <span style="color:var(--color-muted);">of ₱<?= number_format((float)$c['target_amount'],2) ?></span>
            </div>
            <div class="progress-wrap"><div class="progress-fill" style="width:<?= $pct ?>%"></div></div>
            <div style="display:flex;justify-content:space-between;font-size:.72rem;color:var(--color-muted);margin-top:5px;">
                <span><?= number_format($pct,0) ?>% funded · <?= $c['donor_count'] ?> donor<?= $c['donor_count']!=1?'s':'' ?></span>
                <span class="badge-pill badge-<?= e($c['status']) ?>" style="font-size:.65rem;padding:2px 7px;"><?= ucfirst($c['status']) ?></span>
            </div>
            <?php if ($c['end_date']): ?>
            <div style="font-size:.72rem;color:var(--color-muted);margin-top:5px;"><i class="fas fa-calendar" style="margin-right:3px;"></i>Ends <?= date('M d, Y',strtotime($c['end_date'])) ?></div>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div><!-- /tab-campaigns -->

<!-- TAB: Organization Profile -->
<div id="tab-profile" class="tab-pane">
    <!-- Cover photo -->
    <div class="org-hero" onclick="document.getElementById('coverInput').click()" title="Click to change cover photo">
        <?php if ($cover): ?><img src="<?= $cover ?>" alt="Cover"><?php endif; ?>
        <div class="org-hero-overlay">
            <div style="text-align:center;color:white;">
                <i class="fas fa-camera" style="font-size:1.8rem;display:block;margin-bottom:6px;"></i>
                <span>Change Cover Photo</span>
            </div>
        </div>
        <!-- Logo -->
        <div class="org-logo-wrap" onclick="event.stopPropagation();document.getElementById('logoInput').click();">
            <?php if ($logo): ?><img src="<?= $logo ?>" alt="Logo">
            <?php else: ?><div class="org-logo-placeholder"><?= strtoupper(substr($org['org_name'],0,1)) ?></div>
            <?php endif; ?>
            <div class="org-logo-edit"><i class="fas fa-camera" style="color:white;font-size:.9rem;"></i></div>
        </div>
        <input type="file" id="coverInput" accept="image/*" style="display:none;" onchange="uploadOrgPhoto('cover_photo',this)">
        <input type="file" id="logoInput"  accept="image/*" style="display:none;" onchange="uploadOrgPhoto('logo',this)">
    </div>

    <div class="two-col">
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-building" style="color:var(--brand-primary);margin-right:8px;"></i>Edit Organization</h5>
            </div>
            <div class="card-body">
                <form id="orgProfileForm">
                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                    <div class="form-group">
                        <label class="form-label">Organization Name</label>
                        <input class="form-input" type="text" name="org_name" value="<?= e($org['org_name']) ?>" required>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
                        <div class="form-group">
                            <label class="form-label">Org Email</label>
                            <input class="form-input" type="email" name="org_email" value="<?= e($org['org_email']??'') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Contact Number</label>
                            <input class="form-input" type="tel" name="org_contact" value="<?= e($org['org_contact']??'') ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Website</label>
                        <input class="form-input" type="url" name="website" value="<?= e($org['website']??'') ?>" placeholder="https://yourorg.org">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Description</label>
                        <textarea class="form-textarea" name="description" rows="3"><?= e($org['description']??'') ?></textarea>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Mission Statement</label>
                        <textarea class="form-textarea" name="mission" rows="2"><?= e($org['mission']??'') ?></textarea>
                    </div>
                    <!-- Also need personal name/email for update_profile to work -->
                    <input type="hidden" name="first_name" value="<?= e(explode(' ',$_SESSION['user_name']??'Org')[0]) ?>">
                    <input type="hidden" name="last_name"  value="<?= e(explode(' ',$_SESSION['user_name']??'Org User',2)[1]??'') ?>">
                    <input type="hidden" name="email"      value="<?= e($userRow['email']??'') ?>">
                    <button type="submit" class="btn-primary" style="width:100%;justify-content:center;padding:11px;">
                        <i class="fas fa-save"></i> Save Organization Profile
                    </button>
                </form>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h5>Photos &amp; Branding</h5></div>
            <div class="card-body">
                <div style="margin-bottom:20px;">
                    <div style="font-weight:600;font-size:.875rem;margin-bottom:8px;">Organization Logo</div>
                    <div style="display:flex;align-items:center;gap:14px;">
                        <?php if ($logo): ?>
                        <img src="<?= $logo ?>" style="width:64px;height:64px;border-radius:50%;object-fit:cover;border:2px solid var(--color-border);" alt="Logo">
                        <?php else: ?>
                        <div style="width:64px;height:64px;border-radius:50%;background:var(--brand-gradient);display:flex;align-items:center;justify-content:center;color:white;font-size:1.4rem;font-weight:800;"><?= strtoupper(substr($org['org_name'],0,1)) ?></div>
                        <?php endif; ?>
                        <div>
                            <button class="btn-secondary" onclick="document.getElementById('logoInput').click()" style="font-size:.82rem;padding:7px 14px;">
                                <i class="fas fa-upload"></i> Change Logo
                            </button>
                            <div style="font-size:.72rem;color:var(--color-muted);margin-top:4px;">JPG/PNG/WebP · Max 5MB</div>
                        </div>
                    </div>
                </div>
                <hr style="border-color:var(--color-border);margin:16px 0;">
                <div>
                    <div style="font-weight:600;font-size:.875rem;margin-bottom:8px;">Cover Photo</div>
                    <?php if ($cover): ?>
                    <img src="<?= $cover ?>" style="width:100%;height:100px;object-fit:cover;border-radius:8px;border:1px solid var(--color-border);margin-bottom:10px;" alt="Cover">
                    <?php endif; ?>
                    <button class="btn-secondary" onclick="document.getElementById('coverInput').click()" style="font-size:.82rem;padding:7px 14px;">
                        <i class="fas fa-image"></i> <?= $cover ? 'Change' : 'Upload' ?> Cover Photo
                    </button>
                    <div style="font-size:.72rem;color:var(--color-muted);margin-top:4px;">Recommended: 1200×400px · Max 5MB</div>
                </div>
                <div id="orgPhotoStatus" style="margin-top:12px;font-size:.82rem;color:var(--color-muted);"></div>
            </div>
        </div>
    </div>
</div><!-- /tab-profile -->

<!-- TAB: My Personal Profile -->
<div id="tab-myprofile" class="tab-pane">
    <div class="two-col">
        <div class="card">
            <div class="card-header"><h5><i class="fas fa-user-edit" style="color:var(--brand-primary);margin-right:8px;"></i>Personal Details</h5></div>
            <div class="card-body">
                <form id="myProfileForm">
                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                    <!-- org fields hidden so update_profile doesn't wipe them -->
                    <input type="hidden" name="org_name"    value="<?= e($org['org_name']) ?>">
                    <input type="hidden" name="org_email"   value="<?= e($org['org_email']??'') ?>">
                    <input type="hidden" name="org_contact" value="<?= e($org['org_contact']??'') ?>">
                    <input type="hidden" name="description" value="<?= e($org['description']??'') ?>">
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
                        <div class="form-group">
                            <label class="form-label">First Name</label>
                            <input class="form-input" type="text" name="first_name" value="<?= e(explode(' ',$_SESSION['user_name']??'',2)[0]) ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Last Name</label>
                            <input class="form-input" type="text" name="last_name" value="<?= e(explode(' ',$_SESSION['user_name']??'',2)[1]??'') ?>" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Email</label>
                        <input class="form-input" type="email" name="email" value="<?= e($userRow['email']??'') ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Phone</label>
                        <input class="form-input" type="tel" name="phone" value="<?= e($userRow['phone']??'') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Address</label>
                        <textarea class="form-textarea" name="address" rows="2"><?= e($userRow['address']??'') ?></textarea>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Bio</label>
                        <textarea class="form-textarea" name="bio" rows="2" placeholder="Short bio…"><?= e($userRow['bio']??'') ?></textarea>
                    </div>
                    <button type="submit" class="btn-primary" style="width:100%;justify-content:center;padding:11px;">
                        <i class="fas fa-save"></i> Save Personal Profile
                    </button>
                </form>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h5><i class="fas fa-camera" style="color:var(--brand-secondary);margin-right:8px;"></i>Profile Photo</h5></div>
            <div class="card-body" style="text-align:center;">
                <div id="myPhotoWrap" style="margin-bottom:16px;">
                    <?php if ($profilePhoto): ?>
                    <img src="<?= $profilePhoto ?>" style="width:100px;height:100px;border-radius:50%;object-fit:cover;border:3px solid var(--brand-primary);display:block;margin:0 auto;" alt="Profile">
                    <?php else: ?>
                    <div style="width:100px;height:100px;border-radius:50%;background:var(--brand-gradient);display:flex;align-items:center;justify-content:center;font-size:2.2rem;font-weight:800;color:white;margin:0 auto;"><?= $initials ?></div>
                    <?php endif; ?>
                </div>
                <div style="font-weight:700;font-size:1rem;margin-bottom:4px;"><?= $user_name ?></div>
                <div style="color:var(--color-muted);font-size:.82rem;margin-bottom:16px;"><?= e($userRow['email']??'') ?></div>
                <input type="file" id="myPhotoInput" accept="image/jpeg,image/png,image/webp" style="display:none;" onchange="uploadMyPhoto(this)">
                <button class="btn-secondary" onclick="document.getElementById('myPhotoInput').click()" style="font-size:.85rem;padding:8px 18px;">
                    <i class="fas fa-camera"></i> Change Photo
                </button>
                <div id="myPhotoStatus" style="font-size:.78rem;color:var(--color-muted);margin-top:8px;"></div>
                <div style="font-size:.72rem;color:var(--color-muted);margin-top:4px;">JPG/PNG/WebP · Max 3MB</div>
            </div>
        </div>
    </div>
</div><!-- /tab-myprofile -->

<?php endif; // end !needs_setup ?>
</main>

<!-- New Campaign Modal -->
<div class="modal-overlay" id="campaignModal">
    <div class="modal-box">
        <div class="modal-header">
            <h4><i class="fas fa-bullhorn" style="color:var(--brand-primary);"></i> Create New Campaign</h4>
            <button class="modal-close" onclick="closeModal('campaignModal')">&times;</button>
        </div>
        <form method="POST" action="../campaigns/submit.php" id="campaignForm" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <div class="form-group">
                <label class="form-label">Campaign Title <span style="color:var(--color-danger)">*</span></label>
                <input class="form-input" type="text" name="title" placeholder="e.g., Typhoon Relief for Mindanao" required maxlength="255">
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
                <div class="form-group">
                    <label class="form-label">Category <span style="color:var(--color-danger)">*</span></label>
                    <select class="form-input" name="category" required>
                        <option value="">Select…</option>
                        <option>Disaster Relief</option><option>Education</option><option>Health</option>
                        <option>Environment</option><option>Community</option><option>Food</option><option>Other</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Target Amount (₱) <span style="color:var(--color-danger)">*</span></label>
                    <input class="form-input" type="number" name="target_amount" placeholder="50000" min="1000" required>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Description <span style="color:var(--color-danger)">*</span></label>
                <textarea class="form-textarea" name="description" rows="3" placeholder="Describe the campaign and how funds will be used…" required></textarea>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
                <div class="form-group">
                    <label class="form-label">Location</label>
                    <input class="form-input" type="text" name="location" placeholder="City, Province">
                </div>
                <div class="form-group">
                    <label class="form-label">End Date <span style="color:var(--color-danger)">*</span></label>
                    <input class="form-input" type="date" name="end_date" required min="<?= date('Y-m-d',strtotime('+1 day')) ?>">
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Number of Beneficiaries (optional)</label>
                <input class="form-input" type="number" name="beneficiaries" placeholder="e.g., 500 families" min="1">
            </div>
            <div class="form-group">
                <label class="form-label">Campaign Cover Image (optional)</label>
                <div style="border:2px dashed var(--color-border);border-radius:var(--radius-md);padding:20px;text-align:center;cursor:pointer;transition:var(--transition);"
                     onclick="document.getElementById('campImageInput').click()"
                     id="campImgDropzone">
                    <i class="fas fa-image" style="font-size:1.5rem;color:var(--color-muted);display:block;margin-bottom:6px;"></i>
                    <span style="font-size:.855rem;color:var(--color-muted);">Click to upload a campaign photo</span>
                    <div style="font-size:.72rem;color:var(--color-muted);margin-top:4px;">JPG/PNG/WebP · Max 5MB</div>
                    <img id="campImgPreview" style="display:none;max-height:120px;margin:10px auto 0;border-radius:8px;">
                </div>
                <input type="file" id="campImageInput" name="campaign_image" accept="image/*" style="display:none;" onchange="previewCampImg(this)">
            </div>
            <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:8px;">
                <button type="button" class="btn-secondary" onclick="closeModal('campaignModal')">Cancel</button>
                <button type="submit" class="btn-primary"><i class="fas fa-paper-plane"></i> Submit for Review</button>
            </div>
        </form>
    </div>
</div>

<script src="/assets/js/global.js"></script>
<script src="/assets/js/dashboard.js"></script>
<script>
window._SESS = '<?= $_SESS_PARAM ?>';

// ── Charts ─────────────────────────────────────────────────────
const orgMonthly = <?= json_encode($monthlyDonations) ?>;
const orgCamps   = <?= json_encode($campaignPerformance) ?>;

if (orgMonthly.length) {
    new Chart(document.getElementById('orgMonthlyChart'), {
        type: 'bar',
        data: {
            labels: orgMonthly.map(r => r.label),
            datasets: [{
                label: 'Amount (₱)', data: orgMonthly.map(r => parseFloat(r.total)),
                backgroundColor: 'rgba(59,111,240,.75)', borderRadius: 6, borderSkipped: false
            }]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { display: false }, tooltip: { callbacks: { label: ctx => '₱' + ctx.raw.toLocaleString() } } },
            scales: {
                x: { grid: { display: false }, ticks: { color: '#64748b', font: { size: 11 } } },
                y: { grid: { color: 'rgba(0,0,0,.05)' }, ticks: { color: '#64748b', font: { size: 11 }, callback: v => '₱' + v.toLocaleString() } }
            }
        }
    });
}
if (orgCamps.length) {
    new Chart(document.getElementById('orgCampChart'), {
        type: 'bar',
        data: {
            labels: orgCamps.map(r => r.title.length > 18 ? r.title.substring(0,18)+'…' : r.title),
            datasets: [
                { label: 'Raised', data: orgCamps.map(r => parseFloat(r.raised)), backgroundColor: 'rgba(5,150,105,.75)', borderRadius: 4, borderSkipped: false },
                { label: 'Target', data: orgCamps.map(r => parseFloat(r.target_amount)), backgroundColor: 'rgba(59,111,240,.2)', borderRadius: 4, borderSkipped: false }
            ]
        },
        options: {
            responsive: true, maintainAspectRatio: false, indexAxis: 'y',
            plugins: { legend: { position: 'bottom', labels: { color: '#64748b', font: { size: 11 }, usePointStyle: true } },
                tooltip: { callbacks: { label: ctx => ctx.dataset.label + ': ₱' + ctx.raw.toLocaleString() } } },
            scales: {
                x: { grid: { color: 'rgba(0,0,0,.05)' }, ticks: { color: '#64748b', font: { size: 10 }, callback: v => '₱' + v.toLocaleString() } },
                y: { grid: { display: false }, ticks: { color: '#64748b', font: { size: 10 } } }
            }
        }
    });
}

// ── Campaign filter ────────────────────────────────────────────
const allCampaignCards = document.querySelectorAll('.camp-card');
document.getElementById('campSearch')?.addEventListener('input', filterCampaigns);
document.getElementById('campStatus')?.addEventListener('change', filterCampaigns);
document.getElementById('campSort')?.addEventListener('change', filterCampaigns);

function filterCampaigns() {
    const search = (document.getElementById('campSearch')?.value || '').toLowerCase();
    const status = document.getElementById('campStatus')?.value || '';
    allCampaignCards.forEach(card => {
        const title  = card.querySelector('[data-title]')?.dataset.title?.toLowerCase() || '';
        const cstatus = card.dataset.status || '';
        const okS = !search || title.includes(search);
        const okSt = !status || cstatus === status;
        card.style.display = okS && okSt ? '' : 'none';
    });
}

// ── Tab switching ──────────────────────────────────────────────
function switchTab(name, btn) {
    document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.getElementById('tab-'+name).classList.add('active');
    btn.classList.add('active');
}

// ── Campaign image preview in modal ────────────────────────────
function previewCampImg(input) {
    const file = input.files[0];
    if (!file) return;
    const preview = document.getElementById('campImgPreview');
    const zone    = document.getElementById('campImgDropzone');
    const reader  = new FileReader();
    reader.onload = e => {
        preview.src     = e.target.result;
        preview.style.display = 'block';
        zone.style.borderColor = 'var(--brand-primary)';
    };
    reader.readAsDataURL(file);
}

// ── Upload campaign image (existing campaigns) ─────────────────
function triggerCampImg(id) { document.getElementById('camp-img-'+id).click(); }
async function uploadCampImg(campId, input) {
    const file = input.files[0];
    if (!file) return;
    const fd   = new FormData();
    fd.append('image', file);
    fd.append('campaign_id', campId);
    fd.append('csrf_token', document.querySelector('meta[name="csrf-token"]').content);
    try {
        const r    = await fetch('../api/upload_campaign_image.php' + window._SESS, {method:'POST',body:fd});
        const data = await r.json();
        if (data.success) { showToast('Campaign image updated!'); setTimeout(()=>location.reload(),900); }
        else showToast(data.message||'Upload failed','error');
    } catch { showToast('Network error','error'); }
    input.value='';
}

// ── Upload org logo / cover ─────────────────────────────────────
async function uploadOrgPhoto(type, input) {
    const file   = input.files[0];
    const status = document.getElementById('orgPhotoStatus');
    if (!file) return;
    status.textContent = 'Uploading…';
    const fd = new FormData();
    fd.append('photo', file);
    fd.append('type', type);
    fd.append('csrf_token', document.querySelector('meta[name="csrf-token"]').content);
    try {
        const r    = await fetch('../api/upload_org_photo.php' + window._SESS, {method:'POST',body:fd});
        const data = await r.json();
        if (data.success) {
            showToast(data.message);
            status.textContent = '✓ Saved';
            status.style.color = 'var(--color-success)';
            setTimeout(()=>location.reload(),900);
        } else { showToast(data.message||'Failed','error'); status.textContent=''; }
    } catch { showToast('Network error','error'); status.textContent=''; }
    input.value='';
}

// ── Upload personal profile photo ──────────────────────────────
async function uploadMyPhoto(input) {
    const file   = input.files[0];
    const status = document.getElementById('myPhotoStatus');
    if (!file) return;
    if (file.size > 3*1024*1024) { showToast('Max 3MB','error'); return; }
    status.textContent = 'Uploading…';
    const fd = new FormData();
    fd.append('photo', file);
    fd.append('csrf_token', document.querySelector('meta[name="csrf-token"]').content);
    try {
        const r    = await fetch('../api/upload_photo.php' + window._SESS, {method:'POST',body:fd});
        const data = await r.json();
        if (data.success) {
            showToast('Profile photo updated!');
            status.textContent = '✓ Saved'; status.style.color='var(--color-success)';
            const wrap = document.getElementById('myPhotoWrap');
            wrap.innerHTML = `<img src="${data.url}" style="width:100px;height:100px;border-radius:50%;object-fit:cover;border:3px solid var(--brand-primary);display:block;margin:0 auto;" alt="Profile">`;
        } else { showToast(data.message||'Failed','error'); status.textContent=''; }
    } catch { showToast('Network error','error'); status.textContent=''; }
    input.value='';
}

// ── Save org profile form ──────────────────────────────────────
document.getElementById('orgProfileForm')?.addEventListener('submit', async function(e) {
    e.preventDefault();
    const btn = this.querySelector('button[type="submit"]');
    btn.disabled=true; btn.textContent='Saving…';
    try {
        const r = await fetch('../api/update_profile.php' + window._SESS, {method:'POST',body:new FormData(this)});
        const d = await r.json();
        if (d.success) showToast('Organization profile saved!');
        else showToast(d.message||'Failed','error');
    } catch { showToast('Network error','error'); }
    finally { btn.disabled=false; btn.innerHTML='<i class="fas fa-save"></i> Save Organization Profile'; }
});

// ── Save personal profile form ─────────────────────────────────
document.getElementById('myProfileForm')?.addEventListener('submit', async function(e) {
    e.preventDefault();
    const btn = this.querySelector('button[type="submit"]');
    btn.disabled=true; btn.textContent='Saving…';
    try {
        const r = await fetch('../api/update_profile.php' + window._SESS, {method:'POST',body:new FormData(this)});
        const d = await r.json();
        if (d.success) showToast('Personal profile saved!');
        else showToast(d.message||'Failed','error');
    } catch { showToast('Network error','error'); }
    finally { btn.disabled=false; btn.innerHTML='<i class="fas fa-save"></i> Save Personal Profile'; }
});
</script>

<!-- Bottom Navigation (mobile) -->
<nav class="bottom-nav">
    <div class="bottom-nav-inner">
        <button class="bnav-item active" onclick="mobileSwitchTab('campaigns',this)">
            <i class="fas fa-bullhorn"></i>
            <span>Campaigns</span>
        </button>
        <button class="bnav-item" onclick="mobileSwitchTab('profile',this)">
            <i class="fas fa-building"></i>
            <span>Org</span>
        </button>
        <button class="bnav-item" onclick="mobileSwitchTab('myprofile',this)">
            <i class="fas fa-user"></i>
            <span>Profile</span>
        </button>
        <a href="../verification/submit.php?_sess=UMDC_ORG" class="bnav-item">
            <i class="fas fa-id-badge"></i>
            <span>Verify</span>
        </a>
        <button class="bnav-item" onclick="openModal('campaignModal')">
            <i class="fas fa-plus-circle"></i>
            <span>New</span>
        </button>
    </div>
</nav>
<script>
function mobileSwitchTab(name, btn) {
    document.querySelectorAll('.bnav-item').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    // Find and click the desktop tab button
    const tabBtns = document.querySelectorAll('.tab-btn');
    tabBtns.forEach(tb => {
        if (tb.getAttribute('onclick') && tb.getAttribute('onclick').includes("'"+name+"'")) {
            tb.click();
        }
    });
    // fallback: call switchTab directly
    const pane = document.getElementById('tab-'+name);
    if (pane) {
        document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        pane.classList.add('active');
    }
}
</script>

<script src="/assets/js/notifications.js"></script>
</body>
</html>
