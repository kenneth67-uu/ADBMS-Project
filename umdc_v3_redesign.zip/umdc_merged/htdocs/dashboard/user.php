<?php
defined('UMDC_APP') or define('UMDC_APP', true);
require_once __DIR__ . '/../Config/security.php';
require_once __DIR__ . '/../Config/db.php';
umdc_session_start();
requireRole('user');
setSecureHeaders();

$_SESS_PARAM = '?_sess=UMDC_USER';

require_once __DIR__ . '/../Config/notifications.php';

$user_id   = currentUserId();
$user_name = e($_SESSION['user_name'] ?? 'User');
$initials  = strtoupper(substr($_SESSION['user_name'] ?? 'U', 0, 1) . (strpos($_SESSION['user_name'] ?? '', ' ') !== false ? substr(strrchr($_SESSION['user_name'], ' '), 1, 1) : ''));

// Quick stats
$stats = [
    'total_donated'       => $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM donations WHERE user_id=? AND status='completed'"),
    'donation_count'      => $pdo->prepare("SELECT COUNT(*) FROM donations WHERE user_id=?"),
    'campaigns_supported' => $pdo->prepare("SELECT COUNT(DISTINCT campaign_id) FROM donations WHERE user_id=?"),
    'pending_count'       => $pdo->prepare("SELECT COUNT(*) FROM donations WHERE user_id=? AND status='pending'"),
];
foreach ($stats as $k => $s) { $s->execute([$user_id]); $stats[$k] = $s->fetchColumn(); }

// Monthly chart data (last 6 months)
$monthlyStmt = $pdo->prepare("
    SELECT DATE_FORMAT(created_at,'%b') AS label,
           DATE_FORMAT(created_at,'%Y-%m') AS month_key,
           COALESCE(SUM(amount),0) AS total,
           COUNT(*) AS cnt
    FROM donations
    WHERE user_id=? AND status='completed'
      AND created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY month_key, label ORDER BY month_key ASC
");
$monthlyStmt->execute([$user_id]);
$monthlyData = $monthlyStmt->fetchAll(PDO::FETCH_ASSOC);

// Category breakdown
$catStmt = $pdo->prepare("
    SELECT COALESCE(c.category,'General') AS category,
           COALESCE(SUM(d.amount),0) AS total,
           COUNT(*) AS cnt
    FROM donations d
    JOIN campaigns c ON d.campaign_id=c.campaign_id
    WHERE d.user_id=? AND d.status='completed'
    GROUP BY c.category ORDER BY total DESC LIMIT 5
");
$catStmt->execute([$user_id]);
$catData = $catStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<meta name="csrf-token" content="<?= csrf_token() ?>">
<meta name="sess-name" content="UMDC_USER">
<title>Dashboard – UMDC</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<link rel="stylesheet" href="/assets/css/global.css">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<style>
/* ── Chart grid ─────────────────────────────────────────────── */
.chart-grid { display: grid; grid-template-columns: 1.5fr 1fr; gap: 20px; margin-bottom: 24px; }
.chart-wrap { position: relative; height: 220px; }
canvas { max-height: 220px; }

/* ── Filter bar ─────────────────────────────────────────────── */
.filter-bar {
  display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
  padding: 12px 20px 14px; border-bottom: 1px solid var(--color-border);
  background: var(--color-surface-2);
}
.filter-input {
  padding: 6px 12px; border-radius: 20px; border: 1.5px solid var(--color-border);
  background: var(--color-surface); color: var(--color-text);
  font-family: var(--font-sans); font-size: .82rem; min-width: 170px; transition: border-color .15s;
}
.filter-input:focus { outline: none; border-color: var(--brand-primary); }
.filter-select {
  padding: 6px 12px; border-radius: 20px; border: 1.5px solid var(--color-border);
  background: var(--color-surface); color: var(--color-text);
  font-family: var(--font-sans); font-size: .82rem; cursor: pointer;
}
.filter-select:focus { outline: none; border-color: var(--brand-primary); }
.filter-count { margin-left: auto; font-size: .78rem; color: var(--color-muted); white-space: nowrap; }

/* ── Stat accent colors ─────────────────────────────────────── */
.stat-card.green::before  { background: var(--color-success); }
.stat-card.amber::before  { background: var(--color-warning); }
.stat-card.blue::before   { background: var(--brand-primary); }
.stat-card.purple::before { background: var(--brand-secondary); }
.stat-icon {
  position: absolute; top: 18px; right: 18px;
  font-size: 1.4rem; opacity: .1; color: var(--color-text);
}

/* ── Summary chips ──────────────────────────────────────────── */
.summary-strip { display: flex; gap: 6px; flex-wrap: wrap; padding: 14px 20px 0; }
.summary-chip {
  display: inline-flex; align-items: center; gap: 5px;
  background: var(--color-surface-2); border: 1px solid var(--color-border);
  border-radius: 8px; padding: 4px 10px; font-size: .75rem; color: var(--color-muted);
}
.summary-chip strong { color: var(--color-text); }

@media (max-width: 768px) {
  .chart-grid { grid-template-columns: 1fr; }
  .filter-bar { padding: 10px 14px; gap: 6px; }
  .filter-input, .filter-select { font-size: 16px; } /* prevent iOS zoom */
}
</style>
<link rel="stylesheet" href="/assets/css/notifications.css">
</head>
<body>

<header class="mobile-header">
    <div class="brand-name">UMDC</div>
    <div class="mobile-header-right">
        <?php require_once __DIR__ . '/../components/notification_bell.php'; ?>
        <button class="btn-secondary" onclick="loadSection('profile')" style="padding:6px 12px;font-size:.8rem;">
            <i class="fas fa-user"></i>
        </button>
        <button class="logout-btn" data-logout style="padding:6px 8px;font-size:1rem;background:var(--color-surface-2);border:1px solid var(--color-border);border-radius:var(--radius-md);">
            <i class="fas fa-sign-out-alt" style="color:var(--color-danger);"></i>
        </button>
    </div>
</header>
<button class="mobile-toggle" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>

<aside class="sidebar">
    <div class="sidebar-logo">
        <div class="brand-name">UMDC</div>
        <div class="brand-sub">Donor Portal</div>
    </div>
    <nav class="sidebar-nav">
        <span class="nav-section-label">Main</span>
        <button class="sidebar-link active" id="snav-campaigns" onclick="switchSection('campaigns',this)">
            <i class="fas fa-hand-holding-heart"></i> Browse Campaigns
        </button>
        <button class="sidebar-link" id="snav-my-donations" onclick="switchSection('my-donations',this)">
            <i class="fas fa-receipt"></i> My Donations
        </button>
        <button class="sidebar-link" id="snav-leaderboard" onclick="switchSection('leaderboard',this)">
            <i class="fas fa-trophy"></i> Leaderboard
        </button>
        <button class="sidebar-link" id="snav-transparency" onclick="switchSection('transparency',this)">
            <i class="fas fa-shield-alt"></i> Transparency
        </button>
        <span class="nav-section-label">Account</span>
        <button class="sidebar-link" id="snav-profile" onclick="switchSection('profile',this)">
            <i class="fas fa-user"></i> My Profile
        </button>
        <a href="/notifications/index.php<?= $_SESS_PARAM ?>" class="sidebar-link" id="snav-notifications">
            <i class="fas fa-bell"></i> Notifications
            <?php
            $nb_unread = Notifier::getUnreadCount($pdo, $user_id);
            if ($nb_unread > 0): ?>
            <span class="badge-pill badge-danger" style="margin-left:auto;font-size:.65rem;"><?= min($nb_unread,99) ?></span>
            <?php endif; ?>
        </a>
        <a href="/verification/submit.php<?= $_SESS_PARAM ?>" class="sidebar-link">
            <i class="fas fa-id-card"></i> Verification
        </a>
    </nav>
    <div class="sidebar-footer">
        <div class="sidebar-user">
            <div class="avatar"><?= $initials ?></div>
            <div>
                <div class="sidebar-user-name"><?= $user_name ?></div>
                <div class="sidebar-user-role">Donor</div>
            </div>
            <button class="logout-btn" data-logout title="Sign out"><i class="fas fa-sign-out-alt"></i></button>
        </div>
    </div>
</aside>

<main class="main-content">
    <div class="page-header">
        <h1>Welcome back, <?= strtok($user_name, ' ') ?> 👋</h1>
        <p>Track your impact, filter your history, and discover new campaigns to support.</p>
    </div>

    <?php if (isset($_GET['success']) && $_GET['success'] === 'payment_complete'): ?>
    <div class="alert alert-success" data-auto-dismiss>
        <i class="fas fa-check-circle"></i>
        <span>Your donation was completed successfully! Thank you for making a difference.</span>
    </div>
    <?php endif; ?>

    <!-- Stats -->
    <div class="stats-grid">
        <div class="stat-card green">
            <div class="stat-icon"><i class="fas fa-peso-sign"></i></div>
            <div class="stat-label">Total Donated</div>
            <div class="stat-value" style="font-family:var(--font-mono);color:var(--color-success)">₱<?= number_format((float)$stats['total_donated'], 2) ?></div>
            <div class="stat-sub">Lifetime contributions</div>
        </div>
        <div class="stat-card blue">
            <div class="stat-icon"><i class="fas fa-heart"></i></div>
            <div class="stat-label">Donations Made</div>
            <div class="stat-value"><?= number_format((int)$stats['donation_count']) ?></div>
            <div class="stat-sub">All types combined</div>
        </div>
        <div class="stat-card purple">
            <div class="stat-icon"><i class="fas fa-bullhorn"></i></div>
            <div class="stat-label">Campaigns Supported</div>
            <div class="stat-value"><?= number_format((int)$stats['campaigns_supported']) ?></div>
            <div class="stat-sub">Unique campaigns</div>
        </div>
        <div class="stat-card amber">
            <div class="stat-icon"><i class="fas fa-clock"></i></div>
            <div class="stat-label">Pending</div>
            <div class="stat-value"><?= (int)$stats['pending_count'] ?></div>
            <div class="stat-sub">Awaiting completion</div>
        </div>
    </div>

    <!-- Charts -->
    <?php if (!empty($monthlyData) || !empty($catData)): ?>
    <div class="chart-grid">
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-chart-line" style="color:var(--brand-primary);margin-right:8px"></i>My Giving Over Time</h5>
                <span style="font-size:.78rem;color:var(--color-muted)">Last 6 months</span>
            </div>
            <div class="card-body">
                <div class="chart-wrap"><canvas id="monthlyChart"></canvas></div>
            </div>
        </div>
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-chart-pie" style="color:var(--brand-secondary);margin-right:8px"></i>By Category</h5>
            </div>
            <div class="card-body">
                <div class="chart-wrap"><canvas id="catChart"></canvas></div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div id="dynamic-content"></div>
</main>

<!-- Donation Modal -->
<div class="modal-overlay" id="donationModal">
    <div class="modal-box">
        <div class="modal-header">
            <h4><i class="fas fa-heart" style="color:var(--brand-primary)"></i> Make a Donation</h4>
            <button class="modal-close" onclick="closeModal('donationModal')">&times;</button>
        </div>
        <div id="donation-campaign-info" style="margin-bottom:20px;"></div>
        <form id="donationForm" novalidate>
            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
            <input type="hidden" name="campaign_id" id="campaign_id">
            <div class="form-group">
                <label class="form-label">Donation Type</label>
                <select class="form-input" name="donation_type" id="donation_type" onchange="DonationForm.toggleTypeFields(this.value)">
                    <option value="cash">💰 Cash Donation</option>
                    <option value="item">📦 Item Donation</option>
                    <option value="service">🔧 Service Offer</option>
                </select>
            </div>
            <div id="cash-fields">
                <div class="form-group">
                    <label class="form-label">Amount (₱)</label>
                    <input class="form-input" type="number" name="amount" id="amount" placeholder="Enter amount (min ₱10)" min="10" step="0.01">
                    <div class="form-error" id="amount-error"></div>
                </div>
                <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px;">
                    <?php foreach ([50,100,250,500,1000] as $amt): ?>
                    <button type="button" class="btn-secondary" style="padding:6px 14px;font-size:.8rem;"
                            onclick="document.getElementById('amount').value='<?= $amt ?>'"><?= '₱' . number_format($amt) ?></button>
                    <?php endforeach; ?>
                </div>
            </div>
            <div id="item-fields" style="display:none;">
                <div class="form-group">
                    <label class="form-label">Item Name</label>
                    <input class="form-input" type="text" name="item_name" id="item_name" placeholder="e.g., Blankets, Canned Goods">
                </div>
                <div class="form-group">
                    <label class="form-label">Quantity</label>
                    <input class="form-input" type="number" name="quantity" placeholder="1" min="1" max="9999">
                </div>
                <div class="form-group">
                    <label class="form-label">Description (optional)</label>
                    <textarea class="form-textarea" name="item_description" placeholder="Condition, size, brand..." rows="2"></textarea>
                </div>
            </div>
            <div id="service-fields" style="display:none;">
                <div class="form-group">
                    <label class="form-label">Describe Your Service</label>
                    <textarea class="form-textarea" name="service_description" id="service_description" placeholder="What service can you offer?" rows="3"></textarea>
                </div>
            </div>
            <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:8px;">
                <button type="button" class="btn-secondary" onclick="closeModal('donationModal')">Cancel</button>
                <button type="button" class="btn-primary" onclick="DonationForm.submit(this)">
                    <i class="fas fa-check"></i> Confirm Donation
                </button>
            </div>
        </form>
    </div>
</div>

<nav class="bottom-nav">
    <div class="bottom-nav-inner">
        <button class="bnav-item active" id="bnav-campaigns" onclick="bnavSwitch('campaigns',this)"><i class="fas fa-hand-holding-heart"></i><span>Campaigns</span></button>
        <button class="bnav-item" id="bnav-my-donations" onclick="bnavSwitch('my-donations',this)"><i class="fas fa-receipt"></i><span>Donations</span></button>
        <button class="bnav-item" id="bnav-leaderboard" onclick="bnavSwitch('leaderboard',this)"><i class="fas fa-trophy"></i><span>Leaders</span></button>
        <button class="bnav-item" id="bnav-transparency" onclick="bnavSwitch('transparency',this)"><i class="fas fa-shield-alt"></i><span>Ledger</span></button>
        <button class="bnav-item" id="bnav-profile" onclick="bnavSwitch('profile',this)"><i class="fas fa-user"></i><span>Profile</span></button>
    </div>
</nav>

<script src="/assets/js/global.js"></script>
<script src="/assets/js/dashboard.js"></script>
<script src="/assets/js/user.js"></script>
<script>
window._SESS = '<?= $_SESS_PARAM ?>';

/* ── Charts ─────────────────────────────────────────────────── */
const monthlyRaw = <?= json_encode($monthlyData) ?>;
const catRaw     = <?= json_encode($catData) ?>;

if (monthlyRaw.length) {
    new Chart(document.getElementById('monthlyChart'), {
        type: 'bar',
        data: {
            labels: monthlyRaw.map(r => r.label),
            datasets: [{
                label: 'Amount Donated (₱)',
                data: monthlyRaw.map(r => parseFloat(r.total)),
                backgroundColor: 'rgba(59,111,240,.75)',
                borderRadius: 6, borderSkipped: false,
            }]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { display: false },
                tooltip: { callbacks: { label: ctx => '₱' + ctx.raw.toLocaleString() } }
            },
            scales: {
                x: { grid: { display: false }, ticks: { color: '#64748b', font: { size: 11 } } },
                y: { grid: { color: 'rgba(0,0,0,.05)' },
                    ticks: { color: '#64748b', font: { size: 11 }, callback: v => '₱' + v.toLocaleString() } }
            }
        }
    });
}
if (catRaw.length) {
    const colors = ['#3b6ff0','#7c3aed','#059669','#d97706','#0284c7'];
    new Chart(document.getElementById('catChart'), {
        type: 'doughnut',
        data: {
            labels: catRaw.map(r => r.category),
            datasets: [{ data: catRaw.map(r => parseFloat(r.total)), backgroundColor: colors, borderWidth: 0, hoverOffset: 8 }]
        },
        options: {
            responsive: true, maintainAspectRatio: false, cutout: '65%',
            plugins: {
                legend: { position: 'bottom', labels: { color: '#64748b', font: { size: 11 }, padding: 10, usePointStyle: true } },
                tooltip: { callbacks: { label: ctx => ctx.label + ': ₱' + ctx.raw.toLocaleString() } }
            }
        }
    });
}

/* ── Section switching ──────────────────────────────────────── */
function switchSection(section, btn) {
    document.querySelectorAll('.sidebar-link').forEach(l => l.classList.remove('active'));
    if (btn) btn.classList.add('active');
    loadSection(section);
}
function bnavSwitch(section, btn) {
    document.querySelectorAll('.bnav-item').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    loadSection(section);
}

/* ── Override loadMyDonations with filter support ───────────── */
window.loadMyDonations = function(el) {
    if (!el) el = document.getElementById('dynamic-content');
    if (!el) return;
    el.innerHTML = loadingHTML('Loading your donations...');

    apiFetch('../api/my_donation.php')
        .then(data => {
            if (!data.success) throw new Error(data.message);
            renderDonationsWithFilter(el, data.donations);
        })
        .catch(err => { el.innerHTML = emptyHTML('fa-exclamation-circle', 'Failed to load', err.message); });
};

function renderDonationsWithFilter(el, allDonations) {
    if (!allDonations.length) {
        el.innerHTML = emptyHTML('fa-receipt', 'No donations yet', 'Browse campaigns and make your first donation!');
        return;
    }
    const completed = allDonations.filter(d => d.status === 'completed');
    const totalAmt  = completed.reduce((s, d) => s + parseFloat(d.amount || 0), 0);
    const cashCnt   = allDonations.filter(d => d.donation_type === 'cash').length;
    const itemCnt   = allDonations.filter(d => d.donation_type === 'item').length;

    el.innerHTML = `
    <div class="card">
        <div class="card-header">
            <h5><i class="fas fa-receipt" style="color:var(--brand-primary);margin-right:8px"></i>My Donations</h5>
            <span style="font-size:.82rem;color:var(--color-muted);">${allDonations.length} record${allDonations.length !== 1 ? 's' : ''}</span>
        </div>
        <div class="summary-strip">
            <div class="summary-chip"><i class="fas fa-peso-sign" style="color:var(--color-success)"></i><strong>₱${totalAmt.toLocaleString(undefined,{minimumFractionDigits:2})}</strong> total</div>
            <div class="summary-chip"><i class="fas fa-check-circle" style="color:var(--color-success)"></i><strong>${completed.length}</strong> completed</div>
            <div class="summary-chip"><i class="fas fa-coins" style="color:var(--brand-primary)"></i><strong>${cashCnt}</strong> cash</div>
            <div class="summary-chip"><i class="fas fa-box" style="color:var(--brand-secondary)"></i><strong>${itemCnt}</strong> item${itemCnt !== 1 ? 's' : ''}</div>
        </div>
        <div class="filter-bar">
            <input class="filter-input" type="text" id="df-search" placeholder="🔍 Search campaign…" oninput="applyDonationFilters()">
            <select class="filter-select" id="df-type" onchange="applyDonationFilters()">
                <option value="">All Types</option>
                <option value="cash">Cash</option>
                <option value="item">Item</option>
                <option value="service">Service</option>
            </select>
            <select class="filter-select" id="df-status" onchange="applyDonationFilters()">
                <option value="">All Statuses</option>
                <option value="completed">Completed</option>
                <option value="pending">Pending</option>
                <option value="failed">Failed</option>
                <option value="refunded">Refunded</option>
            </select>
            <select class="filter-select" id="df-sort" onchange="applyDonationFilters()">
                <option value="newest">Newest First</option>
                <option value="oldest">Oldest First</option>
                <option value="amount_desc">Highest Amount</option>
                <option value="amount_asc">Lowest Amount</option>
            </select>
            <span class="filter-count" id="df-count"></span>
        </div>
        <div style="overflow-x:auto;">
            <table class="table-custom">
                <thead><tr>
                    <th>Type</th><th>Campaign</th><th>Category</th>
                    <th>Amount</th><th>Status</th><th>Date</th><th>Actions</th>
                </tr></thead>
                <tbody id="donations-tbody"></tbody>
            </table>
        </div>
    </div>`;

    window._allDonations = allDonations;
    applyDonationFilters();
}

window.applyDonationFilters = function() {
    const search = (document.getElementById('df-search')?.value || '').toLowerCase();
    const type   = document.getElementById('df-type')?.value   || '';
    const status = document.getElementById('df-status')?.value || '';
    const sort   = document.getElementById('df-sort')?.value   || 'newest';
    const all    = window._allDonations || [];

    let filtered = all.filter(d => {
        const okSearch = !search || d.campaign_title.toLowerCase().includes(search) || (d.category||'').toLowerCase().includes(search);
        const okType   = !type   || d.donation_type === type;
        const okStatus = !status || d.status === status;
        return okSearch && okType && okStatus;
    });

    filtered.sort((a, b) => {
        if (sort === 'newest')      return new Date(b.created_at) - new Date(a.created_at);
        if (sort === 'oldest')      return new Date(a.created_at) - new Date(b.created_at);
        if (sort === 'amount_desc') return parseFloat(b.amount||0) - parseFloat(a.amount||0);
        if (sort === 'amount_asc')  return parseFloat(a.amount||0) - parseFloat(b.amount||0);
        return 0;
    });

    const countEl = document.getElementById('df-count');
    if (countEl) countEl.textContent = `${filtered.length} of ${all.length} shown`;

    const typeIcons = { cash:'fa-peso-sign', item:'fa-box', service:'fa-screwdriver-wrench' };
    const tbody = document.getElementById('donations-tbody');
    if (!tbody) return;

    if (!filtered.length) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;padding:40px;color:var(--color-muted);">
            <i class="fas fa-filter" style="display:block;font-size:1.5rem;opacity:.3;margin-bottom:8px;"></i>
            No donations match your filters</td></tr>`;
        return;
    }

    tbody.innerHTML = filtered.map(d => `
        <tr>
            <td><i class="fas ${typeIcons[d.donation_type]||'fa-gift'}" style="color:var(--brand-primary);margin-right:6px"></i>${d.donation_type}</td>
            <td style="max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${escapeHtml(d.campaign_title)}">${escapeHtml(d.campaign_title)}</td>
            <td><span style="font-size:.7rem;background:rgba(59,111,240,.08);color:var(--brand-primary);border-radius:6px;padding:2px 8px;font-weight:600;">${escapeHtml(d.category||'General')}</span></td>
            <td class="amount-mono">${d.amount ? '₱' + parseFloat(d.amount).toLocaleString(undefined,{minimumFractionDigits:2}) : '—'}</td>
            <td><span class="badge-pill badge-${escapeHtml(d.status)}">${d.status}</span></td>
            <td style="white-space:nowrap">${formatDate(d.created_at)}</td>
            <td>
                <div style="display:flex;gap:6px;flex-wrap:wrap;">
                ${d.status==='pending'&&d.donation_type==='cash'
                    ? `<a href="../donations/cash.php?id=${d.donation_id}" class="btn-primary" style="font-size:.72rem;padding:4px 10px;"><i class="fas fa-credit-card"></i> Pay</a>` : ''}
                ${d.receipt_number
                    ? `<button class="btn-secondary" style="font-size:.72rem;padding:4px 10px;" onclick="window.open('../receipts/view.php?id=${d.donation_id}','_blank')"><i class="fas fa-receipt"></i> Receipt</button>` : ''}
                ${d.public_hash
                    ? `<button class="btn-secondary" style="font-size:.72rem;padding:4px 10px;" onclick="window.open('../transactions/verify.php?hash=${escapeHtml(d.public_hash)}','_blank')"><i class="fas fa-link"></i> Verify</button>` : ''}
                </div>
            </td>
        </tr>`).join('');
};

loadSection('campaigns');
</script>
<script src="/assets/js/notifications.js"></script>
</body>
</html>
