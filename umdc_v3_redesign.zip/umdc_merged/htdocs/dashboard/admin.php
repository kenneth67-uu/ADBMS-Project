<?php
defined('UMDC_APP') or define('UMDC_APP', true);
require_once __DIR__ . '/../Config/security.php';
require_once __DIR__ . '/../Config/db.php';
umdc_session_start();
requireRole('admin');
setSecureHeaders();
$_SESS_PARAM = '?_sess=UMDC_ADMIN';

// ── Stats ────────────────────────────────────────────────────
$overview        = $pdo->query("SELECT * FROM vw_admin_overview")->fetch() ?: [];
$total_users     = (int)($overview['total_users']        ?? 0);
$total_orgs      = (int)($overview['total_orgs']         ?? 0);
$total_campaigns = (int)($overview['total_campaigns']    ?? 0);
$active_campaigns= (int)($overview['active_campaigns']   ?? 0);
$total_donations = (int)($overview['total_donations']    ?? 0);
$total_raised    = (float)($overview['total_raised']     ?? 0);
$pending_approvals=(int)($overview['pending_approvals']  ?? 0);
$open_flags      = (int)($overview['open_flags']         ?? 0);

// ── Monthly trend (last 6 months donations) ──────────────────
$monthly = $pdo->query("
    SELECT DATE_FORMAT(created_at,'%b') AS month,
           COUNT(*) AS count,
           COALESCE(SUM(CASE WHEN donation_type='cash' THEN amount ELSE 0 END),0) AS cash
    FROM donations
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
      AND status = 'completed'
    GROUP BY MONTH(created_at), DATE_FORMAT(created_at,'%b')
    ORDER BY MONTH(created_at)
")->fetchAll();

// ── Top campaigns ─────────────────────────────────────────────
$top_campaigns = $pdo->query("
    SELECT c.campaign_id, c.title, c.target_amount, c.current_amount, c.status,
           o.org_name,
           COUNT(d.donation_id) AS donor_count
    FROM campaigns c
    JOIN organizations o ON c.org_id = o.org_id
    LEFT JOIN donations d ON d.campaign_id = c.campaign_id AND d.status='completed'
    GROUP BY c.campaign_id
    ORDER BY c.current_amount DESC
    LIMIT 6
")->fetchAll();

// ── Recent donations ──────────────────────────────────────────
$recent_donations = $pdo->query("
    SELECT d.donation_id, d.donation_type, d.amount, d.status, d.created_at,
           CONCAT(u.first_name,' ',u.last_name) AS donor_name,
           c.title AS campaign_title
    FROM donations d
    JOIN users u ON d.user_id = u.user_id
    JOIN campaigns c ON d.campaign_id = c.campaign_id
    ORDER BY d.created_at DESC
    LIMIT 8
")->fetchAll();

// ── Recent users ──────────────────────────────────────────────
$recent_users = $pdo->query("
    SELECT u.user_id, u.first_name, u.last_name, u.email, u.status, u.created_at,
           r.role_name
    FROM users u
    JOIN roles r ON u.role_id = r.role_id
    ORDER BY u.created_at DESC
    LIMIT 6
")->fetchAll();

// ── Donation type breakdown ───────────────────────────────────
$type_breakdown = $pdo->query("
    SELECT donation_type, COUNT(*) AS cnt,
           COALESCE(SUM(amount),0) AS total
    FROM donations WHERE status='completed'
    GROUP BY donation_type
")->fetchAll(PDO::FETCH_UNIQUE);

// ── Pending approvals list ────────────────────────────────────
$pending_list = $pdo->query("
    SELECT a.approval_id, a.entity_type, a.entity_id, a.created_at,
           CASE
             WHEN a.entity_type='campaign'     THEN c.title
             WHEN a.entity_type='organization' THEN o.org_name
             ELSE 'Unknown'
           END AS entity_name
    FROM approvals a
    LEFT JOIN campaigns c     ON a.entity_type='campaign'     AND c.campaign_id = a.entity_id
    LEFT JOIN organizations o ON a.entity_type='organization' AND o.org_id      = a.entity_id
    WHERE a.status = 'pending'
    ORDER BY a.created_at ASC
    LIMIT 5
")->fetchAll();

// ── Helpers ───────────────────────────────────────────────────
function fmt_php(float $n): string {
    if ($n >= 1_000_000) return '₱' . number_format($n/1_000_000,1) . 'M';
    if ($n >= 1_000)     return '₱' . number_format($n/1_000,1)     . 'K';
    return '₱' . number_format($n,2);
}
function time_ago_admin(string $dt): string {
    $d = time() - strtotime($dt);
    if ($d < 60)    return 'Just now';
    if ($d < 3600)  return floor($d/60)  . 'm ago';
    if ($d < 86400) return floor($d/3600).'h ago';
    return date('M j', strtotime($dt));
}
$admin_name = e($_SESSION['user_name'] ?? 'Admin');
$hour       = (int)date('H');
$greeting   = $hour < 12 ? 'Good morning' : ($hour < 18 ? 'Good afternoon' : 'Good evening');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Admin Dashboard — UMDC</title>
<?php include __DIR__ . '/../components/admin_sidebar.php'; ?>
<style>
/* ── Chart canvas ── */
#donationChart, #typeChart { max-height: 260px; }
/* ── Campaign progress ── */
.camp-progress-wrap { margin-top:6px; }
.camp-org { font-size:.72rem; color:var(--text-muted); margin-top:2px; }
.camp-pct  { font-size:.72rem; color:var(--text-muted); margin-left:auto; flex-shrink:0; }
.camp-row  { display:flex; align-items:center; gap:8px; }
/* ── Approval item ── */
.appr-item {
  display:flex; align-items:center; gap:12px;
  padding:12px 0; border-bottom:1px solid var(--border);
}
.appr-item:last-child { border-bottom:none; }
.appr-icon {
  width:36px; height:36px; border-radius:10px;
  display:flex; align-items:center; justify-content:center;
  font-size:.85rem; flex-shrink:0;
}
.appr-icon.campaign     { background:rgba(108,114,255,.12); color:var(--c-purple); }
.appr-icon.organization { background:rgba(87,195,255,.12);  color:var(--c-cyan); }
.appr-name  { font-size:.85rem; font-weight:600; color:var(--text); }
.appr-type  { font-size:.72rem; color:var(--text-muted); text-transform:capitalize; }
.appr-time  { font-size:.72rem; color:var(--text-muted); margin-left:auto; flex-shrink:0; }
.appr-approve-btn {
  padding:5px 12px; border-radius:var(--radius-sm);
  background:rgba(34,211,165,.12); color:var(--success);
  border:1px solid rgba(34,211,165,.2);
  font-size:.72rem; font-weight:700; cursor:pointer;
  font-family:var(--font-sans); transition:var(--transition);
}
.appr-approve-btn:hover { background:var(--success); color:#000; }
</style>
</head>

<main class="admin-main">

  <!-- Topbar -->
  <div class="admin-topbar" style="padding-top:4px;">
    <div class="admin-topbar-left">
      <h1><?= $greeting ?>, <?= $admin_name ?> 👋</h1>
      <p>Here's what's happening on your platform today — <?= date('F j, Y') ?></p>
    </div>
    <div class="admin-topbar-right">
      <?php require_once __DIR__ . '/../components/notification_bell.php'; ?>
      <a href="/public/index.php" class="admin-qa-btn" target="_blank">
        <i class="fas fa-arrow-up-right-from-square"></i> View Site
      </a>
    </div>
  </div>

  <!-- Alert: pending items -->
  <?php if ($pending_approvals > 0 || $open_flags > 0): ?>
  <div class="admin-alert warning" style="margin-bottom:20px;">
    <i class="fas fa-circle-exclamation"></i>
    <span>
      <?php if ($pending_approvals > 0): ?>
        <strong><?= $pending_approvals ?> pending approval<?= $pending_approvals > 1?'s':'' ?></strong>
        waiting for review.
        <a href="/admin/approvals.php<?= $_SESS_PARAM ?>">Review now →</a>
      <?php endif; ?>
      <?php if ($open_flags > 0): ?>
        &nbsp;&nbsp;|&nbsp;&nbsp;
        <strong><?= $open_flags ?> open fraud flag<?= $open_flags > 1?'s':'' ?></strong>.
        <a href="/admin/fraud.php<?= $_SESS_PARAM ?>">View →</a>
      <?php endif; ?>
    </span>
  </div>
  <?php endif; ?>

  <!-- Quick Actions -->
  <div class="admin-quick-actions">
    <a href="/admin/approvals.php<?= $_SESS_PARAM ?>" class="admin-qa-btn"><i class="fas fa-check-double"></i> Approvals</a>
    <a href="/admin/users.php<?= $_SESS_PARAM ?>"     class="admin-qa-btn"><i class="fas fa-user-plus"></i> Add User</a>
    <a href="/admin/fraud.php<?= $_SESS_PARAM ?>"     class="admin-qa-btn"><i class="fas fa-flag"></i> Fraud Queue</a>
    <a href="/admin/reports.php<?= $_SESS_PARAM ?>"   class="admin-qa-btn"><i class="fas fa-file-export"></i> Export Report</a>
    <a href="/admin/notification_settings.php<?= $_SESS_PARAM ?>" class="admin-qa-btn"><i class="fas fa-bell"></i> Notifications</a>
  </div>

  <!-- Stats Grid -->
  <div class="admin-stats-grid">
    <div class="admin-stat-card highlight">
      <div class="admin-stat-icon purple"><i class="fas fa-peso-sign"></i></div>
      <div class="admin-stat-label">Total Raised</div>
      <div class="admin-stat-value mono"><?= fmt_php($total_raised) ?></div>
      <span class="admin-stat-trend up"><i class="fas fa-arrow-trend-up"></i> All time</span>
    </div>
    <div class="admin-stat-card">
      <div class="admin-stat-icon cyan"><i class="fas fa-heart"></i></div>
      <div class="admin-stat-label">Total Donations</div>
      <div class="admin-stat-value"><?= number_format($total_donations) ?></div>
      <?php
        $cash_count = (int)($type_breakdown['cash']['cnt'] ?? 0);
        $item_count = (int)($type_breakdown['item']['cnt'] ?? 0);
      ?>
      <span class="admin-stat-trend up"><i class="fas fa-hand-holding-heart"></i> <?= $cash_count ?> cash · <?= $item_count ?> items</span>
    </div>
    <div class="admin-stat-card">
      <div class="admin-stat-icon amber"><i class="fas fa-bullhorn"></i></div>
      <div class="admin-stat-label">Campaigns</div>
      <div class="admin-stat-value"><?= $total_campaigns ?></div>
      <span class="admin-stat-trend up"><i class="fas fa-circle-check"></i> <?= $active_campaigns ?> active</span>
    </div>
    <div class="admin-stat-card">
      <div class="admin-stat-icon green"><i class="fas fa-users"></i></div>
      <div class="admin-stat-label">Registered Users</div>
      <div class="admin-stat-value"><?= number_format($total_users) ?></div>
      <span class="admin-stat-trend up"><i class="fas fa-building"></i> <?= $total_orgs ?> orgs</span>
    </div>
    <div class="admin-stat-card">
      <div class="admin-stat-icon violet"><i class="fas fa-clock"></i></div>
      <div class="admin-stat-label">Pending Approvals</div>
      <div class="admin-stat-value"><?= $pending_approvals ?></div>
      <?php if ($pending_approvals > 0): ?>
      <span class="admin-stat-trend warn"><i class="fas fa-exclamation"></i> Needs action</span>
      <?php else: ?>
      <span class="admin-stat-trend up"><i class="fas fa-check"></i> All clear</span>
      <?php endif; ?>
    </div>
    <div class="admin-stat-card">
      <div class="admin-stat-icon red"><i class="fas fa-triangle-exclamation"></i></div>
      <div class="admin-stat-label">Open Fraud Flags</div>
      <div class="admin-stat-value"><?= $open_flags ?></div>
      <?php if ($open_flags > 0): ?>
      <span class="admin-stat-trend down"><i class="fas fa-shield-exclamation"></i> Review needed</span>
      <?php else: ?>
      <span class="admin-stat-trend up"><i class="fas fa-shield-check"></i> No flags</span>
      <?php endif; ?>
    </div>
    <div class="admin-stat-card">
      <div class="admin-stat-icon cyan"><i class="fas fa-building-ngo"></i></div>
      <div class="admin-stat-label">Organizations</div>
      <div class="admin-stat-value"><?= $total_orgs ?></div>
      <span class="admin-stat-trend up"><i class="fas fa-badge-check"></i> Platform NGOs</span>
    </div>
    <div class="admin-stat-card">
      <div class="admin-stat-icon amber"><i class="fas fa-file-invoice-dollar"></i></div>
      <div class="admin-stat-label">Pending Verifications</div>
      <?php $pv = (int)$pdo->query("SELECT COUNT(*) FROM verification_requests WHERE status='pending'")->fetchColumn(); ?>
      <div class="admin-stat-value"><?= $pv ?></div>
      <?php if ($pv > 0): ?>
      <span class="admin-stat-trend warn"><i class="fas fa-hourglass-half"></i> Awaiting review</span>
      <?php else: ?>
      <span class="admin-stat-trend up"><i class="fas fa-check"></i> All reviewed</span>
      <?php endif; ?>
    </div>
  </div>

  <!-- Charts Row -->
  <div class="admin-charts-grid" style="margin-bottom:20px;">
    <!-- Donation trend chart -->
    <div class="admin-card">
      <div class="admin-card-header">
        <div class="admin-card-title"><i class="fas fa-chart-line"></i> Donation Trend</div>
        <a href="/admin/analytics.php<?= $_SESS_PARAM ?>" class="admin-card-link">Full analytics <i class="fas fa-arrow-right"></i></a>
      </div>
      <div class="admin-card-body">
        <canvas id="donationChart"></canvas>
      </div>
    </div>
    <!-- Donation type doughnut -->
    <div class="admin-card">
      <div class="admin-card-header">
        <div class="admin-card-title"><i class="fas fa-chart-donut"></i> Donation Types</div>
      </div>
      <div class="admin-card-body" style="display:flex;flex-direction:column;align-items:center;gap:16px;">
        <canvas id="typeChart" style="max-width:200px;"></canvas>
        <div style="display:flex;flex-direction:column;gap:8px;width:100%;max-width:220px;">
          <?php
          $type_labels = ['cash'=>'Cash','item'=>'Items','service'=>'Services'];
          $type_colors = ['cash'=>'#6C72FF','item'=>'#57C3FF','service'=>'#FDB52A'];
          foreach ($type_labels as $k => $label):
            $cnt = (int)($type_breakdown[$k]['cnt'] ?? 0);
            $tot = (float)($type_breakdown[$k]['total'] ?? 0);
          ?>
          <div style="display:flex;align-items:center;gap:8px;font-size:.82rem;">
            <span style="width:10px;height:10px;border-radius:50%;background:<?= $type_colors[$k] ?>;flex-shrink:0;"></span>
            <span style="color:var(--text-sub);flex:1;"><?= $label ?></span>
            <span style="color:var(--text);font-weight:700;"><?= $cnt ?></span>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>

  <!-- Bottom Row: Campaigns + Pending + Recent Users -->
  <div style="display:grid;grid-template-columns:1.5fr 1fr;gap:18px;margin-bottom:20px;">

    <!-- Top Campaigns -->
    <div class="admin-card">
      <div class="admin-card-header">
        <div class="admin-card-title"><i class="fas fa-trophy"></i> Top Campaigns</div>
        <a href="/admin/review_campaigns.php<?= $_SESS_PARAM ?>" class="admin-card-link">View all <i class="fas fa-arrow-right"></i></a>
      </div>
      <div class="admin-card-body" style="padding:10px 22px 18px;">
        <?php foreach ($top_campaigns as $camp):
          $pct = $camp['target_amount'] > 0
            ? min(100, round(($camp['current_amount'] / $camp['target_amount']) * 100))
            : 0;
        ?>
        <div style="padding:10px 0;border-bottom:1px solid var(--border);">
          <div class="camp-row">
            <span style="font-size:.85rem;font-weight:600;color:var(--text);flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
              <?= e($camp['title']) ?>
            </span>
            <span class="adm-badge adm-badge-<?= $camp['status'] ?>"><?= $camp['status'] ?></span>
            <span class="camp-pct"><?= $pct ?>%</span>
          </div>
          <div class="camp-org"><?= e($camp['org_name']) ?> · <?= $camp['donor_count'] ?> donors</div>
          <div class="camp-progress-wrap">
            <div class="admin-progress">
              <div class="admin-progress-fill" style="width:<?= $pct ?>%;<?= $pct>=100?'background:var(--success);':'' ?>"></div>
            </div>
          </div>
          <div style="display:flex;justify-content:space-between;margin-top:4px;font-size:.72rem;color:var(--text-muted);">
            <span><?= fmt_php((float)$camp['current_amount']) ?> raised</span>
            <span>of <?= fmt_php((float)$camp['target_amount']) ?></span>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Pending Approvals -->
    <div class="admin-card">
      <div class="admin-card-header">
        <div class="admin-card-title"><i class="fas fa-clock"></i> Pending Approvals</div>
        <a href="/admin/approvals.php<?= $_SESS_PARAM ?>" class="admin-card-link">All <i class="fas fa-arrow-right"></i></a>
      </div>
      <div class="admin-card-body" style="padding:10px 22px 18px;">
        <?php if (empty($pending_list)): ?>
        <div style="text-align:center;padding:28px 0;color:var(--text-muted);">
          <i class="fas fa-circle-check" style="font-size:2rem;opacity:.3;display:block;margin-bottom:8px;"></i>
          All caught up!
        </div>
        <?php else: ?>
        <?php foreach ($pending_list as $a): ?>
        <div class="appr-item">
          <div class="appr-icon <?= $a['entity_type'] ?>">
            <i class="fas <?= $a['entity_type']==='campaign'?'fa-bullhorn':'fa-building' ?>"></i>
          </div>
          <div style="min-width:0;flex:1;">
            <div class="appr-name" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= e($a['entity_name']) ?></div>
            <div class="appr-type"><?= $a['entity_type'] ?></div>
          </div>
          <div class="appr-time"><?= time_ago_admin($a['created_at']) ?></div>
        </div>
        <?php endforeach; ?>
        <a href="/admin/approvals.php<?= $_SESS_PARAM ?>" style="display:block;text-align:center;margin-top:12px;font-size:.8rem;color:var(--c-purple);font-weight:600;">
          Review all <?= $pending_approvals ?> pending →
        </a>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Recent Donations + Recent Users -->
  <div style="display:grid;grid-template-columns:1.5fr 1fr;gap:18px;margin-bottom:40px;">

    <!-- Recent Donations -->
    <div class="admin-card">
      <div class="admin-card-header">
        <div class="admin-card-title"><i class="fas fa-hand-holding-heart"></i> Recent Donations</div>
        <a href="/admin/donations.php<?= $_SESS_PARAM ?>" class="admin-card-link">View all <i class="fas fa-arrow-right"></i></a>
      </div>
      <table class="admin-table">
        <thead>
          <tr>
            <th>Donor</th>
            <th>Campaign</th>
            <th>Amount</th>
            <th>Type</th>
            <th>Status</th>
            <th>When</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($recent_donations as $d): ?>
          <tr>
            <td style="font-weight:600;"><?= e($d['donor_name']) ?></td>
            <td class="tbl-muted" style="max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><?= e($d['campaign_title']) ?></td>
            <td style="font-family:var(--font-mono);font-weight:700;color:var(--success);">
              <?= $d['donation_type']==='cash' ? '₱'.number_format((float)$d['amount'],2) : '—' ?>
            </td>
            <td><span class="adm-badge adm-badge-<?= $d['donation_type'] === 'cash' ? 'approved' : ($d['donation_type']==='item'?'organization':'user') ?>"><?= $d['donation_type'] ?></span></td>
            <td><span class="adm-badge adm-badge-<?= $d['status'] ?>"><?= $d['status'] ?></span></td>
            <td class="tbl-muted"><?= time_ago_admin($d['created_at']) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <!-- Recent Users -->
    <div class="admin-card">
      <div class="admin-card-header">
        <div class="admin-card-title"><i class="fas fa-user-plus"></i> New Users</div>
        <a href="/admin/users.php<?= $_SESS_PARAM ?>" class="admin-card-link">All <i class="fas fa-arrow-right"></i></a>
      </div>
      <div class="admin-card-body" style="padding:8px 0 12px;">
        <?php foreach ($recent_users as $u):
          $initials = strtoupper(substr($u['first_name'],0,1).substr($u['last_name'],0,1));
        ?>
        <div style="display:flex;align-items:center;gap:12px;padding:10px 22px;border-bottom:1px solid var(--border);">
          <div style="width:34px;height:34px;border-radius:50%;background:var(--brand-gradient);display:flex;align-items:center;justify-content:center;font-size:.72rem;font-weight:800;color:#fff;flex-shrink:0;">
            <?= $initials ?>
          </div>
          <div style="flex:1;min-width:0;">
            <div style="font-size:.84rem;font-weight:600;color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
              <?= e($u['first_name'].' '.$u['last_name']) ?>
            </div>
            <div style="font-size:.72rem;color:var(--text-muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">
              <?= e($u['email']) ?>
            </div>
          </div>
          <div style="display:flex;flex-direction:column;align-items:flex-end;gap:3px;">
            <span class="adm-badge adm-badge-<?= $u['role_name'] ?>"><?= $u['role_name'] ?></span>
            <span style="font-size:.67rem;color:var(--text-muted);"><?= time_ago_admin($u['created_at']) ?></span>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

</main>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
<script>
Chart.defaults.color = '#7E89AC';
Chart.defaults.borderColor = 'rgba(174,185,225,0.08)';
Chart.defaults.font.family = 'DM Sans, sans-serif';

// ── Donation Trend ──────────────────────────────────────────
const monthly = <?= json_encode(array_values($monthly)) ?>;
const labels  = monthly.map(r => r.month);
const counts  = monthly.map(r => parseInt(r.count));
const amounts = monthly.map(r => parseFloat(r.cash));

new Chart(document.getElementById('donationChart'), {
  type: 'line',
  data: {
    labels,
    datasets: [
      {
        label: 'Donations',
        data: counts,
        borderColor: '#6C72FF',
        backgroundColor: 'rgba(108,114,255,.1)',
        fill: true,
        tension: .4,
        pointBackgroundColor: '#6C72FF',
        pointRadius: 4,
        yAxisID: 'y',
      },
      {
        label: 'Cash (₱)',
        data: amounts,
        borderColor: '#57C3FF',
        backgroundColor: 'rgba(87,195,255,.05)',
        fill: true,
        tension: .4,
        pointBackgroundColor: '#57C3FF',
        pointRadius: 4,
        yAxisID: 'y1',
      }
    ]
  },
  options: {
    responsive: true,
    interaction: { mode: 'index', intersect: false },
    plugins: {
      legend: { position: 'top', labels: { boxWidth: 10, padding: 16, font: { size: 12 } } },
      tooltip: {
        backgroundColor: '#212C4D',
        borderColor: 'rgba(108,114,255,.3)',
        borderWidth: 1,
        padding: 12,
        callbacks: {
          label: ctx => ctx.datasetIndex === 0
            ? ` ${ctx.raw} donations`
            : ` ₱${Number(ctx.raw).toLocaleString()}`
        }
      }
    },
    scales: {
      y:  { position:'left',  grid:{ color:'rgba(174,185,225,.06)' }, ticks:{ stepSize:1 } },
      y1: { position:'right', grid:{ drawOnChartArea:false }, ticks:{ callback: v => '₱'+Number(v).toLocaleString() } }
    }
  }
});

// ── Donation Type Doughnut ──────────────────────────────────
const typeData  = <?= json_encode(array_values($type_breakdown)) ?>;
const typeCounts = [
  parseInt(<?= (int)($type_breakdown['cash']['cnt'] ?? 0) ?>),
  parseInt(<?= (int)($type_breakdown['item']['cnt'] ?? 0) ?>),
  parseInt(<?= (int)($type_breakdown['service']['cnt'] ?? 0) ?>),
];

new Chart(document.getElementById('typeChart'), {
  type: 'doughnut',
  data: {
    labels: ['Cash', 'Items', 'Services'],
    datasets: [{
      data: typeCounts,
      backgroundColor: ['#6C72FF','#57C3FF','#FDB52A'],
      borderWidth: 0,
      hoverOffset: 8,
    }]
  },
  options: {
    responsive: true,
    cutout: '72%',
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: '#212C4D',
        borderColor: 'rgba(108,114,255,.3)',
        borderWidth: 1,
        padding: 12,
      }
    }
  }
});
</script>
</body>
</html>
