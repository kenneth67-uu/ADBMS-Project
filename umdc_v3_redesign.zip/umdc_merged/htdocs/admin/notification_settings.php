<?php
// =============================================================
// UMDC – Admin: Notification & Email Settings
// /admin/notification_settings.php
// =============================================================
defined('UMDC_APP') or define('UMDC_APP', true);
require_once __DIR__ . '/../Config/security.php';
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../Config/notifications.php';
umdc_session_start();
requireRole('admin');
setSecureHeaders();
$_SESS_PARAM = '?_sess=UMDC_ADMIN';

$user_name = e($_SESSION['user_name'] ?? 'Admin');
$userId    = currentUserId();
$flash     = [];

// ── Editable settings keys ───────────────────────────────────
$editableKeys = [
    'mail_from_email', 'mail_from_name',
    'email_driver',
    'smtp_host', 'smtp_port', 'smtp_secure', 'smtp_user', 'smtp_pass',
    'semaphore_api_key', 'sms_sender_name', 'sms_driver',
    'require_email_verify', '2fa_required_for_orgs',
];

// ── Handle POST ──────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    // Save settings
    if ($action === 'save_settings') {
        $saved = 0;
        foreach ($editableKeys as $key) {
            if (isset($_POST['setting'][$key])) {
                $val = trim($_POST['setting'][$key]);
                // Don't overwrite password with blank
                if ($key === 'smtp_pass' && $val === '') continue;
                $pdo->prepare("
                    INSERT INTO system_settings (`key`, `value`, updated_by)
                    VALUES (?, ?, ?)
                    ON DUPLICATE KEY UPDATE `value`=VALUES(`value`), updated_by=VALUES(updated_by)
                ")->execute([$key, $val, $userId]);
                $saved++;
            }
        }
        auditLog($pdo, $userId, 'settings_updated', 'system_settings', 0);
        $flash = ['type' => 'success', 'msg' => "$saved settings saved successfully."];
    }

    // Send test email
    if ($action === 'test_email') {
        $testEmail = filter_var($_POST['test_email'] ?? '', FILTER_VALIDATE_EMAIL);
        if ($testEmail) {
            Notifier::send($pdo, $userId, 'email_verification', [
                'verify_link' => 'https://umdc.ph/verify?token=TEST_TOKEN_123',
            ]);
            // Force-queue a manual test
            $pdo->prepare("
                INSERT INTO email_queue (to_email, to_name, subject, body_html, body_text, template_key, status, created_at)
                VALUES (?, 'Admin Test', '[UMDC Test] Email delivery check',
                    '<p>This is a <strong>test email</strong> from UMDC. If you received this, email delivery is working.</p>',
                    'This is a test email from UMDC. If you received this, email delivery is working.',
                    'test', 'queued', NOW())
            ")->execute([$testEmail]);
            $flash = ['type' => 'success', 'msg' => "Test email queued for $testEmail. Run the email processor to deliver it."];
        } else {
            $flash = ['type' => 'danger', 'msg' => 'Please enter a valid email address.'];
        }
    }

    // Send test notification to self
    if ($action === 'test_inapp') {
        Notifier::send($pdo, $userId, 'login_new_device', [
            'time'     => date('M j, Y g:i A'),
            'location' => 'Philippines',
            'device'   => 'Admin Test',
        ]);
        $flash = ['type' => 'success', 'msg' => 'Test in-app notification sent. Check the bell icon.'];
    }
}

// ── Load current settings ─────────────────────────────────────
$settingsRaw = $pdo->query("SELECT `key`, `value` FROM system_settings")->fetchAll(PDO::FETCH_KEY_PAIR);
$s = fn(string $k, string $d = '') => htmlspecialchars($settingsRaw[$k] ?? $d, ENT_QUOTES, 'UTF-8');

// ── Queue stats ───────────────────────────────────────────────
$emailStats = $pdo->query("
    SELECT status, COUNT(*) as cnt FROM email_queue GROUP BY status
")->fetchAll(PDO::FETCH_KEY_PAIR);
$smsStats = $pdo->query("
    SELECT status, COUNT(*) as cnt FROM sms_queue GROUP BY status
")->fetchAll(PDO::FETCH_KEY_PAIR);

$recentFailed = $pdo->query("
    SELECT to_email, subject, attempts, error_msg, created_at
    FROM email_queue WHERE status='failed'
    ORDER BY created_at DESC LIMIT 5
")->fetchAll();

$recentSent = $pdo->query("
    SELECT to_email, subject, sent_at
    FROM email_queue WHERE status='sent'
    ORDER BY sent_at DESC LIMIT 5
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<meta name="csrf-token" content="<?= csrf_token() ?>">
<meta name="sess-name" content="UMDC_ADMIN">
<title>Notification Settings – UMDC Admin</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="/assets/css/global.css">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="/assets/css/notifications.css">
<style>
.settings-grid    { display:grid; grid-template-columns:1fr 1fr; gap:20px; }
@media(max-width:768px){ .settings-grid { grid-template-columns:1fr; } }
.settings-section { background:var(--color-surface); border:1px solid var(--color-border); border-radius:var(--radius-lg); padding:24px; }
.settings-section h3 { font-size:.95rem; font-weight:700; margin:0 0 18px; padding-bottom:12px; border-bottom:1px solid var(--color-border); display:flex; align-items:center; gap:9px; color:var(--color-text); }
.settings-section h3 i { color:var(--brand-primary); width:16px; }
.form-row         { margin-bottom:16px; }
.form-row label   { display:block; font-size:.8rem; font-weight:600; color:var(--color-muted); margin-bottom:5px; text-transform:uppercase; letter-spacing:.4px; }
.form-row input, .form-row select { width:100%; padding:9px 12px; border:1px solid var(--color-border); border-radius:var(--radius-md); font-size:.88rem; font-family:var(--font-sans); background:var(--color-surface); color:var(--color-text); transition:var(--transition); box-sizing:border-box; }
.form-row input:focus, .form-row select:focus { outline:none; border-color:var(--brand-primary); box-shadow:0 0 0 3px rgba(59,111,240,.1); }
.form-row input[type="password"] { font-family:var(--font-mono); letter-spacing:.1em; }
.form-hint { font-size:.75rem; color:var(--color-muted); margin-top:4px; }
.stat-row         { display:flex; gap:12px; flex-wrap:wrap; margin-bottom:16px; }
.stat-chip        { display:flex; align-items:center; gap:7px; padding:7px 14px; border-radius:var(--radius-md); font-size:.82rem; font-weight:600; border:1px solid transparent; }
.stat-chip-queued { background:rgba(217,119,6,.08); color:var(--color-warning); border-color:rgba(217,119,6,.15); }
.stat-chip-sent   { background:rgba(5,150,105,.08);  color:var(--color-success); border-color:rgba(5,150,105,.15); }
.stat-chip-failed { background:rgba(220,38,38,.07);  color:var(--color-danger);  border-color:rgba(220,38,38,.12); }
.queue-table      { width:100%; border-collapse:collapse; font-size:.82rem; }
.queue-table th   { text-align:left; color:var(--color-muted); font-weight:600; font-size:.75rem; text-transform:uppercase; letter-spacing:.4px; padding:6px 8px; border-bottom:1px solid var(--color-border); }
.queue-table td   { padding:8px 8px; border-bottom:1px solid var(--color-border); color:var(--color-text); vertical-align:middle; }
.queue-table tr:last-child td { border-bottom:none; }
.queue-table td:first-child { font-weight:500; }
.mono             { font-family:var(--font-mono); font-size:.78rem; }
.cron-box         { background:var(--color-surface-2); border:1px solid var(--color-border); border-radius:var(--radius-md); padding:12px 16px; font-family:var(--font-mono); font-size:.8rem; color:var(--color-text); white-space:pre; overflow-x:auto; margin-top:8px; }
.driver-toggle    { display:flex; gap:8px; }
.driver-opt       { flex:1; border:1px solid var(--color-border); border-radius:var(--radius-md); padding:10px 14px; cursor:pointer; text-align:center; transition:var(--transition); }
.driver-opt input { display:none; }
.driver-opt:has(input:checked) { border-color:var(--brand-primary); background:rgba(59,111,240,.06); }
.driver-opt span  { font-size:.85rem; font-weight:600; display:block; }
.driver-opt small { font-size:.72rem; color:var(--color-muted); }
</style>
</head>
<body>
<?php include __DIR__ . '/../components/admin_sidebar.php'; ?>

<main class="main-content">
    <div class="page-header">
        <h1><i class="fas fa-bell-cog" style="color:var(--brand-primary);margin-right:10px;"></i>Notification Settings</h1>
        <p>Configure email delivery, SMS gateway, and notification behaviour.</p>
    </div>

    <?php if ($flash): ?>
    <div class="alert alert-<?= $flash['type'] ?>" data-auto-dismiss>
        <i class="fas fa-<?= $flash['type'] === 'success' ? 'check-circle' : 'exclamation-circle' ?>"></i>
        <span><?= htmlspecialchars($flash['msg']) ?></span>
    </div>
    <?php endif; ?>

    <!-- Queue Stats -->
    <div class="card" style="margin-bottom:20px;">
        <div class="card-body" style="padding:20px 24px;">
            <h3 style="font-size:.9rem;font-weight:700;margin:0 0 14px;display:flex;align-items:center;gap:8px;">
                <i class="fas fa-chart-bar" style="color:var(--brand-primary);"></i> Queue Status
            </h3>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;flex-wrap:wrap;">
                <!-- Email -->
                <div>
                    <p style="font-size:.78rem;font-weight:700;color:var(--color-muted);text-transform:uppercase;letter-spacing:.4px;margin:0 0 10px;">Email Queue</p>
                    <div class="stat-row">
                        <div class="stat-chip stat-chip-queued"><i class="fas fa-clock"></i> <?= (int)($emailStats['queued'] ?? 0) ?> queued</div>
                        <div class="stat-chip stat-chip-sent"><i class="fas fa-check"></i> <?= (int)($emailStats['sent'] ?? 0) ?> sent</div>
                        <?php if (!empty($emailStats['failed'])): ?>
                        <div class="stat-chip stat-chip-failed"><i class="fas fa-xmark"></i> <?= (int)$emailStats['failed'] ?> failed</div>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- SMS -->
                <div>
                    <p style="font-size:.78rem;font-weight:700;color:var(--color-muted);text-transform:uppercase;letter-spacing:.4px;margin:0 0 10px;">SMS Queue</p>
                    <div class="stat-row">
                        <div class="stat-chip stat-chip-queued"><i class="fas fa-clock"></i> <?= (int)($smsStats['queued'] ?? 0) ?> queued</div>
                        <div class="stat-chip stat-chip-sent"><i class="fas fa-check"></i> <?= (int)($smsStats['sent'] ?? 0) ?> sent</div>
                        <?php if (!empty($smsStats['failed'])): ?>
                        <div class="stat-chip stat-chip-failed"><i class="fas fa-xmark"></i> <?= (int)$smsStats['failed'] ?> failed</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Cron instructions -->
            <p style="font-size:.78rem;font-weight:700;color:var(--color-muted);text-transform:uppercase;letter-spacing:.4px;margin:16px 0 6px;">Cron Jobs (add to server crontab)</p>
            <div class="cron-box"># Email — runs every minute
* * * * * php <?= rtrim($_SERVER['DOCUMENT_ROOT'] ?? '/var/www/html', '/') ?>/notifications/process_email.php >> /var/log/umdc_email.log 2>&1

# SMS — runs every minute
* * * * * php <?= rtrim($_SERVER['DOCUMENT_ROOT'] ?? '/var/www/html', '/') ?>/notifications/process_sms.php >> /var/log/umdc_sms.log 2>&1</div>
        </div>
    </div>

    <form method="POST">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="save_settings">

        <div class="settings-grid">

            <!-- ── Email general ── -->
            <div class="settings-section">
                <h3><i class="fas fa-envelope"></i> Email — From Address</h3>
                <div class="form-row">
                    <label>From Name</label>
                    <input type="text" name="setting[mail_from_name]" value="<?= $s('mail_from_name','UMDC') ?>" placeholder="UMDC">
                </div>
                <div class="form-row">
                    <label>From Email</label>
                    <input type="email" name="setting[mail_from_email]" value="<?= $s('mail_from_email','no-reply@umdc.ph') ?>" placeholder="no-reply@umdc.ph">
                </div>
                <div class="form-row">
                    <label>Email Driver</label>
                    <div class="driver-toggle">
                        <label class="driver-opt">
                            <input type="radio" name="setting[email_driver]" value="mail" <?= $s('email_driver','mail') === 'mail' ? 'checked' : '' ?>>
                            <span>PHP mail()</span>
                            <small>Built-in, no config needed</small>
                        </label>
                        <label class="driver-opt">
                            <input type="radio" name="setting[email_driver]" value="smtp" <?= $s('email_driver') === 'smtp' ? 'checked' : '' ?>>
                            <span>SMTP</span>
                            <small>Gmail, Mailgun, etc.</small>
                        </label>
                    </div>
                </div>
            </div>

            <!-- ── SMTP config ── -->
            <div class="settings-section">
                <h3><i class="fas fa-server"></i> SMTP Configuration</h3>
                <p class="form-hint" style="margin-bottom:14px;">Only required if Email Driver is set to SMTP. PHPMailer must be installed.</p>
                <div class="form-row">
                    <label>SMTP Host</label>
                    <input type="text" name="setting[smtp_host]" value="<?= $s('smtp_host','smtp.gmail.com') ?>" placeholder="smtp.gmail.com">
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
                    <div class="form-row">
                        <label>Port</label>
                        <input type="number" name="setting[smtp_port]" value="<?= $s('smtp_port','587') ?>" placeholder="587">
                    </div>
                    <div class="form-row">
                        <label>Encryption</label>
                        <select name="setting[smtp_secure]">
                            <option value="tls" <?= $s('smtp_secure','tls') === 'tls' ? 'selected' : '' ?>>TLS (port 587)</option>
                            <option value="ssl" <?= $s('smtp_secure') === 'ssl' ? 'selected' : '' ?>>SSL (port 465)</option>
                            <option value=""    <?= $s('smtp_secure') === '' ? 'selected' : '' ?>>None</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <label>SMTP Username</label>
                    <input type="text" name="setting[smtp_user]" value="<?= $s('smtp_user') ?>" placeholder="your@gmail.com" autocomplete="off">
                </div>
                <div class="form-row">
                    <label>SMTP Password</label>
                    <input type="password" name="setting[smtp_pass]" value="" placeholder="Leave blank to keep current" autocomplete="new-password">
                    <p class="form-hint">Leave blank to keep existing password.</p>
                </div>
            </div>

            <!-- ── SMS / Semaphore ── -->
            <div class="settings-section">
                <h3><i class="fas fa-mobile-screen"></i> SMS — Semaphore Gateway</h3>
                <div class="form-row">
                    <label>Semaphore API Key</label>
                    <input type="text" name="setting[semaphore_api_key]" value="<?= $s('semaphore_api_key') ?>" placeholder="Your Semaphore API key" autocomplete="off">
                    <p class="form-hint"><a href="https://semaphore.co" target="_blank" rel="noopener">semaphore.co</a> — Register for a free key</p>
                </div>
                <div class="form-row">
                    <label>Sender Name (max 11 chars)</label>
                    <input type="text" name="setting[sms_sender_name]" value="<?= $s('sms_sender_name','UMDC') ?>" maxlength="11" placeholder="UMDC">
                </div>
            </div>

            <!-- ── Security notifications ── -->
            <div class="settings-section">
                <h3><i class="fas fa-shield"></i> Security Notifications</h3>
                <div class="form-row">
                    <label>Require Email Verification on Signup</label>
                    <select name="setting[require_email_verify]">
                        <option value="1" <?= $s('require_email_verify','1') === '1' ? 'selected' : '' ?>>Yes — users must verify email</option>
                        <option value="0" <?= $s('require_email_verify') === '0' ? 'selected' : '' ?>>No — skip verification</option>
                    </select>
                </div>
                <div class="form-row">
                    <label>Require 2FA for Organizations</label>
                    <select name="setting[2fa_required_for_orgs]">
                        <option value="0" <?= $s('2fa_required_for_orgs','0') === '0' ? 'selected' : '' ?>>No — optional</option>
                        <option value="1" <?= $s('2fa_required_for_orgs') === '1' ? 'selected' : '' ?>>Yes — mandatory</option>
                    </select>
                </div>
                <p class="form-hint" style="margin-top:12px;">
                    <i class="fas fa-info-circle"></i>
                    Security notifications (new device login, password reset) are always sent regardless of these settings.
                </p>
            </div>
        </div>

        <div style="margin-top:20px;display:flex;justify-content:flex-end;">
            <button type="submit" class="btn-primary" style="padding:11px 28px;">
                <i class="fas fa-floppy-disk"></i> Save All Settings
            </button>
        </div>
    </form>

    <!-- Test tools -->
    <div class="settings-grid" style="margin-top:24px;">
        <!-- Test email -->
        <div class="settings-section">
            <h3><i class="fas fa-flask"></i> Send Test Email</h3>
            <p style="font-size:.85rem;color:var(--color-muted);margin:0 0 14px;">
                Queues a test email to confirm your email driver is configured correctly.
                Run the email processor after clicking send.
            </p>
            <form method="POST" style="display:flex;gap:10px;align-items:flex-end;">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="test_email">
                <div class="form-row" style="flex:1;margin:0;">
                    <label>Recipient Email</label>
                    <input type="email" name="test_email" placeholder="test@example.com" required>
                </div>
                <button type="submit" class="btn-secondary" style="white-space:nowrap;padding:9px 18px;margin-bottom:0;">
                    <i class="fas fa-paper-plane"></i> Queue Test
                </button>
            </form>
        </div>

        <!-- Test in-app -->
        <div class="settings-section">
            <h3><i class="fas fa-bell"></i> Test In-App Notification</h3>
            <p style="font-size:.85rem;color:var(--color-muted);margin:0 0 14px;">
                Sends a test in-app notification to your account. Check the bell icon in the header after sending.
            </p>
            <form method="POST">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="test_inapp">
                <button type="submit" class="btn-secondary" style="padding:9px 18px;">
                    <i class="fas fa-bolt"></i> Send Test Notification
                </button>
            </form>
        </div>
    </div>

    <!-- Recent failed emails -->
    <?php if (!empty($recentFailed)): ?>
    <div class="card" style="margin-top:24px;border-color:rgba(220,38,38,.2);">
        <div class="card-body" style="padding:20px 24px;">
            <h3 style="font-size:.9rem;font-weight:700;margin:0 0 14px;color:var(--color-danger);display:flex;align-items:center;gap:8px;">
                <i class="fas fa-triangle-exclamation"></i> Failed Emails (last 5)
            </h3>
            <table class="queue-table">
                <thead><tr><th>To</th><th>Subject</th><th>Attempts</th><th>Error</th><th>Date</th></tr></thead>
                <tbody>
                <?php foreach ($recentFailed as $f): ?>
                <tr>
                    <td><?= e($f['to_email']) ?></td>
                    <td><?= e(substr($f['subject'], 0, 40)) ?>…</td>
                    <td style="text-align:center;"><?= (int)$f['attempts'] ?></td>
                    <td style="color:var(--color-danger);font-size:.78rem;"><?= e(substr($f['error_msg'] ?? 'Unknown', 0, 50)) ?></td>
                    <td class="mono"><?= date('M j H:i', strtotime($f['created_at'])) ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

    <!-- Recent sent emails -->
    <?php if (!empty($recentSent)): ?>
    <div class="card" style="margin-top:16px;">
        <div class="card-body" style="padding:20px 24px;">
            <h3 style="font-size:.9rem;font-weight:700;margin:0 0 14px;color:var(--color-success);display:flex;align-items:center;gap:8px;">
                <i class="fas fa-circle-check"></i> Recently Sent (last 5)
            </h3>
            <table class="queue-table">
                <thead><tr><th>To</th><th>Subject</th><th>Sent At</th></tr></thead>
                <tbody>
                <?php foreach ($recentSent as $r): ?>
                <tr>
                    <td><?= e($r['to_email']) ?></td>
                    <td><?= e(substr($r['subject'], 0, 50)) ?></td>
                    <td class="mono"><?= date('M j, Y H:i', strtotime($r['sent_at'])) ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

</main>
<script src="/assets/js/notifications.js"></script>
</body>
</html>
