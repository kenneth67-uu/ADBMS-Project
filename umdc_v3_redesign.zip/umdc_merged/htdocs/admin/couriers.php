<?php
defined('UMDC_APP') or define('UMDC_APP', true);
require_once __DIR__ . '/../Config/security.php';
require_once __DIR__ . '/../Config/db.php';
umdc_session_start();
requireRole('admin');
setSecureHeaders();
$_SESS_PARAM = '?_sess=UMDC_ADMIN';

// ── POST actions ──────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';

    if ($action === 'add_courier') {
        $name     = sanitizeInput($_POST['name'] ?? '');
        $endpoint = sanitizeInput($_POST['api_endpoint'] ?? '');
        $contact  = sanitizeInput($_POST['contact'] ?? '');
        $phone    = sanitizeInput($_POST['phone'] ?? '');
        if ($name) {
            $pdo->prepare("INSERT INTO couriers (name, api_endpoint, active) VALUES (?, ?, 1)")
                ->execute([$name, $endpoint ?: null]);
        }
    } elseif ($action === 'toggle_courier') {
        $id = filter_var($_POST['courier_id'] ?? 0, FILTER_VALIDATE_INT);
        if ($id) $pdo->prepare("UPDATE couriers SET active = NOT active WHERE courier_id=?")->execute([$id]);
    } elseif ($action === 'update_delivery') {
        $did     = filter_var($_POST['delivery_id'] ?? 0, FILTER_VALIDATE_INT);
        $status  = sanitizeInput($_POST['status'] ?? '');
        $code    = sanitizeInput($_POST['tracking_code'] ?? '');
        $notes   = sanitizeInput($_POST['notes'] ?? '');
        $pickup  = sanitizeInput($_POST['pickup_address'] ?? '');
        $pdate   = $_POST['pickup_date'] ?? '';
        $edate   = $_POST['estimated_delivery'] ?? '';
        $valid   = ['requested','approved','in_transit','delivered','cancelled'];

        if ($did && in_array($status, $valid, true)) {
            $pdo->prepare("
                UPDATE deliveries SET
                  status=?, tracking_code=?, notes=?, pickup_address=?,
                  pickup_date=?, estimated_delivery=?,
                  delivered_at = CASE WHEN ? = 'delivered' THEN NOW() ELSE delivered_at END,
                  approved_by = CASE WHEN ? IN ('approved','in_transit','delivered') THEN ? ELSE approved_by END
                WHERE delivery_id=?
            ")->execute([
                $status,$code,$notes,$pickup,
                $pdate?:null,$edate?:null,
                $status,$status,currentUserId(),
                $did
            ]);
            auditLog($pdo, currentUserId(), 'delivery_updated', 'delivery', $did);
        }
    }
    header("Location: /admin/couriers.php{$_SESS_PARAM}&updated=1");
    exit;
}

// ── Data ──────────────────────────────────────────────────────────────────────
$couriers = $pdo->query("SELECT * FROM couriers ORDER BY name")->fetchAll();

$filterStatus = in_array($_GET['ds'] ?? '', ['','requested','approved','in_transit','delivered','cancelled']) ? ($_GET['ds'] ?? '') : '';
$whereDelivery = $filterStatus ? "AND dv.status = '$filterStatus'" : '';

$deliveries = $pdo->query("
    SELECT dv.*,
           c.name AS courier_name, c.api_endpoint,
           i.item_name, i.quantity, i.description AS item_desc, i.estimated_value, i.photo AS item_photo,
           CONCAT(u.first_name,' ',u.last_name) AS donor_name, u.email AS donor_email, u.phone AS donor_phone,
           cam.title AS campaign_title, cam.category,
           o.org_name,
           CONCAT(adm.first_name,' ',adm.last_name) AS approver_name
    FROM deliveries dv
    JOIN couriers c ON dv.courier_id = c.courier_id
    JOIN item_donations i ON dv.item_id = i.item_id
    JOIN donations d ON i.donation_id = d.donation_id
    JOIN users u ON d.user_id = u.user_id
    JOIN campaigns cam ON d.campaign_id = cam.campaign_id
    JOIN organizations o ON cam.org_id = o.org_id
    LEFT JOIN users adm ON dv.approved_by = adm.user_id
    WHERE 1=1 $whereDelivery
    ORDER BY FIELD(dv.status,'requested','approved','in_transit','delivered','cancelled'), dv.created_at DESC
")->fetchAll();

$delCounts = $pdo->query("SELECT status, COUNT(*) FROM deliveries GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Couriers & Deliveries – UMDC Admin</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<?php include __DIR__ . '/../components/admin_sidebar.php'; ?>
<style>
.delivery-card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:14px;margin-bottom:18px;overflow:hidden;}
.delivery-head{padding:16px 20px;border-bottom:1px solid var(--color-border);display:flex;align-items:center;gap:12px;flex-wrap:wrap;cursor:pointer;user-select:none;}
.delivery-head:hover{background:rgba(255,255,255,.02);}
.delivery-body{display:none;padding:22px;display:grid;grid-template-columns:1fr 1fr;gap:24px;}
.delivery-body.open{display:grid;}
.info-g{margin-bottom:10px;font-size:.855rem;}
.info-g .lbl{font-size:.75rem;color:var(--color-muted);margin-bottom:2px;}
.info-g .val{font-weight:500;}
.stat-chip{display:inline-flex;align-items:center;gap:6px;padding:5px 12px;border-radius:20px;font-size:.78rem;font-weight:700;}
.chip-requested{background:rgba(217,119,6,.1);color:var(--color-warning);}
.chip-approved{background:rgba(59,111,240,.1);color:var(--brand-primary);}
.chip-in_transit{background:rgba(124,58,237,.1);color:var(--brand-secondary);}
.chip-delivered{background:rgba(5,150,105,.1);color:var(--color-success);}
.chip-cancelled{background:rgba(220,38,38,.1);color:var(--color-danger);}
.proof-img{width:100%;max-height:200px;object-fit:cover;border-radius:8px;border:1px solid var(--color-border);}
.item-img{width:80px;height:80px;object-fit:cover;border-radius:8px;border:1px solid var(--color-border);flex-shrink:0;}
.timeline{padding-left:20px;border-left:2px solid var(--color-border);margin-top:6px;}
.tl-step{position:relative;padding-left:16px;padding-bottom:14px;font-size:.82rem;}
.tl-step::before{content:'';position:absolute;left:-6px;top:5px;width:10px;height:10px;border-radius:50%;background:var(--color-border);}
.tl-step.done::before{background:var(--color-success);}
.tl-step.active::before{background:var(--brand-primary);}
</style>

<main class="main-content">
    <div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px;">
        <div>
            <h1>Couriers &amp; Deliveries</h1>
            <p>Manage item donation pickup couriers and track all deliveries.</p>
        </div>
        <button class="btn-primary" onclick="openModal('addCourierModal')">
            <i class="fas fa-plus"></i> Add Courier
        </button>
    </div>

    <?php if (isset($_GET['updated'])): ?>
    <div class="alert alert-success" data-auto-dismiss><i class="fas fa-check-circle"></i><span>Updated successfully.</span></div>
    <?php endif; ?>

    <!-- Couriers list -->
    <div class="card" style="margin-bottom:28px;">
        <div class="card-header"><h5><i class="fas fa-truck" style="color:var(--brand-primary);margin-right:8px;"></i>Registered Couriers</h5></div>
        <?php if (empty($couriers)): ?>
        <div class="empty-state"><i class="fas fa-truck"></i><h6>No couriers yet</h6><p>Add your first courier partner above.</p></div>
        <?php else: ?>
        <table class="table-custom">
            <thead><tr><th>Courier</th><th>API / Tracking URL</th><th>Total Deliveries</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>
            <?php foreach ($couriers as $c):
                $delCount = $pdo->prepare("SELECT COUNT(*) FROM deliveries WHERE courier_id=?");
                $delCount->execute([$c['courier_id']]);
                $delCount = $delCount->fetchColumn();
            ?>
            <tr>
                <td><strong><?= e($c['name']) ?></strong></td>
                <td style="font-size:.78rem;color:var(--color-muted);font-family:var(--font-mono);"><?= e($c['api_endpoint'] ?: '—') ?></td>
                <td><?= $delCount ?></td>
                <td><span class="badge-pill <?= $c['active']?'badge-active':'badge-failed' ?>"><?= $c['active']?'Active':'Inactive' ?></span></td>
                <td>
                    <form method="POST" style="display:inline;">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="toggle_courier">
                        <input type="hidden" name="courier_id" value="<?= $c['courier_id'] ?>">
                        <button type="submit" class="<?= $c['active']?'btn-secondary':'btn-primary' ?>" style="font-size:.75rem;padding:5px 12px;">
                            <?= $c['active']?'Deactivate':'Activate' ?>
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>

    <!-- Delivery requests -->
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:18px;">
        <h2 style="font-size:1.2rem;font-weight:700;">Delivery Requests</h2>
        <div style="display:flex;gap:6px;flex-wrap:wrap;">
            <?php foreach ([''=>'All','requested'=>'Requested','approved'=>'Approved','in_transit'=>'In Transit','delivered'=>'Delivered','cancelled'=>'Cancelled'] as $k=>$v):
                $cnt = $k ? ($delCounts[$k]??0) : array_sum($delCounts);
            ?>
            <a href="?_sess=UMDC_ADMIN<?= $k ? '&ds='.$k : '' ?>"
               class="<?= $filterStatus===$k?'btn-primary':'btn-secondary' ?>"
               style="padding:6px 12px;font-size:.78rem;text-decoration:none;">
                <?= $v ?> <span style="opacity:.7;">(<?= $cnt ?>)</span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>

    <?php if (empty($deliveries)): ?>
    <div class="card"><div class="empty-state"><i class="fas fa-box-open"></i><h6>No deliveries</h6><p>Delivery requests will appear here when donors submit item donations.</p></div></div>
    <?php endif; ?>

    <?php foreach ($deliveries as $dv):
        $statusDots = ['requested'=>0,'approved'=>1,'in_transit'=>2,'delivered'=>3,'cancelled'=>-1];
        $step = $statusDots[$dv['status']] ?? 0;
    ?>
    <div class="delivery-card" id="del-<?= $dv['delivery_id'] ?>">
        <!-- Collapsible header -->
        <div class="delivery-head" onclick="toggleDelivery(<?= $dv['delivery_id'] ?>)">
            <div style="width:38px;height:38px;background:var(--brand-gradient);border-radius:10px;display:flex;align-items:center;justify-content:center;color:white;font-size:1rem;flex-shrink:0;">
                <i class="fas fa-box"></i>
            </div>
            <div style="flex:1;min-width:180px;">
                <div style="font-weight:700;font-size:.95rem;"><?= e($dv['item_name']) ?> ×<?= $dv['quantity'] ?></div>
                <div style="font-size:.8rem;color:var(--color-muted);"><?= e($dv['campaign_title']) ?> · <?= e($dv['org_name']) ?></div>
            </div>
            <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                <span class="stat-chip chip-<?= $dv['status'] ?>">
                    <i class="fas fa-<?= ['requested'=>'clock','approved'=>'check','in_transit'=>'truck','delivered'=>'check-circle','cancelled'=>'times'][$dv['status']]?:'circle' ?>"></i>
                    <?= ucfirst(str_replace('_',' ',$dv['status'])) ?>
                </span>
                <span class="badge-pill badge-info" style="font-size:.72rem;"><?= e($dv['courier_name']) ?></span>
                <span style="font-size:.75rem;color:var(--color-muted);"><?= date('M d, Y', strtotime($dv['created_at'])) ?></span>
                <i class="fas fa-chevron-down" id="chevron-<?= $dv['delivery_id'] ?>" style="color:var(--color-muted);font-size:.75rem;transition:transform .2s;"></i>
            </div>
        </div>

        <!-- Expanded body -->
        <div class="delivery-body" id="body-<?= $dv['delivery_id'] ?>" style="display:none;">
            <!-- Left column: item + donor info -->
            <div>
                <!-- Item info -->
                <div style="display:flex;gap:14px;margin-bottom:20px;">
                    <?php if ($dv['item_photo']): ?>
                    <img src="/<?= e($dv['item_photo']) ?>" class="item-img" alt="Item photo" onclick="openImgZoom('/<?= e($dv['item_photo']) ?>')">
                    <?php else: ?>
                    <div class="item-img" style="background:var(--color-surface-2);display:flex;align-items:center;justify-content:center;color:var(--color-muted);"><i class="fas fa-box" style="font-size:1.5rem;opacity:.3;"></i></div>
                    <?php endif; ?>
                    <div>
                        <div style="font-weight:700;font-size:1rem;margin-bottom:4px;"><?= e($dv['item_name']) ?></div>
                        <div class="info-g"><span class="lbl">Quantity</span><span class="val"><?= $dv['quantity'] ?> unit<?= $dv['quantity']!==1?'s':'' ?></span></div>
                        <?php if ($dv['estimated_value']): ?>
                        <div class="info-g"><span class="lbl">Est. Value</span><span class="val amount-mono">₱<?= number_format((float)$dv['estimated_value'],2) ?></span></div>
                        <?php endif; ?>
                        <?php if ($dv['item_desc']): ?>
                        <div class="info-g"><span class="lbl">Description</span><span class="val" style="font-size:.82rem;color:var(--color-muted);"><?= e($dv['item_desc']) ?></span></div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Donor info -->
                <div style="background:var(--color-surface-2);border-radius:10px;padding:14px 16px;margin-bottom:16px;">
                    <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:1.5px;color:var(--color-muted);font-weight:700;margin-bottom:10px;">Donor</div>
                    <div class="info-g"><span class="lbl">Name</span><strong class="val"><?= e($dv['donor_name']) ?></strong></div>
                    <div class="info-g"><span class="lbl">Email</span><span class="val" style="font-size:.82rem;"><?= e($dv['donor_email']) ?></span></div>
                    <div class="info-g"><span class="lbl">Phone</span><span class="val"><?= e($dv['donor_phone'] ?: '—') ?></span></div>
                    <?php if ($dv['pickup_address']): ?>
                    <div class="info-g"><span class="lbl">Pickup Addr</span><span class="val" style="font-size:.82rem;"><?= e($dv['pickup_address']) ?></span></div>
                    <?php endif; ?>
                </div>

                <!-- Delivery timeline -->
                <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:1.5px;color:var(--color-muted);font-weight:700;margin-bottom:10px;">Delivery Timeline</div>
                <div class="timeline">
                    <div class="tl-step <?= $step >= 0 ? 'done' : '' ?>"><strong>Request Submitted</strong><div style="color:var(--color-muted);"><?= date('M d, Y g:i A', strtotime($dv['created_at'])) ?></div></div>
                    <div class="tl-step <?= $step >= 1 ? 'done' : ($step === 1 ? 'active' : '') ?>">
                        <strong>Admin Approved</strong>
                        <?php if ($dv['approver_name']): ?><div style="color:var(--color-muted);">By <?= e($dv['approver_name']) ?></div><?php endif; ?>
                        <?php if ($dv['pickup_date']): ?><div style="color:var(--color-muted);">Pickup: <?= date('M d, Y', strtotime($dv['pickup_date'])) ?></div><?php endif; ?>
                    </div>
                    <div class="tl-step <?= $step >= 2 ? 'done' : '' ?>">
                        <strong>In Transit</strong>
                        <?php if ($dv['tracking_code']): ?><div style="color:var(--brand-primary);font-family:var(--font-mono);font-size:.8rem;">Tracking: <?= e($dv['tracking_code']) ?></div><?php endif; ?>
                        <?php if ($dv['estimated_delivery']): ?><div style="color:var(--color-muted);">Est. Delivery: <?= date('M d, Y', strtotime($dv['estimated_delivery'])) ?></div><?php endif; ?>
                    </div>
                    <div class="tl-step <?= $step >= 3 ? 'done' : '' ?>">
                        <strong>Delivered</strong>
                        <?php if ($dv['delivered_at']): ?><div style="color:var(--color-muted);"><?= date('M d, Y g:i A', strtotime($dv['delivered_at'])) ?></div><?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Right column: update form + proof -->
            <div>
                <?php if ($dv['proof_photo']): ?>
                <div style="margin-bottom:18px;">
                    <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:1.5px;color:var(--color-muted);font-weight:700;margin-bottom:8px;">Delivery Proof Photo</div>
                    <img src="/<?= e($dv['proof_photo']) ?>" class="proof-img" alt="Proof of delivery" onclick="openImgZoom('/<?= e($dv['proof_photo']) ?>')">
                    <div style="font-size:.75rem;color:var(--color-muted);margin-top:6px;"><i class="fas fa-check-circle" style="color:var(--color-success);"></i> Delivery confirmed with photo</div>
                </div>
                <?php endif; ?>

                <!-- Admin update form -->
                <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:1.5px;color:var(--color-muted);font-weight:700;margin-bottom:12px;">Update Delivery</div>
                <form method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="update_delivery">
                    <input type="hidden" name="delivery_id" value="<?= $dv['delivery_id'] ?>">

                    <div class="form-group">
                        <label class="form-label">Status</label>
                        <select class="form-input" name="status">
                            <?php foreach (['requested'=>'Requested','approved'=>'Approved','in_transit'=>'In Transit','delivered'=>'Delivered','cancelled'=>'Cancelled'] as $k=>$v): ?>
                            <option value="<?= $k ?>" <?= $dv['status']===$k?'selected':'' ?>><?= $v ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Tracking Code</label>
                        <input class="form-input" type="text" name="tracking_code"
                               value="<?= e($dv['tracking_code']??'') ?>"
                               placeholder="e.g. LBC-123456789">
                    </div>

                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                        <div class="form-group">
                            <label class="form-label">Pickup Date</label>
                            <input class="form-input" type="date" name="pickup_date" value="<?= e($dv['pickup_date']??'') ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Est. Delivery</label>
                            <input class="form-input" type="date" name="estimated_delivery" value="<?= e($dv['estimated_delivery']??'') ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Pickup Address</label>
                        <input class="form-input" type="text" name="pickup_address"
                               value="<?= e($dv['pickup_address']??'') ?>"
                               placeholder="Where to collect the item">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Admin Notes</label>
                        <textarea class="form-textarea" name="notes" rows="2" placeholder="Internal notes…"><?= e($dv['notes']??'') ?></textarea>
                    </div>

                    <div style="display:flex;gap:10px;flex-wrap:wrap;">
                        <button type="submit" class="btn-primary" style="flex:1;justify-content:center;">
                            <i class="fas fa-save"></i> Save Changes
                        </button>
                    </div>
                </form>

                <!-- Proof photo upload -->
                <?php if ($dv['status'] !== 'delivered'): ?>
                <div style="margin-top:16px;padding-top:16px;border-top:1px solid var(--color-border);">
                    <div style="font-size:.8rem;font-weight:600;margin-bottom:8px;">Upload Proof of Delivery</div>
                    <div style="display:flex;gap:8px;align-items:center;">
                        <input type="file" id="proof-file-<?= $dv['delivery_id'] ?>" accept="image/*" style="display:none;"
                               onchange="uploadProof(<?= $dv['delivery_id'] ?>, this)">
                        <button class="btn-secondary" style="font-size:.8rem;"
                                onclick="document.getElementById('proof-file-<?= $dv['delivery_id'] ?>').click()">
                            <i class="fas fa-camera"></i> Upload Photo
                        </button>
                        <span id="proof-status-<?= $dv['delivery_id'] ?>" style="font-size:.8rem;color:var(--color-muted);"></span>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</main>

<!-- Add Courier Modal -->
<div class="modal-overlay" id="addCourierModal">
    <div class="modal-box" style="max-width:440px;">
        <div class="modal-header">
            <h4><i class="fas fa-truck" style="color:var(--brand-primary);margin-right:8px;"></i> Add Courier Partner</h4>
            <button class="modal-close" onclick="closeModal('addCourierModal')">&times;</button>
        </div>
        <form method="POST">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="add_courier">
            <div class="form-group">
                <label class="form-label">Courier Name <span style="color:var(--color-danger);">*</span></label>
                <input class="form-input" type="text" name="name" placeholder="e.g., LBC Express" required>
            </div>
            <div class="form-group">
                <label class="form-label">Tracking URL (optional)</label>
                <input class="form-input" type="url" name="api_endpoint" placeholder="https://track.courier.com/">
            </div>
            <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:8px;">
                <button type="button" class="btn-secondary" onclick="closeModal('addCourierModal')">Cancel</button>
                <button type="submit" class="btn-primary"><i class="fas fa-plus"></i> Add Courier</button>
            </div>
        </form>
    </div>
</div>

<!-- Image zoom modal -->
<div class="modal-overlay" id="imgZoomModal" onclick="closeModal('imgZoomModal')">
    <div style="position:relative;" onclick="event.stopPropagation()">
        <img id="imgZoomSrc" src="" style="max-width:92vw;max-height:90vh;border-radius:12px;box-shadow:0 20px 60px rgba(0,0,0,.7);">
        <button onclick="closeModal('imgZoomModal')"
                style="position:absolute;top:-14px;right:-14px;width:32px;height:32px;border-radius:50%;background:var(--color-danger);color:white;border:none;cursor:pointer;font-weight:900;font-size:1.1rem;line-height:1;">×</button>
    </div>
</div>

<script src="/assets/js/global.js"></script>
<script src="/assets/js/dashboard.js"></script>
<script>
window._SESS = '<?= $_SESS_PARAM ?>';

function toggleDelivery(id) {
    const body    = document.getElementById('body-'+id);
    const chevron = document.getElementById('chevron-'+id);
    const open    = body.style.display !== 'none' && body.style.display !== '';
    body.style.display    = open ? 'none' : 'grid';
    chevron.style.transform = open ? '' : 'rotate(180deg)';
}

function openImgZoom(url) {
    document.getElementById('imgZoomSrc').src = url;
    openModal('imgZoomModal');
}

async function uploadProof(deliveryId, input) {
    const file    = input.files[0];
    const status  = document.getElementById('proof-status-' + deliveryId);
    if (!file) return;

    status.textContent = 'Uploading…';
    const fd = new FormData();
    fd.append('proof', file);
    fd.append('delivery_id', deliveryId);
    fd.append('action', 'upload_proof');
    fd.append('csrf_token', document.querySelector('meta[name="csrf-token"]')?.content || '');

    try {
        const res  = await fetch('/api/update_delivery.php' + window._SESS, { method:'POST', body:fd });
        const data = await res.json();
        if (data.success) {
            showToast(data.message);
            status.textContent = '✓ Uploaded';
            status.style.color = 'var(--color-success)';
            // Refresh after 1 second to show proof
            setTimeout(() => window.location.reload(), 1200);
        } else {
            showToast(data.message || 'Upload failed', 'error');
            status.textContent = 'Failed';
        }
    } catch(e) {
        showToast('Network error', 'error');
        status.textContent = '';
    }
    input.value = '';
}
</script>
</body></html>
