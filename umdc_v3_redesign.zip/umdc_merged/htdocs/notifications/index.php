<?php
// =============================================================
// UMDC – Notifications Page
// Accessible by all roles: user, organization, admin
// =============================================================
defined('UMDC_APP') or define('UMDC_APP', true);
require_once __DIR__ . '/../Config/security.php';
require_once __DIR__ . '/../Config/db.php';
require_once __DIR__ . '/../Config/notifications.php';
umdc_session_start();
setSecureHeaders();
requireAnyRole(['user', 'organization', 'admin']);

$role    = currentRole();
$userId  = currentUserId();

// Role-specific session param
$_SESS_PARAM = match($role) {
    'admin'        => '?_sess=UMDC_ADMIN',
    'organization' => '?_sess=UMDC_ORG',
    default        => '?_sess=UMDC_USER',
};

// Role-specific dashboard link
$dashLink = match($role) {
    'admin'        => '/dashboard/admin.php',
    'organization' => '/dashboard/organization.php',
    default        => '/dashboard/user.php',
};

// Handle mark read via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = $_POST['action'] ?? '';
    if ($action === 'read_all') {
        Notifier::markRead($pdo, $userId);
    } elseif ($action === 'read' && !empty($_POST['id'])) {
        Notifier::markRead($pdo, $userId, (int)$_POST['id']);
    }
    header('Location: /notifications/index.php' . $_SESS_PARAM);
    exit;
}

// Pagination
$page   = max(1, (int)($_GET['page'] ?? 1));
$limit  = 20;
$offset = ($page - 1) * $limit;

// Filter
$filter = $_GET['filter'] ?? 'all';
$allowedFilters = ['all', 'unread', 'donation', 'campaign', 'security', 'courier'];

if (!in_array($filter, $allowedFilters, true)) $filter = 'all';

$where = 'WHERE n.user_id = :uid AND (n.expires_at IS NULL OR n.expires_at > NOW())';
$params = [':uid' => $userId];

if ($filter === 'unread') {
    $where .= ' AND n.is_read = 0';
} elseif ($filter !== 'all') {
    $where .= ' AND n.type LIKE :typefilter';
    $params[':typefilter'] = $filter . '%';
}

$totalStmt = $pdo->prepare("SELECT COUNT(*) FROM notifications n $where");
$totalStmt->execute($params);
$total = (int)$totalStmt->fetchColumn();
$totalPages = max(1, ceil($total / $limit));

$params[':limit']  = $limit;
$params[':offset'] = $offset;
$stmt = $pdo->prepare("
    SELECT notification_id, message, type, link, icon, priority,
           is_read, read_at, created_at
    FROM notifications n
    $where
    ORDER BY created_at DESC
    LIMIT :limit OFFSET :offset
");
$stmt->bindValue(':uid', $userId, PDO::PARAM_INT);
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
if ($filter === 'unread') {
    // no extra bind
} elseif ($filter !== 'all') {
    $stmt->bindValue(':typefilter', $filter . '%');
}
$stmt->execute();
$notifications = $stmt->fetchAll();

$unreadCount = Notifier::getUnreadCount($pdo, $userId);

function time_ago(string $dt): string {
    $diff = time() - strtotime($dt);
    if ($diff < 60)     return 'just now';
    if ($diff < 3600)   return floor($diff/60) . ' min ago';
    if ($diff < 86400)  return floor($diff/3600) . ' hr ago';
    if ($diff < 604800) return floor($diff/86400) . ' days ago';
    return date('M j, Y', strtotime($dt));
}

function notif_icon_class(string $type): string {
    if (str_starts_with($type, 'donation'))   return 'notif-page-icon--donation';
    if (str_starts_with($type, 'campaign'))   return 'notif-page-icon--campaign';
    if (str_starts_with($type, 'courier') || str_starts_with($type, 'delivery')) return 'notif-page-icon--courier';
    if (str_starts_with($type, 'verification') || str_starts_with($type, 'org_verif')) return 'notif-page-icon--verify';
    if (str_starts_with($type, 'password') || str_starts_with($type, 'login') || str_starts_with($type, 'email_verif')) return 'notif-page-icon--security';
    if (str_starts_with($type, 'admin'))      return 'notif-page-icon--admin';
    return 'notif-page-icon--default';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<meta name="csrf-token" content="<?= csrf_token() ?>">
<meta name="sess-name" content="<?= match($role) { 'admin' => 'UMDC_ADMIN', 'organization' => 'UMDC_ORG', default => 'UMDC_USER' } ?>">
<title>Notifications – UMDC</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="/assets/css/global.css">
<link rel="stylesheet" href="/assets/css/dashboard.css">
<link rel="stylesheet" href="/assets/css/notifications.css">
<style>
/* ── Page-level overrides ── */
.notif-page-wrap     { max-width: 760px; margin: 0 auto; padding: 0 0 60px; }
.notif-page-header   { display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px; margin-bottom:24px; }
.notif-page-title    { font-size:1.4rem; font-weight:700; margin:0; display:flex; align-items:center; gap:10px; }
.notif-page-title .badge-pill { font-size:.7rem; }

/* Filter bar */
.notif-filters       { display:flex; gap:6px; flex-wrap:wrap; margin-bottom:20px; }
.notif-filter-btn    { padding:6px 14px; border-radius:20px; border:1px solid var(--color-border); background:var(--color-surface); color:var(--color-muted); font-size:.8rem; font-weight:500; cursor:pointer; font-family:var(--font-sans); transition:var(--transition); text-decoration:none; display:inline-flex; align-items:center; gap:6px; }
.notif-filter-btn:hover, .notif-filter-btn.active { background:var(--brand-primary); border-color:var(--brand-primary); color:#fff; text-decoration:none; }

/* Card list */
.notif-page-list     { display:flex; flex-direction:column; gap:0; background:var(--color-surface); border:1px solid var(--color-border); border-radius:var(--radius-lg); overflow:hidden; }
.notif-page-item     { display:flex; align-items:flex-start; gap:16px; padding:16px 20px; border-bottom:1px solid var(--color-border); transition:background .15s; position:relative; text-decoration:none; color:inherit; }
.notif-page-item:last-child { border-bottom:none; }
.notif-page-item:hover { background:var(--color-surface-2); }
.notif-page-item.unread { background:rgba(59,111,240,.035); }
.notif-page-item.unread::before { content:''; position:absolute; left:0; top:0; bottom:0; width:3px; background:var(--brand-primary); border-radius:0 2px 2px 0; }

/* Icon */
.notif-page-icon     { flex-shrink:0; width:42px; height:42px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:.95rem; }
.notif-page-icon--donation  { background:rgba(5,150,105,.1);   color:var(--color-success); }
.notif-page-icon--campaign  { background:rgba(59,111,240,.1);  color:var(--brand-primary); }
.notif-page-icon--courier   { background:rgba(2,132,199,.1);   color:var(--color-info); }
.notif-page-icon--verify    { background:rgba(124,58,237,.1);  color:var(--brand-secondary); }
.notif-page-icon--security  { background:rgba(220,38,38,.08);  color:var(--color-danger); }
.notif-page-icon--admin     { background:rgba(217,119,6,.1);   color:var(--color-warning); }
.notif-page-icon--default   { background:var(--color-surface-2); color:var(--color-muted); }

/* Content */
.notif-page-body     { flex:1; min-width:0; }
.notif-page-msg      { font-size:.9rem; line-height:1.5; margin:0 0 4px; color:var(--color-text); }
.notif-page-meta     { display:flex; align-items:center; gap:10px; font-size:.75rem; color:var(--color-muted); }
.notif-priority-tag  { display:inline-flex; align-items:center; gap:4px; padding:2px 7px; border-radius:10px; font-size:.68rem; font-weight:600; text-transform:uppercase; letter-spacing:.4px; }
.priority-urgent     { background:rgba(220,38,38,.1); color:var(--color-danger); }
.priority-high       { background:rgba(217,119,6,.1); color:var(--color-warning); }
.priority-normal     { background:rgba(5,150,105,.08); color:var(--color-success); }

/* Mark read button */
.notif-page-action { flex-shrink:0; }
.btn-mark-read { border:none; background:none; color:var(--color-muted); cursor:pointer; font-size:.85rem; padding:6px; border-radius:var(--radius-sm); transition:var(--transition); }
.btn-mark-read:hover { background:var(--color-surface-2); color:var(--brand-primary); }

/* Pagination */
.notif-pagination { display:flex; align-items:center; justify-content:center; gap:8px; margin-top:24px; }
.notif-page-num { width:36px; height:36px; display:flex; align-items:center; justify-content:center; border:1px solid var(--color-border); border-radius:var(--radius-md); font-size:.85rem; color:var(--color-muted); text-decoration:none; transition:var(--transition); }
.notif-page-num:hover, .notif-page-num.active { background:var(--brand-primary); border-color:var(--brand-primary); color:#fff; text-decoration:none; }

/* Empty */
.notif-page-empty { text-align:center; padding:60px 20px; color:var(--color-muted); }
.notif-page-empty i { font-size:2.5rem; opacity:.3; display:block; margin-bottom:12px; }
.notif-page-empty h5 { margin:0 0 6px; font-size:1rem; color:var(--color-text); }
.notif-page-empty p  { margin:0; font-size:.85rem; }

/* Mark all bar */
.notif-actions-bar { display:flex; align-items:center; justify-content:space-between; margin-bottom:12px; }
.notif-count-text  { font-size:.85rem; color:var(--color-muted); }
</style>
</head>
<body>
<?php
if ($role === 'admin') include __DIR__ . '/../components/admin_sidebar.php';
elseif ($role === 'organization') include __DIR__ . '/../components/org_sidebar.php';
else include __DIR__ . '/../components/user_sidebar.php';
?>

<main class="main-content">
<div class="notif-page-wrap">

    <!-- Header -->
    <div class="notif-page-header">
        <h1 class="notif-page-title">
            <i class="fas fa-bell" style="color:var(--brand-primary);"></i>
            Notifications
            <?php if ($unreadCount > 0): ?>
            <span class="badge-pill badge-info"><?= $unreadCount ?> unread</span>
            <?php endif; ?>
        </h1>
        <a href="<?= $dashLink . $_SESS_PARAM ?>" class="btn-secondary" style="font-size:.85rem;padding:8px 16px;">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>

    <!-- Filter tabs -->
    <div class="notif-filters">
        <?php
        $filters = [
            'all'      => ['label' => 'All',       'icon' => 'fa-list'],
            'unread'   => ['label' => 'Unread',    'icon' => 'fa-circle-dot'],
            'donation' => ['label' => 'Donations', 'icon' => 'fa-heart'],
            'campaign' => ['label' => 'Campaigns', 'icon' => 'fa-bullhorn'],
            'courier'  => ['label' => 'Delivery',  'icon' => 'fa-truck'],
            'security' => ['label' => 'Security',  'icon' => 'fa-shield'],
        ];
        foreach ($filters as $key => $f):
            $active = $filter === $key ? ' active' : '';
            $url    = '/notifications/index.php' . $_SESS_PARAM . '&filter=' . $key;
        ?>
        <a href="<?= $url ?>" class="notif-filter-btn<?= $active ?>">
            <i class="fas <?= $f['icon'] ?>"></i> <?= $f['label'] ?>
        </a>
        <?php endforeach; ?>
    </div>

    <!-- Actions bar -->
    <div class="notif-actions-bar">
        <span class="notif-count-text">
            <?= number_format($total) ?> notification<?= $total !== 1 ? 's' : '' ?>
            <?= $filter !== 'all' ? '· filtered by <strong>' . htmlspecialchars($filter) . '</strong>' : '' ?>
        </span>
        <?php if ($unreadCount > 0): ?>
        <form method="POST" style="display:inline;">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="read_all">
            <button type="submit" class="btn-secondary" style="font-size:.8rem;padding:6px 14px;">
                <i class="fas fa-check-double"></i> Mark all read
            </button>
        </form>
        <?php endif; ?>
    </div>

    <!-- Notification list -->
    <?php if (empty($notifications)): ?>
    <div class="notif-page-list">
        <div class="notif-page-empty">
            <i class="fas fa-bell-slash"></i>
            <h5>
                <?= $filter === 'unread' ? 'No unread notifications' : 'No notifications yet' ?>
            </h5>
            <p>
                <?= $filter === 'unread'
                    ? 'You\'re all caught up!'
                    : 'Notifications about your donations, campaigns and deliveries will appear here.' ?>
            </p>
        </div>
    </div>
    <?php else: ?>
    <div class="notif-page-list">
        <?php foreach ($notifications as $n): ?>
        <?php
            $isUnread = !(bool)$n['is_read'];
            $icon     = $n['icon'] ?? 'fa-bell';
            $icClass  = notif_icon_class($n['type'] ?? '');
            $timeAgo  = time_ago($n['created_at']);
            $fullDate = date('M j, Y g:i A', strtotime($n['created_at']));
            $link     = !empty($n['link']) ? $n['link'] . (str_contains($n['link'], '?') ? '&' : '?') . ltrim($_SESS_PARAM, '?') : '';
            $priority = $n['priority'] ?? 'normal';
        ?>
        <div class="notif-page-item <?= $isUnread ? 'unread' : '' ?>"
             data-id="<?= (int)$n['notification_id'] ?>"
             <?= $link ? 'style="cursor:pointer;" onclick="handleNotifClick(this, \'' . htmlspecialchars($link, ENT_QUOTES) . '\')"' : '' ?>>

            <div class="notif-page-icon <?= $icClass ?>">
                <i class="fas <?= htmlspecialchars($icon) ?>"></i>
            </div>

            <div class="notif-page-body">
                <p class="notif-page-msg"><?= htmlspecialchars($n['message']) ?></p>
                <div class="notif-page-meta">
                    <span title="<?= $fullDate ?>"><?= $timeAgo ?></span>
                    <?php if (in_array($priority, ['urgent','high'])): ?>
                    <span class="notif-priority-tag priority-<?= $priority ?>">
                        <i class="fas <?= $priority === 'urgent' ? 'fa-bolt' : 'fa-arrow-up' ?>"></i>
                        <?= $priority ?>
                    </span>
                    <?php endif; ?>
                    <?php if ($n['read_at']): ?>
                    <span style="color:var(--color-success);font-size:.72rem;">
                        <i class="fas fa-check"></i> Read <?= time_ago($n['read_at']) ?>
                    </span>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($isUnread): ?>
            <div class="notif-page-action">
                <form method="POST" onclick="event.stopPropagation();">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="read">
                    <input type="hidden" name="id" value="<?= (int)$n['notification_id'] ?>">
                    <button type="submit" class="btn-mark-read" title="Mark as read">
                        <i class="fas fa-check"></i>
                    </button>
                </form>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
    <nav class="notif-pagination" aria-label="Notifications pages">
        <?php if ($page > 1): ?>
        <a href="/notifications/index.php<?= $_SESS_PARAM ?>&filter=<?= $filter ?>&page=<?= $page-1 ?>" class="notif-page-num">
            <i class="fas fa-chevron-left"></i>
        </a>
        <?php endif; ?>

        <?php
        $start = max(1, $page - 2);
        $end   = min($totalPages, $page + 2);
        for ($p = $start; $p <= $end; $p++):
        ?>
        <a href="/notifications/index.php<?= $_SESS_PARAM ?>&filter=<?= $filter ?>&page=<?= $p ?>"
           class="notif-page-num <?= $p === $page ? 'active' : '' ?>">
            <?= $p ?>
        </a>
        <?php endfor; ?>

        <?php if ($page < $totalPages): ?>
        <a href="/notifications/index.php<?= $_SESS_PARAM ?>&filter=<?= $filter ?>&page=<?= $page+1 ?>" class="notif-page-num">
            <i class="fas fa-chevron-right"></i>
        </a>
        <?php endif; ?>
    </nav>
    <?php endif; ?>
    <?php endif; ?>

</div>
</main>

<script>
const CSRF = document.querySelector('meta[name="csrf-token"]')?.content || '';
const SESS = '<?= addslashes(ltrim($_SESS_PARAM, '?')) ?>';

async function handleNotifClick(el, link) {
    const id = el.dataset.id;
    if (el.classList.contains('unread')) {
        el.classList.remove('unread');
        // Mark read via API silently
        const fd = new FormData();
        fd.append('action', 'read');
        fd.append('id', id);
        fd.append('csrf_token', CSRF);
        fetch('/api/notifications.php?' + SESS, { method: 'POST', body: fd }).catch(() => {});
    }
    if (link) window.location.href = link;
}
</script>
<script src="/assets/js/notifications.js"></script>
</body>
</html>
