<?php
// =============================================================
// UMDC – Email Queue Processor
// =============================================================
// Run via cron every minute:
//   * * * * * php /path/to/htdocs/notifications/process_email.php
//
// Or run manually:
//   php notifications/process_email.php
//
// Driver is set in system_settings table: email_driver
//   Supported: 'mail' (PHP mail), 'smtp' (via PHPMailer if present)
// =============================================================
defined('UMDC_APP') or define('UMDC_APP', true);

// CLI-only guard
if (PHP_SAPI !== 'cli' && !defined('UMDC_CRON')) {
    http_response_code(403);
    exit('CLI only');
}

require_once __DIR__ . '/../Config/db.php';

$batchSize  = 20;   // emails per run
$maxRetries = 3;

// Fetch config from DB
function getSetting(PDO $pdo, string $key, string $default = ''): string {
    try {
        $s = $pdo->prepare("SELECT value FROM system_settings WHERE `key` = ?");
        $s->execute([$key]);
        return $s->fetchColumn() ?: $default;
    } catch (PDOException $e) {
        return $default;
    }
}

$fromEmail = getSetting($pdo, 'mail_from_email', 'no-reply@umdc.ph');
$fromName  = getSetting($pdo, 'mail_from_name',  'UMDC');
$driver    = getSetting($pdo, 'email_driver',     'mail');

// Fetch queued emails
$stmt = $pdo->prepare("
    SELECT id, to_email, to_name, subject, body_html, body_text, attempts
    FROM email_queue
    WHERE status = 'queued'
      AND attempts < ?
    ORDER BY created_at ASC
    LIMIT ?
");
$stmt->execute([$maxRetries, $batchSize]);
$emails = $stmt->fetchAll();

if (empty($emails)) {
    echo date('[Y-m-d H:i:s]') . " No emails in queue.\n";
    exit(0);
}

$sent = 0;
$failed = 0;

foreach ($emails as $email) {
    $success = false;
    $errorMsg = '';

    try {
        if ($driver === 'smtp' && class_exists('PHPMailer\PHPMailer\PHPMailer')) {
            // PHPMailer SMTP path
            $mail = new PHPMailer\PHPMailer\PHPMailer(true);
            $mail->isSMTP();
            $mail->Host       = getSetting($pdo, 'smtp_host', 'localhost');
            $mail->SMTPAuth   = true;
            $mail->Username   = getSetting($pdo, 'smtp_user', '');
            $mail->Password   = getSetting($pdo, 'smtp_pass', '');
            $mail->SMTPSecure = getSetting($pdo, 'smtp_secure', 'tls');
            $mail->Port       = (int)getSetting($pdo, 'smtp_port', '587');
            $mail->setFrom($fromEmail, $fromName);
            $mail->addAddress($email['to_email'], $email['to_name'] ?? '');
            $mail->Subject    = $email['subject'];
            $mail->isHTML(true);
            $mail->Body       = $email['body_html'];
            $mail->AltBody    = $email['body_text'];
            $mail->send();
            $success = true;
        } else {
            // PHP mail() fallback
            $boundary  = md5(uniqid());
            $toName    = $email['to_name'] ? "=?UTF-8?B?" . base64_encode($email['to_name']) . "?= <{$email['to_email']}>" : $email['to_email'];
            $headers   = implode("\r\n", [
                "MIME-Version: 1.0",
                "Content-Type: multipart/alternative; boundary=\"{$boundary}\"",
                "From: =?UTF-8?B?" . base64_encode($fromName) . "?= <{$fromEmail}>",
                "Reply-To: {$fromEmail}",
                "X-Mailer: UMDC/2.4",
            ]);
            $body = "--{$boundary}\r\n"
                  . "Content-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n"
                  . chunk_split(base64_encode($email['body_text'])) . "\r\n"
                  . "--{$boundary}\r\n"
                  . "Content-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n"
                  . chunk_split(base64_encode($email['body_html'])) . "\r\n"
                  . "--{$boundary}--";

            $success = mail($toName, '=?UTF-8?B?' . base64_encode($email['subject']) . '?=', $body, $headers);
            if (!$success) $errorMsg = error_get_last()['message'] ?? 'mail() returned false';
        }
    } catch (Throwable $e) {
        $errorMsg = $e->getMessage();
    }

    if ($success) {
        $pdo->prepare("UPDATE email_queue SET status='sent', sent_at=NOW(), last_attempt=NOW() WHERE id=?")
            ->execute([$email['id']]);
        $sent++;
        echo date('[Y-m-d H:i:s]') . " ✓ Sent to {$email['to_email']} — {$email['subject']}\n";
    } else {
        $newAttempts = $email['attempts'] + 1;
        $newStatus   = $newAttempts >= $maxRetries ? 'failed' : 'queued';
        $pdo->prepare("UPDATE email_queue SET status=?, attempts=?, last_attempt=NOW(), error_msg=? WHERE id=?")
            ->execute([$newStatus, $newAttempts, $errorMsg, $email['id']]);
        $failed++;
        echo date('[Y-m-d H:i:s]') . " ✗ Failed to {$email['to_email']}: {$errorMsg}\n";
    }
}

echo date('[Y-m-d H:i:s]') . " Done. Sent: {$sent}, Failed: {$failed}\n";
