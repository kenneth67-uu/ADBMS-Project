<?php
// =============================================================
// UMDC – SMS Queue Processor (Semaphore SMS Gateway)
// =============================================================
// Run via cron every minute:
//   * * * * * php /path/to/htdocs/notifications/process_sms.php
//
// Add to system_settings:
//   semaphore_api_key  →  your Semaphore API key
//   sms_sender_name    →  UMDC  (up to 11 chars)
// =============================================================
defined('UMDC_APP') or define('UMDC_APP', true);

if (PHP_SAPI !== 'cli' && !defined('UMDC_CRON')) {
    http_response_code(403);
    exit('CLI only');
}

require_once __DIR__ . '/../Config/db.php';
if (defined('SEMAPHORE_API_KEY') || file_exists(__DIR__ . '/../Config/keys.php')) {
    @include_once __DIR__ . '/../Config/keys.php';
}

$batchSize  = 10;
$maxRetries = 3;

function getSetting(PDO $pdo, string $key, string $default = ''): string {
    // Prefer PHP constant if defined
    $constMap = [
        'semaphore_api_key' => defined('SEMAPHORE_API_KEY') ? SEMAPHORE_API_KEY : null,
        'sms_sender_name'   => defined('SEMAPHORE_SENDER')  ? SEMAPHORE_SENDER  : null,
    ];
    if (isset($constMap[$key]) && $constMap[$key] !== null) return $constMap[$key];
    try {
        $s = $pdo->prepare("SELECT value FROM system_settings WHERE `key` = ?");
        $s->execute([$key]);
        return $s->fetchColumn() ?: $default;
    } catch (PDOException $e) {
        return $default;
    }
}

$apiKey     = getSetting($pdo, 'semaphore_api_key', '');
$senderName = getSetting($pdo, 'sms_sender_name', 'UMDC');

if (empty($apiKey)) {
    echo date('[Y-m-d H:i:s]') . " No Semaphore API key set. Skipping SMS.\n";
    exit(0);
}

$stmt = $pdo->prepare("
    SELECT id, to_phone, message, attempts
    FROM sms_queue
    WHERE status = 'queued' AND attempts < ?
    ORDER BY created_at ASC
    LIMIT ?
");
$stmt->execute([$maxRetries, $batchSize]);
$messages = $stmt->fetchAll();

if (empty($messages)) {
    echo date('[Y-m-d H:i:s]') . " No SMS in queue.\n";
    exit(0);
}

$sent = 0; $failed = 0;

foreach ($messages as $sms) {
    $success  = false;
    $errorMsg = '';

    try {
        $payload = http_build_query([
            'apikey'      => $apiKey,
            'number'      => $sms['to_phone'],
            'message'     => $sms['message'],
            'sendername'  => $senderName,
        ]);
        $ctx = stream_context_create(['http' => [
            'method'  => 'POST',
            'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
            'content' => $payload,
            'timeout' => 10,
        ]]);
        $response = @file_get_contents('https://api.semaphore.co/api/v4/messages', false, $ctx);
        $data = $response ? json_decode($response, true) : null;
        $success = $data && isset($data[0]['message_id']);
        if (!$success) $errorMsg = $response ?: 'No response';

    } catch (Throwable $e) {
        $errorMsg = $e->getMessage();
    }

    if ($success) {
        $pdo->prepare("UPDATE sms_queue SET status='sent', sent_at=NOW() WHERE id=?")
            ->execute([$sms['id']]);
        $sent++;
        echo date('[Y-m-d H:i:s]') . " ✓ SMS to {$sms['to_phone']}\n";
    } else {
        $newAttempts = $sms['attempts'] + 1;
        $newStatus   = $newAttempts >= $maxRetries ? 'failed' : 'queued';
        $pdo->prepare("UPDATE sms_queue SET status=?, attempts=?, error_msg=? WHERE id=?")
            ->execute([$newStatus, $newAttempts, $errorMsg, $sms['id']]);
        $failed++;
        echo date('[Y-m-d H:i:s]') . " ✗ SMS failed to {$sms['to_phone']}: {$errorMsg}\n";
    }
}

echo date('[Y-m-d H:i:s]') . " Done. Sent: {$sent}, Failed: {$failed}\n";
