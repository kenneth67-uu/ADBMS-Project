<?php
defined('UMDC_APP') or define('UMDC_APP', true);
require_once __DIR__ . '/../Config/security.php';
require_once __DIR__ . '/../Config/db.php';
umdc_session_start();
requireRole('admin');
setSecureHeaders();
$_SESS_PARAM = '?_sess=UMDC_ADMIN';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id     = filter_var($_POST['req_id'] ?? 0, FILTER_VALIDATE_INT);
    $action = $_POST['action'] ?? '';
    $notes  = sanitizeInput($_POST['review_notes'] ?? '');

    if ($id && in_array($action, ['approve','reject'], true)) {
        $pdo->beginTransaction();
        $req = $pdo->prepare("SELECT * FROM verification_requests WHERE id=?");
        $req->execute([$id]);
        $req = $req->fetch();
        if ($req) {
            $status = $action === 'approve' ? 'approved' : 'rejected';
            $pdo->prepare("UPDATE verification_requests SET status=?, reviewed_by=?, review_notes=? WHERE id=?")
                ->execute([$status, currentUserId(), $notes, $id]);
            if ($action === 'approve') {
                $pdo->prepare("UPDATE users SET is_verified=1 WHERE user_id=?")->execute([$req['user_id']]);
                if ($req['type'] === 'organization') {
                    $pdo->prepare("UPDATE organizations SET verified=1 WHERE user_id=?")->execute([$req['user_id']]);
                }
            }
            auditLog($pdo, currentUserId(), "verification_{$action}", 'verification_request', $id);
        }
        $pdo->commit();
    }
    header("Location: /verification/verify_user.php{$_SESS_PARAM}&updated=1");
    exit;
}

$filter   = in_array($_GET['filter'] ?? 'pending', ['pending','approved','rejected','']) ? ($_GET['filter'] ?? 'pending') : 'pending';
$whereSQL = $filter ? "WHERE v.status = '$filter'" : '';

$requests = $pdo->query("
    SELECT v.*,
           CONCAT(u.first_name,' ',u.last_name) AS user_name,
           u.email, u.phone, u.address, u.is_verified, u.created_at AS user_created,
           r.role_name,
           o.org_name, o.org_email, o.org_contact, o.description AS org_desc, o.verified AS org_verified
    FROM verification_requests v
    JOIN users u ON v.user_id = u.user_id
    JOIN roles r ON u.role_id = r.role_id
    LEFT JOIN organizations o ON o.user_id = u.user_id
    $whereSQL
    ORDER BY FIELD(v.status,'pending','approved','rejected'), v.created_at DESC
")->fetchAll();

$counts = $pdo->query("SELECT status, COUNT(*) FROM verification_requests GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Verifications – UMDC Admin</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<?php include __DIR__ . '/../components/admin_sidebar.php'; ?>
<style>
.verif-card{background:var(--color-surface);border:1px solid var(--color-border);border-radius:14px;margin-bottom:22px;overflow:hidden;}
.verif-head{padding:18px 22px;border-bottom:1px solid var(--color-border);display:flex;align-items:center;gap:14px;flex-wrap:wrap;background:rgba(255,255,255,.02);}
.verif-body{display:grid;grid-template-columns:1fr 380px;gap:0;}
.verif-info{padding:22px;border-right:1px solid var(--color-border);}
.verif-doc{padding:22px;}
.info-pair{display:flex;gap:0;margin-bottom:12px;font-size:.855rem;align-items:flex-start;}
.info-lbl{color:var(--color-muted);width:120px;flex-shrink:0;font-size:.78rem;padding-top:2px;}
.doc-frame{border:1px solid var(--color-border);border-radius:10px;overflow:hidden;margin-bottom:14px;background:#111;}
.doc-frame img{width:100%;max-height:280px;object-fit:contain;display:block;cursor:zoom-in;}
.doc-frame .pdf-icon{display:flex;align-items:center;gap:14px;padding:20px;background:var(--color-surface-2);}
.action-bar{padding:16px 22px;border-top:1px solid var(--color-border);display:flex;gap:10px;align-items:flex-start;flex-wrap:wrap;}
.reject-row{display:flex;gap:8px;align-items:flex-start;flex:1;min-width:260px;}
.section-label{font-size:.68rem;text-transform:uppercase;letter-spacing:2px;color:var(--color-muted);font-weight:700;margin-bottom:14px;display:block;}
@media(max-width:860px){.verif-body{grid-template-columns:1fr;}.verif-info{border-right:none;border-bottom:1px solid var(--color-border);}}
</style>

<main class="main-content">
    <div class="page-header">
        <h1>Verification Requests</h1>
        <p>Review submitted documents and approve or reject account verification requests.</p>
    </div>

    <?php if (isset($_GET['updated'])): ?>
    <div class="alert alert-success" data-auto-dismiss><i class="fas fa-check-circle"></i><span>Verification status updated.</span></div>
    <?php endif; ?>

    <!-- Tabs with counts -->
    <div style="display:flex;gap:8px;margin-bottom:24px;flex-wrap:wrap;">
        <?php foreach (['pending'=>'⏳ Pending','approved'=>'✅ Approved','rejected'=>'❌ Rejected',''=>'All'] as $k=>$label):
            $cnt = $k ? ($counts[$k] ?? 0) : array_sum($counts);
        ?>
        <a href="?_sess=UMDC_ADMIN<?= $k ? '&filter='.$k : '&filter=' ?>"
           class="<?= $filter===$k ? 'btn-primary' : 'btn-secondary' ?>"
           style="padding:8px 18px;font-size:.82rem;text-decoration:none;gap:8px;">
            <?= $label ?>
            <span style="background:rgba(255,255,255,.18);border-radius:20px;padding:1px 8px;font-size:.72rem;font-weight:700;"><?= $cnt ?></span>
        </a>
        <?php endforeach; ?>
    </div>

    <?php if (empty($requests)): ?>
    <div class="card">
        <div class="empty-state">
            <i class="fas fa-id-card-clip"></i>
            <h6>No <?= $filter ?> requests</h6>
            <p>All verification submissions appear here for review.</p>
        </div>
    </div>
    <?php endif; ?>

    <?php foreach ($requests as $v):
        $docPath = $v['document_path'] ?? '';
        $docUrl  = $docPath ? '/' . ltrim($docPath, '/') : '';
        $ext     = strtolower(pathinfo($docUrl, PATHINFO_EXTENSION));
        $isPdf   = ($ext === 'pdf');
        $isImg   = in_array($ext, ['jpg','jpeg','png','webp','gif']);
        $isOrg   = ($v['role_name'] === 'organization');
        $initials= strtoupper(substr($v['user_name'],0,1) . (strpos($v['user_name'],' ')!==false?substr(strrchr($v['user_name'],' '),1,1):''));
    ?>
    <div class="verif-card">

        <!-- Card header -->
        <div class="verif-head">
            <div style="width:46px;height:46px;border-radius:50%;background:var(--brand-gradient);display:flex;align-items:center;justify-content:center;color:white;font-weight:800;font-size:1rem;flex-shrink:0;">
                <?= $initials ?>
            </div>
            <div style="flex:1;">
                <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                    <strong style="font-size:1rem;"><?= e($v['user_name']) ?></strong>
                    <span class="badge-pill badge-role-<?= e($v['role_name']) ?>"><?= ucfirst($v['role_name']) ?></span>
                    <?php if ($isOrg && $v['org_name']): ?>
                    <span style="font-size:.82rem;color:var(--color-muted);">· <?= e($v['org_name']) ?></span>
                    <?php endif; ?>
                </div>
                <div style="font-size:.8rem;color:var(--color-muted);margin-top:3px;"><?= e($v['email']) ?> · Member since <?= date('M Y', strtotime($v['user_created'])) ?></div>
            </div>
            <div style="text-align:right;flex-shrink:0;">
                <span class="badge-pill badge-<?= $v['status']==='approved'?'active':($v['status']==='rejected'?'failed':'pending') ?>" style="font-size:.82rem;">
                    <?= ucfirst($v['status']) ?>
                </span>
                <div style="font-size:.72rem;color:var(--color-muted);margin-top:5px;">
                    Submitted <?= date('M d, Y', strtotime($v['created_at'])) ?>
                </div>
            </div>
        </div>

        <!-- Card body: info + document -->
        <div class="verif-body">

            <!-- Left: applicant info -->
            <div class="verif-info">
                <?php if ($isOrg && $v['org_name']): ?>
                <span class="section-label">Organization Details</span>
                <div class="info-pair"><span class="info-lbl">Org Name</span><strong><?= e($v['org_name']) ?></strong></div>
                <div class="info-pair"><span class="info-lbl">Org Email</span><span><?= e($v['org_email'] ?: '—') ?></span></div>
                <div class="info-pair"><span class="info-lbl">Org Contact</span><span><?= e($v['org_contact'] ?: '—') ?></span></div>
                <?php if ($v['org_desc']): ?>
                <div class="info-pair"><span class="info-lbl">Description</span><span style="font-size:.82rem;color:var(--color-muted);"><?= e(mb_substr($v['org_desc'],0,150)) ?>…</span></div>
                <?php endif; ?>
                <div class="info-pair"><span class="info-lbl">Org Verified</span>
                    <span class="badge-pill <?= $v['org_verified']?'badge-active':'badge-pending' ?>"><?= $v['org_verified']?'Yes':'No' ?></span>
                </div>
                <div style="border-top:1px solid var(--color-border);margin:16px 0;"></div>
                <span class="section-label">Owner / Contact Person</span>
                <?php else: ?>
                <span class="section-label">Applicant Information</span>
                <?php endif; ?>

                <div class="info-pair"><span class="info-lbl">Full Name</span><strong><?= e($v['user_name']) ?></strong></div>
                <div class="info-pair"><span class="info-lbl">Email</span><span><?= e($v['email']) ?></span></div>
                <div class="info-pair"><span class="info-lbl">Phone</span><span><?= e($v['phone'] ?: '—') ?></span></div>
                <div class="info-pair"><span class="info-lbl">Address</span><span style="font-size:.82rem;"><?= e($v['address'] ?: 'Not provided') ?></span></div>
                <div class="info-pair"><span class="info-lbl">Account Age</span><span style="font-size:.82rem;color:var(--color-muted);">Member since <?= date('M d, Y', strtotime($v['user_created'])) ?></span></div>

                <div style="border-top:1px solid var(--color-border);margin:16px 0;"></div>
                <span class="section-label">Submitted Document</span>
                <div class="info-pair"><span class="info-lbl">Document Type</span><strong><?= e($v['document_type'] ?: 'Not specified') ?></strong></div>
                <div class="info-pair"><span class="info-lbl">Request Type</span>
                    <span class="badge-pill badge-info"><?= ucfirst($v['type'] ?? 'user') ?> verification</span>
                </div>
                <div class="info-pair"><span class="info-lbl">Account Status</span>
                    <span class="badge-pill <?= $v['is_verified']?'badge-active':'badge-pending' ?>"><?= $v['is_verified']?'Verified':'Unverified' ?></span>
                </div>

                <?php if ($v['review_notes']): ?>
                <div style="margin-top:14px;background:rgba(220,38,38,.07);border:1px solid rgba(220,38,38,.15);border-radius:8px;padding:12px 14px;">
                    <div style="font-size:.72rem;font-weight:700;color:var(--color-danger);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">Admin Review Notes</div>
                    <div style="font-size:.855rem;"><?= e($v['review_notes']) ?></div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Right: document preview -->
            <div class="verif-doc">
                <span class="section-label">Document Preview</span>

                <?php if (!$docUrl): ?>
                <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:200px;background:var(--color-surface-2);border-radius:10px;color:var(--color-muted);">
                    <i class="fas fa-file-slash" style="font-size:2.5rem;opacity:.25;margin-bottom:10px;"></i>
                    <span style="font-size:.875rem;">No document uploaded</span>
                </div>

                <?php elseif ($isImg): ?>
                <div class="doc-frame">
                    <img src="<?= e($docUrl) ?>" alt="<?= e($v['document_type']) ?>"
                         onclick="openDocZoom('<?= e($docUrl) ?>')" title="Click to view full size">
                </div>
                <div style="display:flex;gap:8px;flex-wrap:wrap;">
                    <button class="btn-primary" onclick="openDocZoom('<?= e($docUrl) ?>')" style="font-size:.8rem;padding:7px 14px;">
                        <i class="fas fa-search-plus"></i> Full Size
                    </button>
                    <a href="<?= e($docUrl) ?>" download class="btn-secondary" style="font-size:.8rem;padding:7px 14px;">
                        <i class="fas fa-download"></i> Download
                    </a>
                </div>

                <?php elseif ($isPdf): ?>
                <div class="doc-frame">
                    <div class="pdf-icon">
                        <i class="fas fa-file-pdf" style="font-size:2.5rem;color:#dc2626;flex-shrink:0;"></i>
                        <div>
                            <div style="font-weight:700;margin-bottom:2px;">PDF Document</div>
                            <div style="font-size:.78rem;color:var(--color-muted);"><?= e($v['document_type']) ?></div>
                        </div>
                    </div>
                </div>
                <div style="display:flex;gap:8px;flex-wrap:wrap;">
                    <a href="<?= e($docUrl) ?>" target="_blank" class="btn-primary" style="font-size:.8rem;padding:7px 14px;">
                        <i class="fas fa-external-link-alt"></i> Open PDF
                    </a>
                    <a href="<?= e($docUrl) ?>" download class="btn-secondary" style="font-size:.8rem;padding:7px 14px;">
                        <i class="fas fa-download"></i> Download
                    </a>
                </div>

                <?php else: ?>
                <div class="doc-frame">
                    <div class="pdf-icon">
                        <i class="fas fa-file" style="font-size:2rem;color:var(--brand-primary);"></i>
                        <a href="<?= e($docUrl) ?>" target="_blank" style="color:var(--brand-primary);">Open document ↗</a>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Action bar -->
        <?php if ($v['status'] === 'pending'): ?>
        <div class="action-bar">
            <form method="POST" style="display:inline;">
                <?= csrf_field() ?>
                <input type="hidden" name="req_id" value="<?= $v['id'] ?>">
                <input type="hidden" name="action" value="approve">
                <button type="submit" class="btn-primary"
                        style="padding:10px 22px;"
                        onclick="return confirm('Approve verification for <?= e($v['user_name']) ?>?\nThis will mark their account as verified.')">
                    <i class="fas fa-check-circle"></i> Approve &amp; Verify Account
                </button>
            </form>
            <form method="POST" class="reject-row">
                <?= csrf_field() ?>
                <input type="hidden" name="req_id" value="<?= $v['id'] ?>">
                <input type="hidden" name="action" value="reject">
                <textarea name="review_notes" class="form-input" rows="2"
                          placeholder="Rejection reason (e.g. document blurry, wrong ID type, info mismatch)…"
                          style="min-width:220px;font-size:.84rem;padding:8px 12px;resize:none;"></textarea>
                <button type="submit" class="btn-danger" style="padding:10px 18px;white-space:nowrap;"
                        onclick="const ta=this.form.querySelector('textarea');if(!ta.value.trim()){alert('Please enter a rejection reason.');return false;}return confirm('Reject this request?')">
                    <i class="fas fa-times-circle"></i> Reject
                </button>
            </form>
        </div>
        <?php elseif ($v['status'] === 'approved'): ?>
        <div class="action-bar" style="background:rgba(5,150,105,.05);">
            <i class="fas fa-check-circle" style="color:var(--color-success);font-size:1.1rem;"></i>
            <span style="font-weight:600;color:var(--color-success);">Approved</span>
            <?php if ($v['review_notes']): ?>
            <span style="color:var(--color-muted);font-size:.82rem;">— <?= e($v['review_notes']) ?></span>
            <?php endif; ?>
        </div>
        <?php else: ?>
        <div class="action-bar" style="background:rgba(220,38,38,.05);">
            <i class="fas fa-times-circle" style="color:var(--color-danger);font-size:1.1rem;"></i>
            <span style="font-weight:600;color:var(--color-danger);">Rejected</span>
            <?php if ($v['review_notes']): ?>
            <span style="color:var(--color-muted);font-size:.82rem;">— <?= e($v['review_notes']) ?></span>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
</main>

<!-- Full-size document zoom modal -->
<div class="modal-overlay" id="docZoomModal" onclick="closeModal('docZoomModal')" style="align-items:center;justify-content:center;">
    <div style="position:relative;" onclick="event.stopPropagation()">
        <img id="docZoomImg" src="" alt="Document" style="max-width:92vw;max-height:90vh;border-radius:10px;display:block;box-shadow:0 30px 80px rgba(0,0,0,.7);">
        <button onclick="closeModal('docZoomModal')"
                style="position:absolute;top:-14px;right:-14px;width:34px;height:34px;border-radius:50%;background:var(--color-danger);color:white;border:none;cursor:pointer;font-size:1.1rem;font-weight:900;line-height:1;">×</button>
    </div>
</div>

<script src="/assets/js/global.js"></script>
<script src="/assets/js/dashboard.js"></script>
<script>
window._SESS = '<?= $_SESS_PARAM ?>';
function openDocZoom(url) {
    document.getElementById('docZoomImg').src = url;
    openModal('docZoomModal');
}
</script>
</body></html>
