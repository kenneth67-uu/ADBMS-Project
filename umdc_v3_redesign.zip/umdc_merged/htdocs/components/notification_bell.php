<?php
// =============================================================
// UMDC – Notification Bell Component
// =============================================================
// Drop this include into any dashboard header:
//
//   <?php require_once __DIR__ . '/../components/notification_bell.php'; ?>
//
// Requires: $pdo and session already started.
// The JS (notification_bell.js) must also be included.
// =============================================================
defined('UMDC_APP') or define('UMDC_APP', true);
require_once __DIR__ . '/../Config/notifications.php';

$_nb_userId  = currentUserId();
$_nb_unread  = $_nb_userId ? Notifier::getUnreadCount($pdo, $_nb_userId) : 0;
$_nb_sess    = isset($_SESS_PARAM) ? htmlspecialchars($_SESS_PARAM) : '';
?>
<div class="notif-bell-wrap" id="notifBellWrap">
    <button class="notif-bell-btn" id="notifBellBtn" aria-label="Notifications" aria-expanded="false">
        <i class="fas fa-bell"></i>
        <span class="notif-badge <?= $_nb_unread > 0 ? 'visible' : '' ?>"
              id="notifBadge"><?= $_nb_unread > 0 ? min($_nb_unread, 99) . ($_nb_unread > 99 ? '+' : '') : '' ?></span>
    </button>

    <div class="notif-dropdown" id="notifDropdown" role="dialog" aria-label="Notifications panel">
        <div class="notif-header">
            <span class="notif-title">Notifications</span>
            <button class="notif-mark-all" id="notifMarkAll" title="Mark all as read">
                <i class="fas fa-check-double"></i> Mark all read
            </button>
        </div>

        <div class="notif-list" id="notifList">
            <div class="notif-loading" id="notifLoading">
                <i class="fas fa-spinner fa-spin"></i>
            </div>
        </div>

        <div class="notif-footer" id="notifFooter" style="display:none;">
            <button class="notif-load-more" id="notifLoadMore">Load more</button>
        </div>
    </div>
</div>
