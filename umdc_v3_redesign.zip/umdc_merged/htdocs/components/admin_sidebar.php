<?php
defined('UMDC_APP') or define('UMDC_APP', true);
$_admin_name     = e($_SESSION['user_name'] ?? 'Admin');
$_admin_initials = strtoupper(substr($_SESSION['user_name'] ?? 'A', 0, 2));
$_SESS           = isset($_SESS_PARAM) ? $_SESS_PARAM : '?_sess=UMDC_ADMIN';
$_pending_approvals = (int)$pdo->query("SELECT COUNT(*) FROM approvals WHERE status='pending'")->fetchColumn();
$_open_flags        = (int)$pdo->query("SELECT COUNT(*) FROM fraud_flags WHERE status='open'")->fetchColumn();
$_pending_verif     = (int)$pdo->query("SELECT COUNT(*) FROM verification_requests WHERE status='pending'")->fetchColumn();
$_current = basename($_SERVER['PHP_SELF']);
function _admin_active(string $file): string { global $_current; return ($file === $_current) ? ' active' : ''; }
require_once __DIR__ . '/../Config/notifications.php';
$_nb_unread = Notifier::getUnreadCount($pdo, (int)($_SESSION['user_id'] ?? 0));
?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700;9..40,800&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="/assets/css/theme.css">
<link rel="stylesheet" href="/assets/css/notifications.css">
<meta name="csrf-token" content="<?= csrf_token() ?>">
<meta name="sess-name" content="UMDC_ADMIN">
</head>
<body class="admin-theme">

<!-- ── Mobile Header ─────────────────────────────────────── -->
<header class="admin-mobile-header" id="adminMobileHeader">
    <div class="admin-logo-icon"><i class="fas fa-shield-halved"></i></div>
    <div class="admin-logo-title">UMDC Admin</div>
    <div class="admin-mobile-right">
        <?php require_once __DIR__ . '/../components/notification_bell.php'; ?>
        <button class="admin-logout-btn" data-logout title="Sign out" style="background:rgba(248,113,113,.1);border:1px solid rgba(248,113,113,.2);border-radius:var(--radius-sm);padding:7px 9px;">
            <i class="fas fa-sign-out-alt" style="color:var(--danger);"></i>
        </button>
    </div>
</header>

<!-- ── Sidebar ───────────────────────────────────────────── -->
<aside class="admin-sidebar" id="adminSidebar">
    <div class="admin-sidebar-logo">
        <div class="admin-logo-icon"><i class="fas fa-shield-halved"></i></div>
        <div class="admin-logo-text">
            <div class="admin-logo-title">UMDC</div>
            <div class="admin-logo-sub">Admin Panel</div>
        </div>
    </div>

    <nav class="admin-nav">
        <span class="admin-nav-label">Overview</span>
        <a href="/dashboard/admin.php<?= $_SESS ?>" class="admin-nav-link<?= _admin_active('admin.php') ?>">
            <i class="fas fa-chart-pie"></i> Dashboard
        </a>

        <span class="admin-nav-label">Management</span>
        <a href="/admin/approvals.php<?= $_SESS ?>" class="admin-nav-link<?= _admin_active('approvals.php') ?>">
            <i class="fas fa-check-double"></i> Approvals
            <?php if ($_pending_approvals > 0): ?>
            <span class="admin-nav-badge"><?= $_pending_approvals ?></span>
            <?php endif; ?>
        </a>
        <a href="/admin/review_campaigns.php<?= $_SESS ?>" class="admin-nav-link<?= _admin_active('review_campaigns.php') ?>">
            <i class="fas fa-bullhorn"></i> Campaigns
        </a>
        <a href="/admin/organizations.php<?= $_SESS ?>" class="admin-nav-link<?= _admin_active('organizations.php') ?>">
            <i class="fas fa-building"></i> Organizations
        </a>
        <a href="/admin/users.php<?= $_SESS ?>" class="admin-nav-link<?= _admin_active('users.php') ?>">
            <i class="fas fa-users"></i> Users
        </a>
        <a href="/admin/donations.php<?= $_SESS ?>" class="admin-nav-link<?= _admin_active('donations.php') ?>">
            <i class="fas fa-heart"></i> Donations
        </a>
        <a href="/admin/fraud.php<?= $_SESS ?>" class="admin-nav-link<?= _admin_active('fraud.php') ?>">
            <i class="fas fa-triangle-exclamation"></i> Fraud Flags
            <?php if ($_open_flags > 0): ?>
            <span class="admin-nav-badge"><?= $_open_flags ?></span>
            <?php endif; ?>
        </a>
        <a href="/verification/verify_user.php<?= $_SESS ?>" class="admin-nav-link<?= _admin_active('verify_user.php') ?>">
            <i class="fas fa-id-card"></i> Verifications
            <?php if ($_pending_verif > 0): ?>
            <span class="admin-nav-badge warning"><?= $_pending_verif ?></span>
            <?php endif; ?>
        </a>
        <a href="/admin/couriers.php<?= $_SESS ?>" class="admin-nav-link<?= _admin_active('couriers.php') ?>">
            <i class="fas fa-truck"></i> Couriers
        </a>

        <span class="admin-nav-label">Reports & System</span>
        <a href="/admin/analytics.php<?= $_SESS ?>" class="admin-nav-link<?= _admin_active('analytics.php') ?>">
            <i class="fas fa-chart-line"></i> Analytics
        </a>
        <a href="/admin/reports.php<?= $_SESS ?>" class="admin-nav-link<?= _admin_active('reports.php') ?>">
            <i class="fas fa-file-chart-column"></i> Reports
        </a>
        <a href="/admin/system.php<?= $_SESS ?>" class="admin-nav-link<?= _admin_active('system.php') ?>">
            <i class="fas fa-sliders"></i> System
        </a>
        <a href="/admin/notification_settings.php<?= $_SESS ?>" class="admin-nav-link<?= _admin_active('notification_settings.php') ?>">
            <i class="fas fa-bell-cog"></i> Notifications
            <?php if ($_nb_unread > 0): ?>
            <span class="admin-nav-badge info"><?= min($_nb_unread,99) ?></span>
            <?php endif; ?>
        </a>
    </nav>

    <div class="admin-sidebar-footer">
        <div class="admin-user-card">
            <div class="admin-avatar"><?= $_admin_initials ?></div>
            <div>
                <div class="admin-user-name"><?= $_admin_name ?></div>
                <div class="admin-user-role">Administrator</div>
            </div>
            <button class="admin-logout-btn" data-logout title="Sign out">
                <i class="fas fa-sign-out-alt"></i>
            </button>
        </div>
    </div>
</aside>

<!-- ── Mobile Bottom Nav ──────────────────────────────────── -->
<nav class="admin-bottom-nav" id="adminBottomNav">
    <div class="admin-bnav-inner">
        <a href="/dashboard/admin.php<?= $_SESS ?>" class="admin-bnav-item"><i class="fas fa-chart-pie"></i><span>Home</span></a>
        <a href="/admin/approvals.php<?= $_SESS ?>" class="admin-bnav-item"><i class="fas fa-check-double"></i><span>Approvals</span></a>
        <a href="/admin/users.php<?= $_SESS ?>" class="admin-bnav-item"><i class="fas fa-users"></i><span>Users</span></a>
        <a href="/admin/fraud.php<?= $_SESS ?>" class="admin-bnav-item"><i class="fas fa-flag"></i><span>Fraud</span></a>
        <a href="/admin/analytics.php<?= $_SESS ?>" class="admin-bnav-item"><i class="fas fa-chart-bar"></i><span>Stats</span></a>
    </div>
</nav>

<script src="/assets/js/global.js"></script>
<script src="/assets/js/dashboard.js"></script>
<script src="/assets/js/notifications.js"></script>
<script>
// Highlight active bottom nav item
document.addEventListener('DOMContentLoaded', () => {
    const page = location.pathname.split('/').pop().split('?')[0];
    document.querySelectorAll('.admin-bnav-item').forEach(a => {
        if (a.href && a.href.includes(page)) {
            a.classList.add('active');
        }
    });
});
</script>
