<?php
// =============================================================
// UMDC — API Keys & Gateway Configuration
// KEEP THIS FILE OUT OF VERSION CONTROL
// Add to .gitignore: htdocs/Config/keys.php
// =============================================================

// ── PayMongo ─────────────────────────────────────────────────
define('PAYMONGO_SECRET_KEY',  'sk_live_EHLewR8fjk25DmLiuvueF5DJ');
define('PAYMONGO_PUBLIC_KEY',  'pk_live_5CCs5XaeheK5LTQnoAuYwy8D');
define('PAYMONGO_WEBHOOK_SIG', 'whsk_tr2SAmAwhjsPSJudtet7Yqob');

// ── Semaphore SMS ─────────────────────────────────────────────
define('SEMAPHORE_API_KEY',    '81f2342e1bc33cdbe797ee01659a91f4');
define('SEMAPHORE_SENDER',     'UMDC');

// ── App ───────────────────────────────────────────────────────
define('APP_URL',   'http://localhost/umdc');
define('APP_ENV',   'production'); // development | production
