/* =============================================================
   UMDC – User Dashboard JS
   ============================================================= */
'use strict';

let currentSection = null;

function loadSection(section) {
    currentSection = section;

    // Update active sidebar link
    document.querySelectorAll('.sidebar-link').forEach(l => l.classList.remove('active'));
    const activeLink = Array.from(document.querySelectorAll('.sidebar-link'))
        .find(l => l.textContent.trim().toLowerCase().includes(section.replace('-', ' ')));
    if (activeLink) activeLink.classList.add('active');

    const content = document.getElementById('dynamic-content');
    if (!content) return;
    content.innerHTML = loadingHTML();

    switch (section) {
        case 'campaigns':    loadCampaigns(content); break;
        case 'my-donations': loadMyDonations(content); break;
        case 'leaderboard':  loadLeaderboard(content); break;
        case 'transparency': loadTransparency(content); break;
        case 'profile':      loadProfile(content); break;
        default:             loadCampaigns(content);
    }
}

// ── Campaigns ──────────────────────────────────────────────────
function loadCampaigns(el) {
    apiFetch('../api/campaigns.php')
        .then(data => {
            if (!data.success) throw new Error(data.message);

            if (!data.campaigns.length) {
                el.innerHTML = emptyHTML('fa-hand-holding-heart', 'No active campaigns', 'Check back soon!');
                return;
            }

            const categoryIcons = { education:'📚', health:'🏥', disaster:'🆘', environment:'🌿', community:'🤝', food:'🍱' };
            const grid = document.createElement('div');
            grid.style.cssText = 'display:grid;grid-template-columns:repeat(auto-fill,minmax(290px,1fr));gap:20px;';

            data.campaigns.forEach(c => {
                const icon = categoryIcons[c.category?.toLowerCase()] || '🤝';
                const pct  = c.target_amount > 0 ? Math.min(100, (c.current_amount / c.target_amount) * 100) : 0;
                const card = document.createElement('div');
                card.className = 'dash-campaign-card';
                const thumbContent = c.campaign_image
                    ? `<img src="${escapeHtml(c.campaign_image)}" alt="${escapeHtml(c.title)}" style="width:100%;height:100%;object-fit:cover;position:absolute;inset:0;">`
                    : icon;
                card.innerHTML = `
                    <div class="thumb" style="position:relative;">${thumbContent}</div>
                    <div class="c-body">
                        <div class="c-cat">${escapeHtml(c.category || 'General')} · ${escapeHtml(c.org_name || '')}</div>
                        <div class="c-title">${escapeHtml(c.title)}</div>
                        <div class="c-desc">${escapeHtml(c.description || '')}</div>
                        <div class="c-amounts">
                            <span class="c-raised">${formatCurrency(c.current_amount)}</span>
                            <span class="c-goal">Goal: ${formatCurrency(c.target_amount)}</span>
                        </div>
                        ${progressBar(c.current_amount, c.target_amount)}
                        <div style="font-size:.72rem;color:var(--color-muted);margin-top:6px;">
                            ${pct.toFixed(0)}% funded · ${c.donor_count} donor${c.donor_count !== 1 ? 's' : ''}
                        </div>
                    </div>
                    <div class="c-actions">
                        <button class="btn-primary" style="font-size:.8rem;padding:8px 14px;flex:1;justify-content:center;"
                                onclick="DonationForm.open(${c.campaign_id}, '${escapeHtml(c.title).replace(/'/g, "\\'")}')">
                            <i class="fas fa-heart"></i> Donate
                        </button>
                    </div>
                `;
                grid.appendChild(card);
            });

            el.innerHTML = `
                <div class="card-header" style="padding:0 0 16px;">
                    <h5 style="margin:0;">Active Campaigns</h5>
                    <span style="font-size:.82rem;color:var(--color-muted);">${data.campaigns.length} campaign${data.campaigns.length !== 1 ? 's' : ''}</span>
                </div>`;
            el.appendChild(grid);
        })
        .catch(err => {
            el.innerHTML = emptyHTML('fa-exclamation-circle', 'Failed to load campaigns', err.message);
        });
}

// ── My Donations ───────────────────────────────────────────────
window.loadMyDonations = function (el) {
    if (!el) el = document.getElementById('dynamic-content');
    if (!el) return;
    el.innerHTML = loadingHTML('Loading your donations...');

    apiFetch('../api/my_donation.php')
        .then(data => {
            if (!data.success) throw new Error(data.message);

            if (!data.donations.length) {
                el.innerHTML = emptyHTML('fa-receipt', 'No donations yet', 'Browse campaigns and make your first donation!');
                return;
            }

            const typeIcons = { cash:'fa-peso-sign', item:'fa-box', service:'fa-screwdriver-wrench' };
            let rows = data.donations.map(d => `
                <tr>
                    <td><i class="fas ${typeIcons[d.donation_type] || 'fa-gift'}" style="margin-right:6px;color:var(--brand-primary)"></i>${d.donation_type}</td>
                    <td>${escapeHtml(d.campaign_title)}</td>
                    <td class="amount-mono">${d.amount ? formatCurrency(d.amount) : '—'}</td>
                    <td><span class="badge-pill badge-${d.status}">${d.status}</span></td>
                    <td>${formatDate(d.created_at)}</td>
                    <td>
                        ${d.status === 'pending' && d.donation_type === 'cash'
                            ? `<a href="../donations/cash.php?id=${d.donation_id}" class="btn-primary" style="font-size:.75rem;padding:5px 12px;">Complete</a>`
                            : ''}
                        ${d.receipt_number
                            ? `<button class="btn-secondary" style="font-size:.75rem;padding:5px 12px;" onclick="window.open('../receipts/view.php?id=${d.donation_id}','_blank')"><i class="fas fa-receipt"></i> Receipt</button>`
                            : ''}
                        ${d.public_hash
                            ? `<button class="btn-secondary" style="font-size:.75rem;padding:5px 12px;" onclick="window.open('../transactions/verify.php?hash=${escapeHtml(d.public_hash)}','_blank')"><i class="fas fa-link"></i> Verify</button>`
                            : ''}
                    </td>
                </tr>`).join('');

            el.innerHTML = `
                <div class="card">
                    <div class="card-header">
                        <h5>My Donations</h5>
                        <span style="font-size:.82rem;color:var(--color-muted);">${data.donations.length} record${data.donations.length !== 1 ? 's' : ''}</span>
                    </div>
                    <div style="overflow-x:auto;">
                        <table class="table-custom">
                            <thead><tr>
                                <th>Type</th><th>Campaign</th><th>Amount</th>
                                <th>Status</th><th>Date</th><th>Actions</th>
                            </tr></thead>
                            <tbody>${rows}</tbody>
                        </table>
                    </div>
                </div>`;
        })
        .catch(err => {
            el.innerHTML = emptyHTML('fa-exclamation-circle', 'Failed to load', err.message);
        });
};

// ── Leaderboard ────────────────────────────────────────────────
function loadLeaderboard(el) {
    apiFetch('../analytics/leaderboard.php')
        .then(data => {
            if (!data.success) throw new Error(data.message);
            const rankClass = ['gold','silver','bronze'];
            let items = (data.leaderboard || []).map((u, i) => `
                <div class="leaderboard-item">
                    <div class="rank ${rankClass[i] || ''}">${i < 3 ? ['🥇','🥈','🥉'][i] : `#${i+1}`}</div>
                    <div class="lb-info">
                        <div class="lb-name">${escapeHtml(u.donor_name)}</div>
                        <div class="lb-sub">${u.donation_count} donation${u.donation_count !== 1 ? 's' : ''}</div>
                    </div>
                    <div class="lb-amount">${formatCurrency(u.total_donated)}</div>
                </div>`).join('');

            el.innerHTML = `
                <div class="card">
                    <div class="card-header"><h5>🏆 Top Donors</h5></div>
                    ${items || emptyHTML('fa-trophy', 'No donors yet')}
                </div>`;
        })
        .catch(() => {
            el.innerHTML = emptyHTML('fa-exclamation-circle', 'Failed to load leaderboard');
        });
}

// ── Transparency ────────────────────────────────────────────────
function loadTransparency(el) {
    apiFetch('../api/transparency.php')
        .then(data => {
            if (!data.success) throw new Error(data.message);
            let rows = (data.records || []).map(r => `
                <tr>
                    <td class="amount-mono" style="font-size:.75rem;">${escapeHtml(r.public_hash || '—')}</td>
                    <td>${escapeHtml(r.campaign_title)}</td>
                    <td class="amount-mono">${formatCurrency(r.amount)}</td>
                    <td>${formatDate(r.created_at)}</td>
                </tr>`).join('');

            el.innerHTML = `
                <div class="card">
                    <div class="card-header">
                        <h5><i class="fas fa-shield-alt" style="color:var(--color-success)"></i> Public Transaction Ledger</h5>
                    </div>
                    <div class="alert alert-info" style="margin:16px 20px 0;">
                        <i class="fas fa-info-circle"></i>
                        <span>All completed donations are hashed and recorded publicly for full transparency.</span>
                    </div>
                    <div style="overflow-x:auto;">
                        <table class="table-custom">
                            <thead><tr><th>Hash</th><th>Campaign</th><th>Amount</th><th>Date</th></tr></thead>
                            <tbody>${rows || '<tr><td colspan="4" style="text-align:center;color:var(--color-muted);padding:30px;">No records yet</td></tr>'}</tbody>
                        </table>
                    </div>
                </div>`;
        })
        .catch(() => {
            el.innerHTML = emptyHTML('fa-exclamation-circle', 'Failed to load transparency data');
        });
}

// ── Profile ────────────────────────────────────────────────────
function loadProfile(el) {
    apiFetch('../api/profile.php')
        .then(data => {
            if (!data.success) throw new Error(data.message);
            const u    = data.user;
            const s    = data.stats;
            const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';

            // Avatar
            const initials  = ((u.first_name?.[0]||'') + (u.last_name?.[0]||'')).toUpperCase();
            const avatarHtml = u.profile_photo
                ? `<img src="${escapeHtml(u.profile_photo)}" alt="Avatar"
                       style="width:90px;height:90px;border-radius:50%;object-fit:cover;border:3px solid var(--brand-primary);display:block;margin:0 auto;">`
                : `<div style="width:90px;height:90px;border-radius:50%;background:var(--brand-gradient);display:flex;align-items:center;justify-content:center;font-size:2rem;font-weight:800;color:#fff;margin:0 auto;">${initials}</div>`;

            // Verification badge
            const verifiedBadge = u.is_verified
                ? `<span style="display:inline-flex;align-items:center;gap:4px;padding:3px 9px;background:rgba(5,150,105,.1);color:var(--color-success);border-radius:20px;font-size:.72rem;font-weight:700;"><i class="fas fa-circle-check"></i> Verified</span>`
                : `<span style="display:inline-flex;align-items:center;gap:4px;padding:3px 9px;background:rgba(217,119,6,.08);color:var(--color-warning);border-radius:20px;font-size:.72rem;font-weight:600;"><i class="fas fa-clock"></i> Unverified</span>`;

            // Social link display helper
            const socialLink = (val, icon, prefix='') => val
                ? `<a href="${prefix}${escapeHtml(val)}" target="_blank" rel="noopener"
                      style="display:inline-flex;align-items:center;gap:5px;color:var(--brand-primary);font-size:.8rem;text-decoration:none;"
                      ><i class="fab ${icon}"></i> ${escapeHtml(val)}</a>`
                : `<span style="color:var(--color-muted);font-size:.8rem;">—</span>`;

            el.innerHTML = `
            <!-- ── Profile tabs ── -->
            <div style="display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap;">
                <button class="profile-tab active" data-tab="personal" onclick="switchProfileTab('personal',this)">
                    <i class="fas fa-user"></i> Personal Info
                </button>
                <button class="profile-tab" data-tab="social" onclick="switchProfileTab('social',this)">
                    <i class="fas fa-share-nodes"></i> Social Links
                </button>
                <button class="profile-tab" data-tab="security" onclick="switchProfileTab('security',this)">
                    <i class="fas fa-lock"></i> Password
                </button>
            </div>

            <!-- ── Tab: Personal Info ── -->
            <div id="tab-personal" class="profile-tab-content">
                <div class="two-col">

                    <!-- Left: form -->
                    <div class="card">
                        <div class="card-header">
                            <h5><i class="fas fa-user-edit" style="color:var(--brand-primary);margin-right:8px;"></i>Edit Profile</h5>
                        </div>
                        <div class="card-body">
                            <form id="profileForm" novalidate>
                                <input type="hidden" name="csrf_token" value="${escapeHtml(csrf)}">

                                <!-- Name row -->
                                <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
                                    <div class="form-group">
                                        <label class="form-label">First Name <span style="color:var(--color-danger);">*</span></label>
                                        <input class="form-input" type="text" name="first_name" value="${escapeHtml(u.first_name||'')}" required maxlength="100" placeholder="Juan">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Last Name <span style="color:var(--color-danger);">*</span></label>
                                        <input class="form-input" type="text" name="last_name" value="${escapeHtml(u.last_name||'')}" required maxlength="100" placeholder="DelaCruz">
                                    </div>
                                </div>

                                <!-- Email -->
                                <div class="form-group">
                                    <label class="form-label">Email Address <span style="color:var(--color-danger);">*</span></label>
                                    <input class="form-input" type="email" name="email" value="${escapeHtml(u.email||'')}" required placeholder="juan@email.com">
                                </div>

                                <!-- Phone -->
                                <div class="form-group">
                                    <label class="form-label">Phone Number</label>
                                    <input class="form-input" type="tel" name="phone" value="${escapeHtml(u.phone||'')}" placeholder="+63 9XX XXX XXXX" maxlength="50">
                                    <div class="form-hint">Used for SMS notifications (urgent alerts only)</div>
                                </div>

                                <!-- DOB + Gender row -->
                                <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
                                    <div class="form-group">
                                        <label class="form-label">Date of Birth</label>
                                        <input class="form-input" type="date" name="date_of_birth"
                                               value="${escapeHtml(u.date_of_birth||'')}"
                                               max="${new Date().toISOString().split('T')[0]}">
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">Gender</label>
                                        <select class="form-input" name="gender">
                                            <option value="" ${!u.gender?'selected':''}>Prefer not to say</option>
                                            <option value="male"   ${u.gender==='male'?'selected':''}>Male</option>
                                            <option value="female" ${u.gender==='female'?'selected':''}>Female</option>
                                            <option value="prefer_not_to_say" ${u.gender==='prefer_not_to_say'?'selected':''}>Other / PNTS</option>
                                        </select>
                                    </div>
                                </div>

                                <!-- Address -->
                                <div class="form-group">
                                    <label class="form-label">Address</label>
                                    <textarea class="form-textarea" name="address" rows="2"
                                              placeholder="Street, Barangay, City, Province">${escapeHtml(u.address||'')}</textarea>
                                </div>

                                <!-- Bio -->
                                <div class="form-group">
                                    <label class="form-label">
                                        Bio
                                        <span style="color:var(--color-muted);font-weight:400;font-size:.78rem;"> — visible on leaderboard (max 500 chars)</span>
                                    </label>
                                    <textarea class="form-textarea" name="bio" rows="3"
                                              maxlength="500"
                                              placeholder="Tell the community a little about yourself…"
                                              oninput="document.getElementById('bioCount').textContent=this.value.length">${escapeHtml(u.bio||'')}</textarea>
                                    <div class="form-hint" style="text-align:right;">
                                        <span id="bioCount">${(u.bio||'').length}</span>/500
                                    </div>
                                </div>

                                <button type="submit" class="btn-primary" style="width:100%;justify-content:center;padding:11px;">
                                    <i class="fas fa-floppy-disk"></i> Save Changes
                                </button>
                            </form>
                        </div>
                    </div>

                    <!-- Right: photo + stats -->
                    <div>
                        <!-- Photo card -->
                        <div class="card" style="margin-bottom:16px;">
                            <div class="card-body" style="text-align:center;padding:24px 20px;">
                                <div style="margin-bottom:14px;">${avatarHtml}</div>
                                <div style="font-weight:700;font-size:1.05rem;margin-bottom:4px;">
                                    ${escapeHtml(u.first_name||'')} ${escapeHtml(u.last_name||'')}
                                </div>
                                <div style="color:var(--color-muted);font-size:.82rem;margin-bottom:10px;">${escapeHtml(u.email||'')}</div>
                                <div style="margin-bottom:16px;">${verifiedBadge}</div>
                                <input type="file" id="photoInput" accept="image/jpeg,image/png,image/webp" style="display:none;" onchange="uploadProfilePhoto(this)">
                                <button class="btn-secondary" onclick="document.getElementById('photoInput').click()" style="font-size:.82rem;padding:7px 16px;width:100%;">
                                    <i class="fas fa-camera"></i> Change Photo
                                </button>
                                <div id="photoUploadStatus" style="font-size:.75rem;color:var(--color-muted);margin-top:8px;"></div>
                                <div style="font-size:.7rem;color:var(--color-muted);margin-top:4px;">JPG, PNG or WebP · Max 3 MB</div>
                            </div>
                        </div>

                        <!-- Stats card -->
                        <div class="card">
                            <div class="card-header"><h5><i class="fas fa-chart-bar" style="color:var(--brand-primary);margin-right:8px;"></i>Account Statistics</h5></div>
                            <div class="card-body">
                                <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                                    <div style="background:var(--color-surface-2);border-radius:10px;padding:14px;text-align:center;">
                                        <div style="font-size:.65rem;color:var(--color-muted);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px;">Total Donated</div>
                                        <div style="font-size:1.2rem;font-weight:800;color:var(--color-success);font-family:var(--font-mono);">${formatCurrency(s.total_donated)}</div>
                                    </div>
                                    <div style="background:var(--color-surface-2);border-radius:10px;padding:14px;text-align:center;">
                                        <div style="font-size:.65rem;color:var(--color-muted);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px;">Donations</div>
                                        <div style="font-size:1.2rem;font-weight:800;color:var(--brand-primary);">${s.donation_count}</div>
                                    </div>
                                    <div style="background:var(--color-surface-2);border-radius:10px;padding:14px;text-align:center;">
                                        <div style="font-size:.65rem;color:var(--color-muted);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px;">Campaigns</div>
                                        <div style="font-size:1.2rem;font-weight:800;color:var(--brand-primary);">${s.campaigns_supported}</div>
                                    </div>
                                    <div style="background:var(--color-surface-2);border-radius:10px;padding:14px;text-align:center;">
                                        <div style="font-size:.65rem;color:var(--color-muted);text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px;">Member Since</div>
                                        <div style="font-size:.85rem;font-weight:700;">${formatDate(u.created_at)}</div>
                                    </div>
                                </div>
                                ${s.last_donation ? `
                                <div style="margin-top:10px;padding:10px 12px;background:var(--color-surface-2);border-radius:8px;font-size:.78rem;color:var(--color-muted);display:flex;align-items:center;gap:8px;">
                                    <i class="fas fa-clock" style="color:var(--brand-primary);"></i>
                                    Last donation: <strong style="color:var(--color-text);">${formatDate(s.last_donation)}</strong>
                                </div>` : ''}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ── Tab: Social Links ── -->
            <div id="tab-social" class="profile-tab-content" style="display:none;">
                <div class="two-col">
                    <div class="card">
                        <div class="card-header">
                            <h5><i class="fas fa-share-nodes" style="color:var(--brand-primary);margin-right:8px;"></i>Social & Contact Links</h5>
                        </div>
                        <div class="card-body">
                            <form id="socialForm" novalidate>
                                <input type="hidden" name="csrf_token" value="${escapeHtml(csrf)}">
                                <!-- carry over required personal fields silently -->
                                <input type="hidden" name="first_name" value="${escapeHtml(u.first_name||'')}">
                                <input type="hidden" name="last_name"  value="${escapeHtml(u.last_name||'')}">
                                <input type="hidden" name="email"      value="${escapeHtml(u.email||'')}">

                                <p style="font-size:.83rem;color:var(--color-muted);margin:0 0 18px;">
                                    Add your social profiles so the community can connect with you. All fields are optional.
                                </p>

                                <div class="form-group">
                                    <label class="form-label"><i class="fab fa-facebook" style="color:#1877f2;width:16px;"></i> Facebook</label>
                                    <input class="form-input" type="url" name="facebook"
                                           value="${escapeHtml(u.facebook||'')}"
                                           placeholder="https://facebook.com/yourpage">
                                </div>
                                <div class="form-group">
                                    <label class="form-label"><i class="fab fa-x-twitter" style="color:#000;width:16px;"></i> X / Twitter</label>
                                    <div style="position:relative;">
                                        <span style="position:absolute;left:11px;top:50%;transform:translateY(-50%);color:var(--color-muted);font-size:.9rem;">@</span>
                                        <input class="form-input" type="text" name="twitter"
                                               value="${escapeHtml(u.twitter||'')}"
                                               placeholder="yourhandle" style="padding-left:28px;" maxlength="50">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label"><i class="fab fa-instagram" style="color:#e1306c;width:16px;"></i> Instagram</label>
                                    <div style="position:relative;">
                                        <span style="position:absolute;left:11px;top:50%;transform:translateY(-50%);color:var(--color-muted);font-size:.9rem;">@</span>
                                        <input class="form-input" type="text" name="instagram"
                                               value="${escapeHtml(u.instagram||'')}"
                                               placeholder="yourhandle" style="padding-left:28px;" maxlength="50">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label"><i class="fab fa-linkedin" style="color:#0a66c2;width:16px;"></i> LinkedIn</label>
                                    <input class="form-input" type="url" name="linkedin"
                                           value="${escapeHtml(u.linkedin||'')}"
                                           placeholder="https://linkedin.com/in/yourprofile">
                                </div>
                                <div class="form-group">
                                    <label class="form-label"><i class="fas fa-globe" style="color:var(--brand-primary);width:16px;"></i> Personal Website</label>
                                    <input class="form-input" type="url" name="website"
                                           value="${escapeHtml(u.website||'')}"
                                           placeholder="https://yoursite.com">
                                </div>

                                <button type="submit" class="btn-primary" style="width:100%;justify-content:center;padding:11px;">
                                    <i class="fas fa-floppy-disk"></i> Save Social Links
                                </button>
                            </form>
                        </div>
                    </div>

                    <!-- Current links preview -->
                    <div class="card">
                        <div class="card-header"><h5>Current Links</h5></div>
                        <div class="card-body">
                            <div style="display:flex;flex-direction:column;gap:14px;">
                                <div>
                                    <div style="font-size:.72rem;color:var(--color-muted);text-transform:uppercase;letter-spacing:.4px;margin-bottom:4px;">Facebook</div>
                                    ${socialLink(u.facebook,'fa-facebook','') }
                                </div>
                                <div>
                                    <div style="font-size:.72rem;color:var(--color-muted);text-transform:uppercase;letter-spacing:.4px;margin-bottom:4px;">X / Twitter</div>
                                    ${u.twitter ? `<a href="https://x.com/${escapeHtml(u.twitter)}" target="_blank" rel="noopener" style="color:var(--brand-primary);font-size:.8rem;text-decoration:none;"><i class="fab fa-x-twitter"></i> @${escapeHtml(u.twitter)}</a>` : '<span style="color:var(--color-muted);font-size:.8rem;">—</span>'}
                                </div>
                                <div>
                                    <div style="font-size:.72rem;color:var(--color-muted);text-transform:uppercase;letter-spacing:.4px;margin-bottom:4px;">Instagram</div>
                                    ${u.instagram ? `<a href="https://instagram.com/${escapeHtml(u.instagram)}" target="_blank" rel="noopener" style="color:var(--brand-primary);font-size:.8rem;text-decoration:none;"><i class="fab fa-instagram"></i> @${escapeHtml(u.instagram)}</a>` : '<span style="color:var(--color-muted);font-size:.8rem;">—</span>'}
                                </div>
                                <div>
                                    <div style="font-size:.72rem;color:var(--color-muted);text-transform:uppercase;letter-spacing:.4px;margin-bottom:4px;">LinkedIn</div>
                                    ${socialLink(u.linkedin,'fa-linkedin','')}
                                </div>
                                <div>
                                    <div style="font-size:.72rem;color:var(--color-muted);text-transform:uppercase;letter-spacing:.4px;margin-bottom:4px;">Website</div>
                                    ${u.website ? `<a href="${escapeHtml(u.website)}" target="_blank" rel="noopener" style="color:var(--brand-primary);font-size:.8rem;text-decoration:none;"><i class="fas fa-globe"></i> ${escapeHtml(u.website)}</a>` : '<span style="color:var(--color-muted);font-size:.8rem;">—</span>'}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ── Tab: Password ── -->
            <div id="tab-security" class="profile-tab-content" style="display:none;">
                <div style="max-width:480px;">
                    <div class="card">
                        <div class="card-header">
                            <h5><i class="fas fa-lock" style="color:var(--brand-primary);margin-right:8px;"></i>Change Password</h5>
                        </div>
                        <div class="card-body">
                            <form id="passwordForm" novalidate>
                                <input type="hidden" name="csrf_token" value="${escapeHtml(csrf)}">
                                <div class="form-group">
                                    <label class="form-label">Current Password <span style="color:var(--color-danger);">*</span></label>
                                    <input class="form-input" type="password" name="current_password" required autocomplete="current-password" placeholder="Your current password">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">New Password <span style="color:var(--color-danger);">*</span></label>
                                    <input class="form-input" type="password" name="new_password" required minlength="8" autocomplete="new-password" placeholder="At least 8 characters" oninput="checkPasswordStrength(this.value)">
                                    <div id="pwStrengthBar" style="margin-top:6px;height:4px;border-radius:4px;background:var(--color-border);overflow:hidden;"><div id="pwStrengthFill" style="height:100%;width:0;border-radius:4px;transition:width .3s,background .3s;"></div></div>
                                    <div id="pwStrengthLabel" class="form-hint" style="margin-top:3px;"></div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Confirm New Password <span style="color:var(--color-danger);">*</span></label>
                                    <input class="form-input" type="password" name="confirm_password" required autocomplete="new-password" placeholder="Repeat your new password">
                                </div>
                                <button type="submit" class="btn-primary" style="width:100%;justify-content:center;padding:11px;">
                                    <i class="fas fa-key"></i> Update Password
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>`;

            // ── Wire forms ──────────────────────────────────────
            // Personal form
            document.getElementById('profileForm').addEventListener('submit', async function(e) {
                e.preventDefault();
                const btn = this.querySelector('button[type="submit"]');
                btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving…';
                try {
                    const r = await apiFetch('../api/update_profile.php', { method:'POST', body:new FormData(this) });
                    if (r.success) { showToast('Profile updated!', 'success'); loadProfile(el); }
                    else showToast(r.message || 'Update failed', 'error');
                } catch { showToast('Network error', 'error'); }
                finally { btn.disabled = false; btn.innerHTML = '<i class="fas fa-floppy-disk"></i> Save Changes'; }
            });

            // Social form
            document.getElementById('socialForm').addEventListener('submit', async function(e) {
                e.preventDefault();
                const btn = this.querySelector('button[type="submit"]');
                btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving…';
                try {
                    const r = await apiFetch('../api/update_profile.php', { method:'POST', body:new FormData(this) });
                    if (r.success) { showToast('Social links updated!', 'success'); loadProfile(el); }
                    else showToast(r.message || 'Update failed', 'error');
                } catch { showToast('Network error', 'error'); }
                finally { btn.disabled = false; btn.innerHTML = '<i class="fas fa-floppy-disk"></i> Save Social Links'; }
            });

            // Password form
            document.getElementById('passwordForm').addEventListener('submit', async function(e) {
                e.preventDefault();
                const np = this.querySelector('[name="new_password"]').value;
                const cp = this.querySelector('[name="confirm_password"]').value;
                if (np !== cp) { showToast('Passwords do not match', 'error'); return; }
                if (np.length < 8) { showToast('Password must be at least 8 characters', 'error'); return; }
                const btn = this.querySelector('button[type="submit"]');
                btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Updating…';
                try {
                    const fd = new FormData(this);
                    const r  = await apiFetch('../api/change_password.php', { method:'POST', body:fd });
                    if (r.success) { showToast('Password changed!', 'success'); this.reset(); }
                    else showToast(r.message || 'Failed to change password', 'error');
                } catch { showToast('Network error', 'error'); }
                finally { btn.disabled = false; btn.innerHTML = '<i class="fas fa-key"></i> Update Password'; }
            });
        })
        .catch(() => { el.innerHTML = emptyHTML('fa-exclamation-circle', 'Failed to load profile'); });
}

// ── Profile tab switcher ────────────────────────────────────────
function switchProfileTab(tab, btn) {
    document.querySelectorAll('.profile-tab').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.profile-tab-content').forEach(d => d.style.display = 'none');
    btn.classList.add('active');
    document.getElementById('tab-' + tab).style.display = '';
}

// ── Password strength meter ─────────────────────────────────────
function checkPasswordStrength(val) {
    const fill  = document.getElementById('pwStrengthFill');
    const label = document.getElementById('pwStrengthLabel');
    if (!fill) return;
    let score = 0;
    if (val.length >= 8)  score++;
    if (val.length >= 12) score++;
    if (/[A-Z]/.test(val)) score++;
    if (/[0-9]/.test(val)) score++;
    if (/[^A-Za-z0-9]/.test(val)) score++;
    const levels = [
        { w:'0%',   c:'transparent', t:'' },
        { w:'20%',  c:'#ef4444',     t:'Very weak' },
        { w:'40%',  c:'#f97316',     t:'Weak' },
        { w:'60%',  c:'#eab308',     t:'Fair' },
        { w:'80%',  c:'#22c55e',     t:'Strong' },
        { w:'100%', c:'#059669',     t:'Very strong' },
    ];
    const l = levels[Math.min(score, 5)];
    fill.style.width      = l.w;
    fill.style.background = l.c;
    label.textContent     = l.t;
    label.style.color     = l.c;
}

// ── Upload profile photo ────────────────────────────────────────
async function uploadProfilePhoto(input) {
    const file   = input.files[0];
    const status = document.getElementById('photoUploadStatus');
    if (!file) return;
    if (file.size > 3 * 1024 * 1024) { showToast('Photo must be under 3MB', 'error'); return; }

    status.textContent = 'Uploading…';
    const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
    const fd   = new FormData();
    fd.append('photo', file);
    fd.append('csrf_token', csrf);

    try {
        const sessName = (window._SESS||'').replace('?_sess=','');
        const url = '../api/upload_photo.php' + (sessName ? '?_sess='+sessName : '');
        const res  = await fetch(url, { method:'POST', body:fd });
        const data = await res.json();
        if (data.success) {
            showToast('Photo updated!');
            status.textContent = '✓ Saved';
            status.style.color = 'var(--color-success)';
            // Reload profile section to show new photo
            setTimeout(() => loadProfile(document.getElementById('dynamic-content')), 800);
        } else {
            showToast(data.message || 'Upload failed', 'error');
            status.textContent = '';
        }
    } catch { showToast('Network error', 'error'); status.textContent = ''; }
    input.value = '';
}
