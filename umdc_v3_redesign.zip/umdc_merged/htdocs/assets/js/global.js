/* =============================================================
   UMDC – Global JS Utilities
   ============================================================= */
'use strict';

// ── Toast Notifications ────────────────────────────────────────
(function () {
    const container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);

    window.showToast = function (message, type = 'success', duration = 4000) {
        const icons = { success: 'fa-check-circle', error: 'fa-times-circle', warning: 'fa-exclamation-triangle', info: 'fa-info-circle' };
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `<i class="fas ${icons[type] || icons.success}" style="color:var(--color-${type === 'error' ? 'danger' : type === 'warning' ? 'warning' : 'success'})"></i><span>${escapeHtml(message)}</span>`;
        container.appendChild(toast);
        setTimeout(() => {
            toast.style.animation = 'toastOut .3s ease forwards';
            toast.addEventListener('animationend', () => toast.remove());
        }, duration);
    };
})();

// ── Escape HTML ────────────────────────────────────────────────
window.escapeHtml = function (str) {
    if (str == null) return '';
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
};

// ── Format Currency ────────────────────────────────────────────
window.formatCurrency = function (amount, currency = '₱') {
    const num = parseFloat(amount) || 0;
    return currency + num.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
};

// ── Format Date ────────────────────────────────────────────────
window.formatDate = function (dateStr) {
    if (!dateStr) return '—';
    try {
        return new Date(dateStr).toLocaleDateString('en-PH', { year: 'numeric', month: 'short', day: 'numeric' });
    } catch { return dateStr; }
};

// ── Modal Helpers ──────────────────────────────────────────────
window.openModal = function (id) {
    const el = document.getElementById(id);
    if (el) { el.classList.add('active'); document.body.style.overflow = 'hidden'; }
};
window.closeModal = function (id) {
    const el = document.getElementById(id);
    if (el) { el.classList.remove('active'); document.body.style.overflow = ''; }
};

// Close modal on overlay click
document.addEventListener('click', function (e) {
    if (e.target.classList.contains('modal-overlay')) {
        e.target.classList.remove('active');
        document.body.style.overflow = '';
    }
});

// Close modal on ESC
document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.active').forEach(m => {
            m.classList.remove('active');
            document.body.style.overflow = '';
        });
    }
});

// ── Sidebar Toggle (Mobile) ────────────────────────────────────
window.toggleSidebar = function () {
    const sb = document.querySelector('.sidebar');
    if (sb) sb.classList.toggle('open');
};

document.addEventListener('click', function (e) {
    const sb = document.querySelector('.sidebar');
    const toggle = document.querySelector('.mobile-toggle');
    if (sb && sb.classList.contains('open') && !sb.contains(e.target) && e.target !== toggle) {
        sb.classList.remove('open');
    }
});

// ── CSRF helper for fetch ──────────────────────────────────────
window.csrfFetch = function (url, options = {}) {
    const csrfMeta = document.querySelector('meta[name="csrf-token"]');
    if (csrfMeta) {
        options.headers = options.headers || {};
        options.headers['X-CSRF-Token'] = csrfMeta.content;
    }
    return fetch(url, options);
};

// ── Confirm Dialog ─────────────────────────────────────────────
window.confirmAction = function (message, callback) {
    if (window.confirm(message)) callback();
};

// ── Progress Bar Renderer ──────────────────────────────────────
window.progressBar = function (current, target) {
    const pct = target > 0 ? Math.min(100, (current / target) * 100) : 0;
    return `<div class="progress-wrap"><div class="progress-fill" style="width:${pct.toFixed(1)}%"></div></div>`;
};

// ── Loading Placeholder ────────────────────────────────────────
window.loadingHTML = function (msg = 'Loading...') {
    return `<div class="loading-state"><div class="spinner"></div><span>${escapeHtml(msg)}</span></div>`;
};

// ── Empty State ────────────────────────────────────────────────
window.emptyHTML = function (icon = 'fa-inbox', title = 'No data', sub = '') {
    return `<div class="empty-state"><i class="fas ${icon}"></i><h6>${escapeHtml(title)}</h6>${sub ? `<p>${escapeHtml(sub)}</p>` : ''}</div>`;
};

// ── API fetch wrapper ──────────────────────────────────────────
// Automatically appends _sess= to every API call so PHP opens the
// correct role session for this tab (multi-account support).
window._SESS = window._SESS || '';   // set by each dashboard page

window.apiFetch = async function (url, options = {}) {
    try {
        // Append _sess param if we know the session name for this tab
        let fullUrl = url;
        if (window._SESS) {
            const sep = url.includes('?') ? '&' : '?';
            fullUrl = url + sep + '_sess=' + window._SESS.replace('?_sess=', '');
        }
        const res = await fetch(fullUrl, options);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return await res.json();
    } catch (err) {
        console.error('API error:', err);
        throw err;
    }
};

// ── Loading HTML helper ────────────────────────────────────────
window.loadingHTML = function (msg = 'Loading…') {
    return `<div class="loading-state">
        <div class="spinner"></div>
        <span style="color:var(--color-muted);font-size:.85rem;">${escapeHtml(msg)}</span>
    </div>`;
};

// ── Empty state HTML helper ────────────────────────────────────
window.emptyHTML = function (icon, title, sub = '') {
    return `<div class="empty-state">
        <i class="fas ${escapeHtml(icon)}"></i>
        <h6>${escapeHtml(title)}</h6>
        ${sub ? `<p>${escapeHtml(sub)}</p>` : ''}
    </div>`;
};

// ── Debounce helper ────────────────────────────────────────────
window.debounce = function (fn, delay = 300) {
    let timer;
    return function (...args) {
        clearTimeout(timer);
        timer = setTimeout(() => fn.apply(this, args), delay);
    };
};

// ── apiFetch (wraps fetch with CSRF + JSON + error handling) ───
window.apiFetch = async function (url, options = {}) {
    const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
    const defaultOpts = {
        method: 'GET',
        headers: { 'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-Token': csrf },
        credentials: 'same-origin',
    };
    const merged = { ...defaultOpts, ...options };
    if (merged.body && typeof merged.body === 'object' && !(merged.body instanceof FormData)) {
        merged.body = JSON.stringify(merged.body);
        merged.headers['Content-Type'] = 'application/json';
    }
    const res = await fetch(url, merged);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
};

// ── Sidebar toggle (mobile) ────────────────────────────────────
window.toggleSidebar = function () {
    document.querySelector('.sidebar')?.classList.toggle('open');
};
document.addEventListener('click', function (e) {
    const sidebar = document.querySelector('.sidebar');
    const toggle  = document.querySelector('.mobile-toggle');
    if (sidebar?.classList.contains('open') && !sidebar.contains(e.target) && e.target !== toggle) {
        sidebar.classList.remove('open');
    }
});

// ── Auto-dismiss alerts ────────────────────────────────────────
document.querySelectorAll('[data-auto-dismiss]').forEach(el => {
    setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 400); }, 5000);
});

// ── Logout confirmation ────────────────────────────────────────
document.querySelectorAll('[data-logout]').forEach(btn => {
    btn.addEventListener('click', function () {
        if (confirm('Sign out of UMDC?')) {
            window.location.href = '/auth/logout.php';
        }
    });
});

// ── Dynamic section loader ─────────────────────────────────────
window.loadSection = function (section) {
    const el = document.getElementById('dynamic-content');
    if (!el) return;
    el.innerHTML = loadingHTML('Loading…');
    el.classList.remove('fade-in');

    const loaders = {
        'campaigns':     () => typeof loadCampaigns     === 'function' && loadCampaigns(el),
        'my-donations':  () => typeof loadMyDonations   === 'function' && loadMyDonations(el),
        'leaderboard':   () => typeof loadLeaderboard   === 'function' && loadLeaderboard(el),
        'transparency':  () => typeof loadTransparency  === 'function' && loadTransparency(el),
        'profile':       () => typeof loadProfile       === 'function' && loadProfile(el),
    };

    const loader = loaders[section];
    if (loader) {
        requestAnimationFrame(() => {
            loader();
            setTimeout(() => el.classList.add('fade-in'), 10);
        });
    } else {
        el.innerHTML = emptyHTML('fa-question-circle', 'Section not found');
    }
};
