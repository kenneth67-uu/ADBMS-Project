/* =============================================================
   UMDC – Notification Bell
   Include after the bell component:
     <script src="/assets/js/notifications.js"></script>
   ============================================================= */

(function () {
  'use strict';

  // ── Config ─────────────────────────────────────────────────
  const API        = '/api/notifications.php';
  const POLL_MS    = 30_000; // poll every 30s for new notifications
  const SESS_PARAM = document.querySelector('meta[name="sess-name"]')?.content
                     ? '?_sess=' + document.querySelector('meta[name="sess-name"]').content
                     : '';
  const CSRF_TOKEN = document.querySelector('meta[name="csrf-token"]')?.content || '';

  // ── State ──────────────────────────────────────────────────
  let page       = 1;
  let hasMore    = false;
  let loaded     = false;
  let polling    = null;

  // ── Elements ───────────────────────────────────────────────
  const wrap     = document.getElementById('notifBellWrap');
  const btn      = document.getElementById('notifBellBtn');
  const dropdown = document.getElementById('notifDropdown');
  const list     = document.getElementById('notifList');
  const badge    = document.getElementById('notifBadge');
  const markAll  = document.getElementById('notifMarkAll');
  const loadMore = document.getElementById('notifLoadMore');
  const footer   = document.getElementById('notifFooter');

  if (!wrap || !btn || !dropdown) return; // component not on page

  // ── Toggle dropdown ────────────────────────────────────────
  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    const isOpen = dropdown.classList.contains('open');
    if (isOpen) {
      close();
    } else {
      open();
    }
  });

  document.addEventListener('click', (e) => {
    if (!wrap.contains(e.target)) close();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') close();
  });

  function open() {
    dropdown.classList.add('open');
    btn.setAttribute('aria-expanded', 'true');
    if (!loaded) fetchNotifications(1, true);
    startPolling();
  }

  function close() {
    dropdown.classList.remove('open');
    btn.setAttribute('aria-expanded', 'false');
  }

  // ── Fetch ──────────────────────────────────────────────────
  async function fetchNotifications(pg = 1, replace = false) {
    if (replace) showLoading();

    try {
      const res  = await fetch(`${API}?page=${pg}${SESS_PARAM}`);
      const data = await res.json();
      if (!data.success) return;

      setBadge(data.unread);
      hasMore = data.has_more;
      page    = pg;
      loaded  = true;

      if (replace) {
        list.innerHTML = '';
      }
      removeLoading();

      if (data.items.length === 0 && replace) {
        list.innerHTML = emptyState();
      } else {
        data.items.forEach(item => list.appendChild(buildItem(item)));
      }

      footer.style.display = hasMore ? 'block' : 'none';

    } catch (err) {
      removeLoading();
      console.error('Notif fetch error', err);
    }
  }

  // ── Build item DOM ─────────────────────────────────────────
  function buildItem(item) {
    const el = document.createElement('div');
    el.className = 'notif-item' + (item.is_read ? '' : ' unread');
    el.dataset.id       = item.id;
    el.dataset.priority = item.priority;
    el.setAttribute('role', 'button');
    el.setAttribute('tabindex', '0');

    el.innerHTML = `
      <div class="notif-icon ${iconClass(item.type)}">
        <i class="fas ${item.icon || 'fa-bell'}"></i>
      </div>
      <div class="notif-content">
        <p class="notif-message">${escHtml(item.message)}</p>
        <span class="notif-time">${item.time_ago}</span>
      </div>
    `;

    el.addEventListener('click', () => handleItemClick(item, el));
    el.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') handleItemClick(item, el); });

    return el;
  }

  async function handleItemClick(item, el) {
    // Mark read
    if (!item.is_read) {
      el.classList.remove('unread');
      item.is_read = true;
      try {
        const fd = new FormData();
        fd.append('action', 'read');
        fd.append('id', item.id);
        fd.append('csrf_token', CSRF_TOKEN);
        const res  = await fetch(API + SESS_PARAM, { method: 'POST', body: fd });
        const data = await res.json();
        if (data.success) setBadge(data.unread);
      } catch (e) { /* silent */ }
    }
    // Navigate if link
    if (item.link) {
      close();
      window.location.href = item.link;
    }
  }

  // ── Mark all read ──────────────────────────────────────────
  markAll?.addEventListener('click', async () => {
    document.querySelectorAll('.notif-item.unread').forEach(el => el.classList.remove('unread'));
    setBadge(0);
    try {
      const fd = new FormData();
      fd.append('action', 'read_all');
      fd.append('csrf_token', CSRF_TOKEN);
      await fetch(API + SESS_PARAM, { method: 'POST', body: fd });
    } catch (e) { /* silent */ }
  });

  // ── Load more ──────────────────────────────────────────────
  loadMore?.addEventListener('click', () => {
    if (hasMore) fetchNotifications(page + 1, false);
  });

  // ── Polling ────────────────────────────────────────────────
  function startPolling() {
    if (polling) return;
    polling = setInterval(pollUnread, POLL_MS);
  }

  async function pollUnread() {
    try {
      const res  = await fetch(`${API}?page=1${SESS_PARAM}`);
      const data = await res.json();
      if (!data.success) return;
      setBadge(data.unread);
      // If new items appeared and dropdown is open, refresh list
      if (dropdown.classList.contains('open')) {
        fetchNotifications(1, true);
      }
    } catch (e) { /* silent */ }
  }

  // Also poll when tab becomes visible again
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) pollUnread();
  });

  // ── Badge ──────────────────────────────────────────────────
  function setBadge(count) {
    if (!badge) return;
    if (count > 0) {
      badge.textContent = count > 99 ? '99+' : count;
      badge.classList.add('visible');
    } else {
      badge.textContent = '';
      badge.classList.remove('visible');
    }
  }

  // ── Helpers ────────────────────────────────────────────────
  function iconClass(type) {
    if (!type) return 'notif-icon-default';
    if (type.startsWith('donation'))   return 'notif-icon-donation';
    if (type.startsWith('campaign'))   return 'notif-icon-campaign';
    if (type.startsWith('courier') || type.startsWith('delivery')) return 'notif-icon-courier';
    if (type.startsWith('verification') || type.startsWith('org_verif')) return 'notif-icon-verify';
    if (type.startsWith('password') || type.startsWith('login') || type.startsWith('email_verif')) return 'notif-icon-security';
    if (type.startsWith('admin'))      return 'notif-icon-admin';
    return 'notif-icon-default';
  }

  function emptyState() {
    return `<div class="notif-empty">
      <i class="fas fa-bell-slash"></i>
      <p>You're all caught up!</p>
    </div>`;
  }

  function showLoading() {
    list.innerHTML = `<div class="notif-loading" id="notifLoading">
      <i class="fas fa-spinner fa-spin"></i>
    </div>`;
  }

  function removeLoading() {
    document.getElementById('notifLoading')?.remove();
  }

  function escHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // ── Initial unread count (already set server-side on badge) ─
  // Do a quick poll on page load to keep it fresh
  setTimeout(pollUnread, 3000);

})();
