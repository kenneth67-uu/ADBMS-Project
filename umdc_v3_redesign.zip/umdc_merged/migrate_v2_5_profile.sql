-- ================================================================
-- UMDC migrate_v2_5_profile.sql
-- Adds all missing profile columns to users & organizations
-- Safe stored-procedure pattern (works on MySQL 5.7+)
-- Run AFTER umdc.sql + migrate.sql
-- ================================================================

SET FOREIGN_KEY_CHECKS = 0;

-- ── users: extra profile columns ────────────────────────────────
DROP PROCEDURE IF EXISTS umdc_profile_users;
DELIMITER $$
CREATE PROCEDURE umdc_profile_users()
BEGIN
  -- Already in migrate.sql but guard anyway
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='profile_photo') THEN
    ALTER TABLE `users` ADD COLUMN `profile_photo` VARCHAR(500) DEFAULT NULL AFTER `address`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='bio') THEN
    ALTER TABLE `users` ADD COLUMN `bio` TEXT DEFAULT NULL AFTER `profile_photo`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='date_of_birth') THEN
    ALTER TABLE `users` ADD COLUMN `date_of_birth` DATE DEFAULT NULL AFTER `bio`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='gender') THEN
    ALTER TABLE `users` ADD COLUMN `gender` ENUM('male','female','prefer_not_to_say') DEFAULT NULL AFTER `date_of_birth`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='facebook') THEN
    ALTER TABLE `users` ADD COLUMN `facebook` VARCHAR(255) DEFAULT NULL AFTER `gender`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='twitter') THEN
    ALTER TABLE `users` ADD COLUMN `twitter` VARCHAR(100) DEFAULT NULL AFTER `facebook`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='instagram') THEN
    ALTER TABLE `users` ADD COLUMN `instagram` VARCHAR(100) DEFAULT NULL AFTER `twitter`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='linkedin') THEN
    ALTER TABLE `users` ADD COLUMN `linkedin` VARCHAR(255) DEFAULT NULL AFTER `instagram`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='website') THEN
    ALTER TABLE `users` ADD COLUMN `website` VARCHAR(255) DEFAULT NULL AFTER `linkedin`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='updated_at') THEN
    ALTER TABLE `users` ADD COLUMN `updated_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER `website`;
  END IF;
  -- Notification columns (from v2.4)
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='email_verified_at') THEN
    ALTER TABLE `users` ADD COLUMN `email_verified_at` TIMESTAMP DEFAULT NULL AFTER `is_verified`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='two_factor_enabled') THEN
    ALTER TABLE `users` ADD COLUMN `two_factor_enabled` TINYINT(1) DEFAULT 0 AFTER `email_verified_at`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='last_login_at') THEN
    ALTER TABLE `users` ADD COLUMN `last_login_at` TIMESTAMP DEFAULT NULL AFTER `two_factor_enabled`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='last_login_ip') THEN
    ALTER TABLE `users` ADD COLUMN `last_login_ip` VARCHAR(50) DEFAULT NULL AFTER `last_login_at`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='failed_login_count') THEN
    ALTER TABLE `users` ADD COLUMN `failed_login_count` INT DEFAULT 0 AFTER `last_login_ip`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='locked_until') THEN
    ALTER TABLE `users` ADD COLUMN `locked_until` TIMESTAMP DEFAULT NULL AFTER `failed_login_count`;
  END IF;
END$$
DELIMITER ;
CALL umdc_profile_users();
DROP PROCEDURE IF EXISTS umdc_profile_users;

-- ── organizations: extra columns ────────────────────────────────
DROP PROCEDURE IF EXISTS umdc_profile_orgs;
DELIMITER $$
CREATE PROCEDURE umdc_profile_orgs()
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='organizations' AND COLUMN_NAME='logo') THEN
    ALTER TABLE `organizations` ADD COLUMN `logo` VARCHAR(500) DEFAULT NULL AFTER `description`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='organizations' AND COLUMN_NAME='cover_photo') THEN
    ALTER TABLE `organizations` ADD COLUMN `cover_photo` VARCHAR(500) DEFAULT NULL AFTER `logo`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='organizations' AND COLUMN_NAME='website') THEN
    ALTER TABLE `organizations` ADD COLUMN `website` VARCHAR(255) DEFAULT NULL AFTER `cover_photo`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='organizations' AND COLUMN_NAME='facebook') THEN
    ALTER TABLE `organizations` ADD COLUMN `facebook` VARCHAR(255) DEFAULT NULL AFTER `website`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='organizations' AND COLUMN_NAME='twitter') THEN
    ALTER TABLE `organizations` ADD COLUMN `twitter` VARCHAR(100) DEFAULT NULL AFTER `facebook`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='organizations' AND COLUMN_NAME='instagram') THEN
    ALTER TABLE `organizations` ADD COLUMN `instagram` VARCHAR(100) DEFAULT NULL AFTER `twitter`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='organizations' AND COLUMN_NAME='founded_year') THEN
    ALTER TABLE `organizations` ADD COLUMN `founded_year` YEAR DEFAULT NULL AFTER `instagram`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='organizations' AND COLUMN_NAME='address') THEN
    ALTER TABLE `organizations` ADD COLUMN `address` TEXT DEFAULT NULL AFTER `founded_year`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='organizations' AND COLUMN_NAME='mission') THEN
    ALTER TABLE `organizations` ADD COLUMN `mission` TEXT DEFAULT NULL AFTER `address`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='organizations' AND COLUMN_NAME='updated_at') THEN
    ALTER TABLE `organizations` ADD COLUMN `updated_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER `mission`;
  END IF;
END$$
DELIMITER ;
CALL umdc_profile_orgs();
DROP PROCEDURE IF EXISTS umdc_profile_orgs;

-- ── notifications table: extra columns ──────────────────────────
DROP PROCEDURE IF EXISTS umdc_notif_cols;
DELIMITER $$
CREATE PROCEDURE umdc_notif_cols()
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='notifications' AND COLUMN_NAME='type') THEN
    ALTER TABLE `notifications` ADD COLUMN `type` VARCHAR(80) DEFAULT 'general' AFTER `message`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='notifications' AND COLUMN_NAME='link') THEN
    ALTER TABLE `notifications` ADD COLUMN `link` VARCHAR(500) DEFAULT NULL AFTER `type`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='notifications' AND COLUMN_NAME='icon') THEN
    ALTER TABLE `notifications` ADD COLUMN `icon` VARCHAR(50) DEFAULT NULL AFTER `link`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='notifications' AND COLUMN_NAME='priority') THEN
    ALTER TABLE `notifications` ADD COLUMN `priority` ENUM('low','normal','high','urgent') DEFAULT 'normal' AFTER `icon`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='notifications' AND COLUMN_NAME='read_at') THEN
    ALTER TABLE `notifications` ADD COLUMN `read_at` TIMESTAMP DEFAULT NULL AFTER `is_read`;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='notifications' AND COLUMN_NAME='expires_at') THEN
    ALTER TABLE `notifications` ADD COLUMN `expires_at` TIMESTAMP DEFAULT NULL AFTER `read_at`;
  END IF;
END$$
DELIMITER ;
CALL umdc_notif_cols();
DROP PROCEDURE IF EXISTS umdc_notif_cols;

-- ── email_queue ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `email_queue` (
  `id`            BIGINT        NOT NULL AUTO_INCREMENT,
  `to_email`      VARCHAR(200)  NOT NULL,
  `to_name`       VARCHAR(200)  DEFAULT NULL,
  `subject`       VARCHAR(500)  NOT NULL,
  `body_html`     LONGTEXT      NOT NULL,
  `body_text`     TEXT          DEFAULT NULL,
  `template_key`  VARCHAR(100)  DEFAULT NULL,
  `status`        ENUM('queued','sent','failed','cancelled') DEFAULT 'queued',
  `attempts`      INT           DEFAULT 0,
  `last_attempt`  TIMESTAMP     DEFAULT NULL,
  `sent_at`       TIMESTAMP     DEFAULT NULL,
  `error_msg`     TEXT          DEFAULT NULL,
  `created_at`    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `status`     (`status`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── sms_queue ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `sms_queue` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT,
  `to_phone`    VARCHAR(20)  NOT NULL,
  `message`     VARCHAR(160) NOT NULL,
  `status`      ENUM('queued','sent','failed') DEFAULT 'queued',
  `attempts`    INT          DEFAULT 0,
  `sent_at`     TIMESTAMP    DEFAULT NULL,
  `created_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── system_settings ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `system_settings` (
  `key`         VARCHAR(100) NOT NULL,
  `value`       TEXT         DEFAULT NULL,
  `description` VARCHAR(500) DEFAULT NULL,
  `updated_by`  BIGINT       DEFAULT NULL,
  `updated_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `system_settings` (`key`, `value`, `description`) VALUES
('mail_from_email',       'no-reply@umdc.ph', 'Sender email address'),
('mail_from_name',        'UMDC',             'Sender display name'),
('email_driver',          'mail',             'mail | smtp'),
('smtp_host',             'smtp.gmail.com',   'SMTP host'),
('smtp_port',             '587',              'SMTP port'),
('smtp_secure',           'tls',              'tls | ssl | none'),
('smtp_user',             '',                 'SMTP username'),
('smtp_pass',             '',                 'SMTP password (stored plain — use env in prod)'),
('semaphore_api_key',     '',                 'Semaphore SMS API key'),
('sms_sender_name',       'UMDC',             'SMS sender name (max 11 chars)'),
('sms_driver',            'semaphore',        'SMS gateway'),
('require_email_verify',  '1',                '1 = require email verification on signup'),
('2fa_required_for_orgs', '0',                '1 = force 2FA for org accounts'),
('fraud_score_threshold', '70',               'Score above which account is auto-flagged'),
('max_login_attempts',    '5',                'Failed logins before lockout'),
('lockout_minutes',       '30',               'Lockout duration in minutes');

SET FOREIGN_KEY_CHECKS = 1;
SELECT '✅ UMDC v2.5 profile + notifications migration complete.' AS result;
