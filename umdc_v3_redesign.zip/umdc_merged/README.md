# UMDC Platform — Complete Setup Guide

## Project Structure

```
htdocs/
├── assets/
│   ├── css/
│   │   ├── global.css        ← Shared variables, components, layout
│   │   ├── public.css        ← Landing page, auth pages
│   │   └── dashboard.css     ← All dashboard roles
│   ├── js/
│   │   ├── global.js         ← Toast, modal, helpers, CSRF fetch
│   │   ├── auth.js           ← Login/register validation
│   │   ├── public.js         ← Landing page animations, campaign loader
│   │   ├── dashboard.js      ← Shared dashboard JS, DonationForm
│   │   └── user.js           ← User dashboard section loader
│   └── img/                  ← (Place your images here)
├── Auth/
│   ├── Middleware.php         ← Session bootstrap shim
│   ├── login.php              ← Login handler (rate-limited, audited)
│   ├── register.php           ← Registration handler (validated)
│   └── logout.php             ← Secure logout + session destroy
├── Config/
│   ├── db.php                 ← PDO connection (env var aware)
│   └── security.php           ← CSRF, auth helpers, rate limit, audit log
├── public/
│   ├── index.php              ← 🌐 Public landing page (no login required)
│   ├── login.html             ← Login page (external CSS/JS)
│   ├── register.html          ← Register page (external CSS/JS)
│   └── unauthorized.html      ← 403 page
├── dashboard/
│   ├── user.php               ← Donor dashboard
│   ├── organization.php       ← Organization dashboard
│   └── admin.php              ← Admin dashboard (dark theme)
├── api/
│   ├── public_campaigns.php   ← ✅ Public — no auth
│   ├── campaigns.php          ← Auth required (all roles)
│   ├── donate.php             ← User only, CSRF-protected
│   ├── my_donation.php        ← User's donation history
│   ├── profile.php            ← Profile data
│   ├── update_profile.php     ← Profile update, CSRF-protected
│   ├── transparency.php       ← Public ledger records
│   └── setup_org.php          ← Organization setup
├── admin/
│   ├── approvals.php          ← Approve/reject campaigns & orgs
│   ├── users.php              ← User management (suspend/ban)
│   ├── donations.php          ← All donations view
│   ├── fraud.php              ← Fraud flag management
│   ├── analytics.php          ← Platform analytics
│   ├── review_campaigns.php   ← (copy from original + refactor)
│   ├── organizations.php      ← Org management
│   ├── reports.php            ← Reports
│   └── system.php             ← System info
├── campaigns/
│   └── submit.php             ← Campaign creation for orgs
├── donations/
│   └── cash.php               ← Payment confirmation page
├── receipts/
│   ├── generate.php           ← Receipt + ledger hash generator
│   └── view.php               ← Receipt viewer (print-ready)
├── analytics/
│   └── leaderboard.php        ← Donor leaderboard API
├── verification/
│   └── submit.php             ← Document verification submission
└── uploads/
    └── verification/          ← Uploaded verification documents (chmod 750)
```

---

## Quick Setup (XAMPP)

### 1. Database
```sql
-- In phpMyAdmin, create database: umdc
-- Import: umdc.sql
```

### 2. Configure DB credentials
Edit `htdocs/Config/db.php` — or set environment variables:
```
DB_HOST=localhost
DB_NAME=umdc
DB_USER=root
DB_PASS=yourpassword
```

### 3. Virtual Host (recommended)
In `httpd-vhosts.conf`:
```apache
<VirtualHost *:80>
    DocumentRoot "C:/xampp/htdocs"
    ServerName localhost
    <Directory "C:/xampp/htdocs">
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
```

### 4. URL Rewriting (create htdocs/.htaccess)
```apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
```

### 5. Upload Directory Permissions
```bash
chmod 750 htdocs/uploads/
chmod 750 htdocs/uploads/verification/
```

---

## Security Features Implemented

| Feature | Implementation |
|---|---|
| SQL Injection | PDO prepared statements throughout |
| XSS | `e()` / `htmlspecialchars()` on all output |
| CSRF | Token on every POST form + API validation |
| Session Fixation | `session_regenerate_id()` on login |
| Rate Limiting | File-based limiter on login & register |
| Password Hashing | `bcrypt` cost 12 |
| File Upload | MIME validation, size limit, random filenames |
| Secure Cookies | `httponly`, `samesite=Strict`, `secure` in HTTPS |
| Role Enforcement | `requireRole()` / `requireAnyRole()` middleware |
| Audit Logging | All sensitive actions logged to `audit_logs` |
| Secure Headers | CSP, X-Frame-Options, X-Content-Type-Options |
| Guest Restriction | Public view read-only, interactions require login |

---

## Default Test Accounts

| Role | Email | Password |
|---|---|---|
| User | aldrich.malijan789@gmail.com | (from DB hash) |
| Organization | lando_navidad@yahoo.com | (from DB hash) |
| Admin | Create one via SQL: see below |

### Create admin account:
```sql
INSERT INTO users (role_id, first_name, last_name, email, password_hash, status)
VALUES (1, 'Admin', 'User', 'admin@umdc.local',
  '$2y$12$' /* run: password_hash('Admin@1234', PASSWORD_BCRYPT, ['cost'=>12]) */,
  'active');
```

---

## Public vs Authenticated Features

### 🌐 Public (No Login)
- Landing page with campaign previews
- Statistics bar
- How it works, Features sections
- Login / Register pages

### 🔒 Authenticated Only
- Full campaign listings
- Donate (cash / item / service)
- My donations & receipts
- Leaderboard & transparency ledger
- Profile management
- Organization dashboard
- Admin panel

---

## Key URLs

| URL | Description |
|---|---|
| `/public/index.php` | Landing page |
| `/public/login.html` | Login |
| `/public/register.html` | Register |
| `/dashboard/user.php` | Donor dashboard |
| `/dashboard/organization.php` | Org dashboard |
| `/dashboard/admin.php` | Admin dashboard |
| `/admin/approvals.php` | Approve campaigns/orgs |
| `/admin/users.php` | Manage users |
| `/admin/fraud.php` | Fraud flags |
| `/admin/analytics.php` | Analytics |
