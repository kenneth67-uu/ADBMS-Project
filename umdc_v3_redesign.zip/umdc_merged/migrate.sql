-- ================================================================
-- UMDC v2.3 → Improved Migration
-- Applies: profile/org/campaign columns, performance indexes,
--          data-alignment fixes, and dashboard filter support.
-- Run once in phpMyAdmin (SQL tab) or MySQL CLI.
-- Safe to re-run: uses IF NOT EXISTS / IGNORE where possible.
-- ================================================================

SET FOREIGN_KEY_CHECKS = 0;

-- ────────────────────────────────────────────────────────────────
-- 1. USERS  – profile enrichment columns
-- ────────────────────────────────────────────────────────────────
ALTER TABLE `users`
  ADD COLUMN IF NOT EXISTS `profile_photo`  varchar(500)                                       DEFAULT NULL AFTER `address`,
  ADD COLUMN IF NOT EXISTS `bio`            text                                               DEFAULT NULL AFTER `profile_photo`,
  ADD COLUMN IF NOT EXISTS `date_of_birth`  date                                               DEFAULT NULL AFTER `bio`,
  ADD COLUMN IF NOT EXISTS `gender`         enum('male','female','prefer_not_to_say')          DEFAULT NULL AFTER `date_of_birth`,
  ADD COLUMN IF NOT EXISTS `facebook`       varchar(255)                                       DEFAULT NULL AFTER `gender`,
  ADD COLUMN IF NOT EXISTS `twitter`        varchar(255)                                       DEFAULT NULL AFTER `facebook`,
  ADD COLUMN IF NOT EXISTS `updated_at`     timestamp NULL DEFAULT CURRENT_TIMESTAMP
                                            ON UPDATE CURRENT_TIMESTAMP                        AFTER `twitter`;

-- ────────────────────────────────────────────────────────────────
-- 2. ORGANIZATIONS  – branding and contact columns
-- ────────────────────────────────────────────────────────────────
ALTER TABLE `organizations`
  ADD COLUMN IF NOT EXISTS `logo`           varchar(500)   DEFAULT NULL AFTER `description`,
  ADD COLUMN IF NOT EXISTS `cover_photo`    varchar(500)   DEFAULT NULL AFTER `logo`,
  ADD COLUMN IF NOT EXISTS `website`        varchar(255)   DEFAULT NULL AFTER `cover_photo`,
  ADD COLUMN IF NOT EXISTS `facebook`       varchar(255)   DEFAULT NULL AFTER `website`,
  ADD COLUMN IF NOT EXISTS `founded_year`   year           DEFAULT NULL AFTER `facebook`,
  ADD COLUMN IF NOT EXISTS `address`        text           DEFAULT NULL AFTER `founded_year`,
  ADD COLUMN IF NOT EXISTS `mission`        text           DEFAULT NULL AFTER `address`,
  ADD COLUMN IF NOT EXISTS `updated_at`     timestamp NULL DEFAULT CURRENT_TIMESTAMP
                                            ON UPDATE CURRENT_TIMESTAMP AFTER `mission`;

-- ────────────────────────────────────────────────────────────────
-- 3. CAMPAIGNS  – image, geo, meta columns
-- ────────────────────────────────────────────────────────────────
ALTER TABLE `campaigns`
  ADD COLUMN IF NOT EXISTS `campaign_image` varchar(500)  DEFAULT NULL AFTER `status`,
  ADD COLUMN IF NOT EXISTS `location`       varchar(255)  DEFAULT NULL AFTER `campaign_image`,
  ADD COLUMN IF NOT EXISTS `beneficiaries`  int           DEFAULT NULL AFTER `location`,
  ADD COLUMN IF NOT EXISTS `contact_person` varchar(150)  DEFAULT NULL AFTER `beneficiaries`,
  ADD COLUMN IF NOT EXISTS `contact_email`  varchar(150)  DEFAULT NULL AFTER `contact_person`,
  ADD COLUMN IF NOT EXISTS `tags`           varchar(500)  DEFAULT NULL AFTER `contact_email`,
  ADD COLUMN IF NOT EXISTS `updated_at`     timestamp NULL DEFAULT CURRENT_TIMESTAMP
                                            ON UPDATE CURRENT_TIMESTAMP AFTER `tags`;

-- ────────────────────────────────────────────────────────────────
-- 4. DELIVERIES  – tracking and proof columns
-- ────────────────────────────────────────────────────────────────
ALTER TABLE `deliveries`
  ADD COLUMN IF NOT EXISTS `notes`               text          DEFAULT NULL AFTER `tracking_code`,
  ADD COLUMN IF NOT EXISTS `pickup_address`       text          DEFAULT NULL AFTER `notes`,
  ADD COLUMN IF NOT EXISTS `pickup_date`          date          DEFAULT NULL AFTER `pickup_address`,
  ADD COLUMN IF NOT EXISTS `estimated_delivery`   date          DEFAULT NULL AFTER `pickup_date`,
  ADD COLUMN IF NOT EXISTS `delivered_at`         timestamp NULL DEFAULT NULL AFTER `estimated_delivery`,
  ADD COLUMN IF NOT EXISTS `proof_photo`          varchar(500)  DEFAULT NULL AFTER `delivered_at`,
  ADD COLUMN IF NOT EXISTS `updated_at`           timestamp NULL DEFAULT CURRENT_TIMESTAMP
                                                  ON UPDATE CURRENT_TIMESTAMP AFTER `proof_photo`;

-- ────────────────────────────────────────────────────────────────
-- 5. ITEM_DONATIONS  – condition and value columns
-- ────────────────────────────────────────────────────────────────
ALTER TABLE `item_donations`
  ADD COLUMN IF NOT EXISTS `condition_notes`  varchar(500)    DEFAULT NULL AFTER `description`,
  ADD COLUMN IF NOT EXISTS `estimated_value`  decimal(10,2)   DEFAULT NULL AFTER `condition_notes`,
  ADD COLUMN IF NOT EXISTS `photo`            varchar(500)    DEFAULT NULL AFTER `estimated_value`;

-- ────────────────────────────────────────────────────────────────
-- 6. VERIFICATION_REQUESTS  – extra document slots
-- ────────────────────────────────────────────────────────────────
ALTER TABLE `verification_requests`
  ADD COLUMN IF NOT EXISTS `additional_notes`      text DEFAULT NULL AFTER `review_notes`,
  ADD COLUMN IF NOT EXISTS `second_document_path`  text DEFAULT NULL AFTER `additional_notes`,
  ADD COLUMN IF NOT EXISTS `selfie_path`           text DEFAULT NULL AFTER `second_document_path`;

-- ────────────────────────────────────────────────────────────────
-- 7. DONATIONS  – payment reference for PayMongo reconciliation
-- ────────────────────────────────────────────────────────────────
ALTER TABLE `donations`
  ADD COLUMN IF NOT EXISTS `payment_reference` varchar(255) DEFAULT NULL AFTER `status`,
  ADD COLUMN IF NOT EXISTS `updated_at`        timestamp NULL DEFAULT CURRENT_TIMESTAMP
                                               ON UPDATE CURRENT_TIMESTAMP AFTER `payment_reference`;

-- ────────────────────────────────────────────────────────────────
-- 8. SERVICE_DONATIONS  – missing table for service-type donations
--    The donate.php API creates service records but no table existed.
-- ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `service_donations` (
  `service_id`          bigint         NOT NULL AUTO_INCREMENT,
  `donation_id`         bigint         NOT NULL,
  `service_description` text           NOT NULL,
  `offered_date`        date           DEFAULT NULL,
  `status`              enum('pending','accepted','completed','declined') DEFAULT 'pending',
  `admin_notes`         text           DEFAULT NULL,
  `created_at`          timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`service_id`),
  KEY `idx_service_donation` (`donation_id`),
  CONSTRAINT `service_donations_ibfk_1`
    FOREIGN KEY (`donation_id`) REFERENCES `donations` (`donation_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ────────────────────────────────────────────────────────────────
-- 9. PERFORMANCE INDEXES
--    All missing indexes that dashboard filter queries need.
--    Uses IF NOT EXISTS (MySQL 8.0+). On older MySQL, remove that.
-- ────────────────────────────────────────────────────────────────

-- donations: filter by user+status, sort by date, sum by campaign
ALTER TABLE `donations`
  ADD INDEX IF NOT EXISTS `idx_don_user_status`     (`user_id`, `status`),
  ADD INDEX IF NOT EXISTS `idx_don_campaign_status` (`campaign_id`, `status`),
  ADD INDEX IF NOT EXISTS `idx_don_created`         (`created_at`),
  ADD INDEX IF NOT EXISTS `idx_don_type`            (`donation_type`);

-- campaigns: filter by org+status, category browsing
ALTER TABLE `campaigns`
  ADD INDEX IF NOT EXISTS `idx_camp_org_status` (`org_id`, `status`),
  ADD INDEX IF NOT EXISTS `idx_camp_status`      (`status`),
  ADD INDEX IF NOT EXISTS `idx_camp_category`    (`category`),
  ADD INDEX IF NOT EXISTS `idx_camp_end_date`    (`end_date`);

-- approvals: admin pending queue
ALTER TABLE `approvals`
  ADD INDEX IF NOT EXISTS `idx_appr_status` (`status`),
  ADD INDEX IF NOT EXISTS `idx_appr_entity` (`entity_type`, `entity_id`);

-- fraud_flags: open flags count on admin dashboard
ALTER TABLE `fraud_flags`
  ADD INDEX IF NOT EXISTS `idx_fraud_status` (`status`);

-- ledgers: public hash lookup for transparency page
ALTER TABLE `ledgers`
  ADD INDEX IF NOT EXISTS `idx_ledger_hash` (`public_hash`(32));

-- notifications: unread badge count per user
ALTER TABLE `notifications`
  ADD INDEX IF NOT EXISTS `idx_notif_user_read` (`user_id`, `is_read`);

-- audit_logs: admin activity feed
ALTER TABLE `audit_logs`
  ADD INDEX IF NOT EXISTS `idx_audit_user`    (`user_id`),
  ADD INDEX IF NOT EXISTS `idx_audit_created` (`created_at`);

-- users: role/status filter for admin users panel
ALTER TABLE `users`
  ADD INDEX IF NOT EXISTS `idx_users_role_status` (`role_id`, `status`),
  ADD INDEX IF NOT EXISTS `idx_users_created`     (`created_at`);

-- organizations: verified filter
ALTER TABLE `organizations`
  ADD INDEX IF NOT EXISTS `idx_org_user`     (`user_id`),
  ADD INDEX IF NOT EXISTS `idx_org_verified` (`verified`);

-- ────────────────────────────────────────────────────────────────
-- 10. DATA ALIGNMENT FIXES
--     Correct rows that got into impossible or inconsistent states.
-- ────────────────────────────────────────────────────────────────

-- 10a. Mark donations with orphaned campaign_id as failed
UPDATE `donations` d
  LEFT JOIN `campaigns` c ON d.campaign_id = c.campaign_id
SET d.status = 'failed'
WHERE c.campaign_id IS NULL
  AND d.status NOT IN ('failed','refunded');

-- 10b. Campaigns whose current_amount is NULL → set to 0.00
UPDATE `campaigns`
SET `current_amount` = 0.00
WHERE `current_amount` IS NULL;

-- 10c. Re-sync current_amount from actual completed cash donations
--      Ensures the displayed total is always accurate
UPDATE `campaigns` c
JOIN (
  SELECT campaign_id, COALESCE(SUM(amount), 0) AS real_total
  FROM donations
  WHERE status = 'completed' AND donation_type = 'cash'
  GROUP BY campaign_id
) agg ON agg.campaign_id = c.campaign_id
SET c.current_amount = agg.real_total
WHERE c.current_amount <> agg.real_total;

-- 10d. Campaigns past end_date still marked 'active' → complete them
UPDATE `campaigns`
SET `status` = 'completed'
WHERE `status` = 'active'
  AND `end_date` IS NOT NULL
  AND `end_date` < CURDATE();

-- 10e. Users with NULL status → default 'active'
UPDATE `users`
SET `status` = 'active'
WHERE `status` IS NULL OR `status` = '';

-- ────────────────────────────────────────────────────────────────
-- 11. HELPER VIEWS for dashboard queries
--     Dashboards can SELECT from these instead of raw JOIN chains.
-- ────────────────────────────────────────────────────────────────

-- User donation summary (used by user dashboard stat cards)
CREATE OR REPLACE VIEW `vw_user_donation_summary` AS
SELECT
  d.user_id,
  COUNT(*)                                                                 AS total_count,
  COALESCE(SUM(CASE WHEN d.status = 'completed' THEN d.amount END), 0)   AS total_donated,
  COUNT(CASE WHEN d.status = 'completed' THEN 1 END)                      AS completed_count,
  COUNT(CASE WHEN d.status = 'pending'   THEN 1 END)                      AS pending_count,
  COUNT(DISTINCT d.campaign_id)                                            AS campaigns_supported,
  COUNT(CASE WHEN d.donation_type = 'cash'    THEN 1 END)                 AS cash_count,
  COUNT(CASE WHEN d.donation_type = 'item'    THEN 1 END)                 AS item_count,
  COUNT(CASE WHEN d.donation_type = 'service' THEN 1 END)                 AS service_count
FROM donations d
GROUP BY d.user_id;

-- Organization campaign summary (used by org dashboard stat cards)
CREATE OR REPLACE VIEW `vw_org_campaign_summary` AS
SELECT
  c.org_id,
  COUNT(*)                                                        AS total_campaigns,
  COUNT(CASE WHEN c.status IN ('approved','active') THEN 1 END)  AS active_campaigns,
  COALESCE(SUM(c.current_amount), 0)                             AS total_raised,
  COUNT(DISTINCT d.user_id)                                      AS total_donors
FROM campaigns c
LEFT JOIN donations d
  ON d.campaign_id = c.campaign_id AND d.status = 'completed'
GROUP BY c.org_id;

-- Public leaderboard (used by leaderboard section & analytics)
CREATE OR REPLACE VIEW `vw_leaderboard` AS
SELECT
  u.user_id,
  CONCAT(u.first_name, ' ', u.last_name) AS donor_name,
  u.bio,
  u.profile_photo,
  COUNT(d.donation_id)                   AS donation_count,
  COALESCE(SUM(d.amount), 0)            AS total_donated
FROM users u
JOIN donations d
  ON d.user_id = u.user_id
  AND d.status = 'completed'
  AND d.donation_type = 'cash'
GROUP BY u.user_id, donor_name, u.bio, u.profile_photo
ORDER BY total_donated DESC;

-- Admin platform overview (used by admin dashboard stat cards)
CREATE OR REPLACE VIEW `vw_admin_overview` AS
SELECT
  (SELECT COUNT(*) FROM users)                                              AS total_users,
  (SELECT COUNT(*) FROM organizations)                                      AS total_orgs,
  (SELECT COUNT(*) FROM campaigns)                                          AS total_campaigns,
  (SELECT COUNT(*) FROM campaigns WHERE status IN ('active','approved'))    AS active_campaigns,
  (SELECT COUNT(*) FROM donations)                                          AS total_donations,
  (SELECT COALESCE(SUM(amount), 0) FROM donations WHERE status='completed') AS total_raised,
  (SELECT COUNT(*) FROM approvals WHERE status='pending')                   AS pending_approvals,
  (SELECT COUNT(*) FROM fraud_flags WHERE status='open')                    AS open_flags;

SET FOREIGN_KEY_CHECKS = 1;

SELECT 'UMDC Improved Migration complete! Run SELECT * FROM vw_admin_overview to verify.' AS result;
